import { ListingClient } from "@/components/listing-client";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ lid: string }>;
}) {
  const { lid } = await params;
  return { title: `${lid} · BOSS trust layer` };
}

export default async function ListingPage({
  params,
}: {
  params: Promise<{ id: string; lid: string }>;
}) {
  const { id, lid } = await params;
  return <ListingClient id={id} lid={lid} />;
}
