import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // The dev overlay badge sits on top of the sidebar footer.
  devIndicators: false,
};

export default nextConfig;
