"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

/**
 * The Triage / Ledger toggle from screenshots/boss-pipeline.png.
 *
 * Both halves are real views: Triage is the deal list, Ledger is every
 * scraped listing. It lives in one component so the two pages cannot
 * disagree about which half is selected.
 */
export function Segmented({ dealId }: { dealId: string }) {
  const pathname = usePathname();
  // The ledger belongs to a deal. Hardcoding one meant opening "Ledger" from
  // the fully-furnished deal silently showed the semi-furnished comp set.
  const items = [
    { href: "/", label: "Triage" },
    { href: `/ledger?deal=${encodeURIComponent(dealId)}`, label: "Ledger" },
  ];

  return (
    <div className="flex overflow-hidden rounded-md border border-border bg-secondary">
      {items.map((i) => {
        const active =
          i.href === "/" ? pathname === "/" : pathname.startsWith("/ledger");
        return (
          <Link
            key={i.href}
            href={i.href}
            aria-current={active ? "page" : undefined}
            className={`px-3.5 py-1.5 text-[13px] transition ${
              active
                ? "bg-card font-medium text-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {i.label}
          </Link>
        );
      })}
    </div>
  );
}
