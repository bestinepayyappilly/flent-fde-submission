import { LedgerClient } from "@/components/ledger-client";

export const metadata = {
  title: "Ledger · BOSS trust layer",
  description:
    "Every scraped listing, with the rule and the reason it was kept or dropped.",
};

const DEFAULT_DEAL = "FLT-FDE-2026-01";

export default async function LedgerPage({
  searchParams,
}: {
  searchParams: Promise<{ deal?: string }>;
}) {
  const { deal } = await searchParams;
  return <LedgerClient dealId={deal ?? DEFAULT_DEAL} />;
}
