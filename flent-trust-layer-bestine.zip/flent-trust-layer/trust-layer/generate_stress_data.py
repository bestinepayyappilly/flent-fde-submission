#!/usr/bin/env python3
"""
Generate labelled SYNTHETIC pulls that exercise the engine's known failure
modes, so the trust layer can be tested against inputs the case packet does
not contain.

    python3 generate_stress_data.py          # write ../stress-data/
    python3 generate_stress_data.py --check  # write, then score each and
                                             # compare against expectations

EVERY ROW THESE WRITE IS FABRICATED. The packet's ground rule is that
invented data must say so, so each scenario ships a README.md and every
deal_id carries a SYNTH- prefix. None of this is evidence about Bangalore;
it is evidence about the engine.

The scenarios are drawn from FAILURES.md. Two of them are expected to defeat
the engine rather than be caught by it, and they are labelled as such: a
harness that only generates cases its own code passes is a demo, not a test.
"""

import argparse
import csv
import json
import os
import random
import subprocess
import sys
import zlib
from datetime import date, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(os.path.join(HERE, "..", "stress-data"))

SNAPSHOT = date(2026, 8, 18)
PORTALS = ["MagicBricks", "NoBroker", "Housing", "CommonFloor"]
FIELDS = [
    "listing_id", "source", "posted_date", "last_seen_date", "society",
    "locality", "bhk", "furnishing", "area_sqft", "rent", "deposit",
    "photo_count", "poster_type",
]
LOCALITY = "Harlur-Sarjapur Road"


def row(i, rent, *, society="Lakeview Residences", bhk="2",
        furnishing="semi-furnished", portal=None, posted_ago=None,
        seen_ago=2, area=None, poster="broker", rng=None):
    """
    NB: area and posted_date default to something DIFFERENT for every row.
    Distinct homes that share a floor area and a posting date are exactly
    what the cross-post rule merges, so generating them identical would make
    every scenario collapse into a handful of comparables for the right
    reason and the wrong one.
    """
    rng = rng or random
    p = portal or rng.choice(PORTALS)
    if area is None:
        area = 1000 + (i * 25) % 400
    if posted_ago is None:
        posted_ago = 8 + (i * 3) % 12
    return {
        "listing_id": f"SY-{i:04d}",
        "source": p,
        "posted_date": (SNAPSHOT - timedelta(days=posted_ago)).isoformat(),
        "last_seen_date": (SNAPSHOT - timedelta(days=seen_ago)).isoformat(),
        "society": society,
        "locality": LOCALITY,
        "bhk": bhk,
        "furnishing": furnishing,
        "area_sqft": area,
        "rent": int(rent),
        "deposit": int(rent) * 5,
        "photo_count": rng.randint(3, 18),
        "poster_type": poster,
    }


def spread(rng, n, centre=59500, width=1500):
    """
    A believable rent cluster. Symmetric on purpose; skew is a scenario.

    width is deliberately tight (about 2.5% of centre). At 3000 the control
    case scored LOW on spread alone, which made every scenario look degraded
    before its own defect was applied. The case packet's own 90% interval is
    3.4% of the median, so this is the realistic end.
    """
    return [int(round(rng.gauss(centre, width) / 500) * 500) for _ in range(n)]


# ---------------------------------------------------------------------------
# SCENARIOS
# ---------------------------------------------------------------------------

def sc_clean(rng):
    rows = [row(i, r, portal=PORTALS[i % 4], rng=rng)
            for i, r in enumerate(spread(rng, 24), start=1)]
    return rows, deal(), (
        "A healthy pull: 24 comparables, four portals, no injected defect. "
        "The control case. If this one refuses, something is wrong with the "
        "engine rather than with the data."
    ), "publishes a benchmark at MEDIUM or better"


def sc_thin(rng):
    rows = [row(i, r, portal=PORTALS[i % 4], rng=rng)
            for i, r in enumerate(spread(rng, 4), start=1)]
    return rows, deal(), (
        "Only 4 comparables in scope. Below min_n_low, which is 6."
    ), "refuses outright: no benchmark published"


def sc_single_portal(rng):
    rows = [row(i, r, portal=("NoBroker" if i < 20 else "Housing"), rng=rng)
            for i, r in enumerate(spread(rng, 20), start=1)]
    return rows, deal(), (
        "20 comparables, 19 of them from one portal. The count looks healthy "
        "and the evidence is not: this is S5."
    ), "publishes, but the tier drops to LOW naming the dominant portal"


def sc_dedup_evasion(rng):
    """S1. Cross-posts whose posted dates differ by more than the tolerance."""
    rows, i = [], 1
    for r in spread(rng, 12):
        # A pair shares an area because it IS one home, twice.
        a = 1000 + (i * 25) % 400
        rows.append(row(i, r, portal="MagicBricks", posted_ago=20,
                        area=a, rng=rng))
        i += 1
        # The same home, re-listed elsewhere 5 days later. dup_posted_tolerance
        # is 2 days, so this pair should NOT be merged.
        rows.append(row(i, r, portal="NoBroker", posted_ago=15,
                        area=a, rng=rng))
        i += 1
    return rows, deal(), (
        "Every home is cross-posted twice with the posted dates 5 days apart, "
        "beyond the 2-day dedup tolerance. Each home therefore counts twice."
    ), "EXPECTED TO DEFEAT THE ENGINE: n is roughly double the true count"


def sc_bait(rng):
    """S2. Plausibly cheap rows that sit inside the distribution."""
    rows = [row(i, r, portal=PORTALS[i % 4], rng=rng)
            for i, r in enumerate(spread(rng, 18), start=1)]
    # Just below the cluster, not absurdly below. With a tight spread,
    # 51,000 would sit outside the distribution and the MAD test would catch
    # it, which would demonstrate the opposite of S2.
    for j, r in enumerate([56500, 56000, 57000, 55500], start=19):
        rows.append(row(j, r, portal="Housing", poster="unknown", rng=rng))
    return rows, deal(), (
        "Four lead-harvesting listings priced just below the cluster rather "
        "than absurdly below it. The MAD test cannot reach them because they "
        "sit inside the distribution."
    ), ("bait survives every filter and is counted as evidence, which is the "
        "defect. But 4 cheap rows in 22 barely move a MEDIAN, so the published "
        "rate is close to unchanged. The filter is defeated and the statistic "
        "absorbs it. That split is the finding: a mean would have moved")


def sc_ask_inflation(rng):
    rows = [row(i, r * 1.08, portal=PORTALS[i % 4], rng=rng)
            for i, r in enumerate(spread(rng, 22), start=1)]
    return rows, deal(), (
        "Every ask inflated 8% above what the home would actually let for. "
        "This is S3, and no listings-only signal separates it from a real "
        "market: days-on-market correlates with rent at only -0.16."
    ), ("publishes a confidently wrong benchmark. The robustness battery is "
        "the only thing that surfaces it, by bounding where the call flips")


def sc_alias_collision(rng):
    """S6 at scale: one builder prefix across genuinely different projects."""
    rows, i = [], 1
    for society, centre in [("Prestige Lakeview", 59500),
                            ("Prestige Lakeside", 74000),
                            ("Prestige Lake View", 59500)]:
        for r in spread(rng, 8, centre=centre, width=2000):
            rows.append(row(i, r, society=society, portal=PORTALS[i % 4],
                            rng=rng))
            i += 1
    d = deal(society="Prestige Lakeview")
    return rows, d, (
        "Three society names sharing a builder prefix. Two are the same "
        "development spelled differently and must merge. The third is a "
        "different project at a much higher rent and must NOT merge. v1's "
        "fuzzy matching at 0.82 merged all three."
    ), ("merges Lakeview with Lake View, keeps Lakeside separate. A wrong "
        "merge would raise n and the median together")


def sc_determinate_negotiate(rng):
    """
    The engine must not refuse whenever anything is ambiguous. Here the
    maintenance convention is just as unresolved, but both branches land on
    the same side of the benchmark, so the ambiguity changes nothing and a
    determinate answer is the correct output.
    """
    rows = [row(i, r, portal=PORTALS[i % 4], rng=rng)
            for i, r in enumerate(spread(rng, 22, centre=52000), start=1)]
    d = deal(base_rent=64000, maintenance=4000)
    return rows, d, (
        "The subject is well above the comps on BOTH readings of the "
        "maintenance convention: base 64,000 and all-in 68,000 against a "
        "benchmark near 52,000. The fork is still unresolved, but it no "
        "longer changes the call."
    ), "gives a determinate ABOVE MARKET call rather than refusing"



def sc_determinate_acquire(rng):
    """
    The mirror of the negotiate case, and the one that ends in a decision to
    sign. The subject is clearly cheaper than the comparables on BOTH readings
    of the maintenance question, so the ambiguity is immaterial and the engine
    answers plainly: the rent is defensible.
    """
    rows = [row(i, r, portal=PORTALS[i % 4], rng=rng)
            for i, r in enumerate(spread(rng, 22, centre=65000), start=1)]
    d = deal(base_rent=52000, maintenance=3000)
    return rows, d, (
        "The subject is well below the comps on BOTH readings: base 52,000 "
        "and all-in 55,000 against a benchmark near 65,000. The maintenance "
        "convention is just as unresolved as on the real deal, but here it "
        "cannot change the answer."
    ), "gives a determinate BELOW MARKET call: the rent is defensible, sign it"


def sc_broken(rng):
    rows = [row(i, r, portal=PORTALS[i % 4], rng=rng)
            for i, r in enumerate(spread(rng, 16), start=1)]
    bad = row(90, 61000, rng=rng)
    bad["last_seen_date"] = (SNAPSHOT - timedelta(days=40)).isoformat()
    bad["posted_date"] = (SNAPSHOT - timedelta(days=10)).isoformat()
    rows.append(bad)
    rows.append(row(91, 9000, rng=rng))
    rows.append(row(92, 240000, rng=rng))
    huge = row(93, 58000, bhk="1", area=2300, rng=rng)
    rows.append(huge)
    stale = row(94, 60000, seen_ago=70, rng=rng)
    rows.append(stale)
    return rows, deal(), (
        "16 good rows plus five deliberate defects: last_seen before posted, "
        "a 9,000 bait, a 240,000 bait, a 1BHK listed at 2,300 sqft, and a "
        "listing last seen 70 days ago."
    ), "benches all five with a rule id and a sentence, and keeps the 16"


SCENARIOS = {
    "clean-baseline": sc_clean,
    "thin-evidence": sc_thin,
    "single-portal": sc_single_portal,
    "dedup-evasion": sc_dedup_evasion,
    "bait-inside-distribution": sc_bait,
    "ask-inflation-8pc": sc_ask_inflation,
    "alias-collision": sc_alias_collision,
    "determinate-negotiate": sc_determinate_negotiate,
    "determinate-acquire": sc_determinate_acquire,
    "broken-records": sc_broken,
}


def deal(society="Lakeview Residences", base_rent=56000, maintenance=5000,
         furnishing="semi-furnished", bhk="2"):
    return {
        "_synthetic": "FABRICATED TEST DATA. Not a real Flent deal.",
        "deal_id": "SYNTH-0001",
        "snapshot": SNAPSHOT.isoformat(),
        "society": society,
        "locality": LOCALITY,
        "bhk": bhk,
        "furnishing": furnishing,
        "base_rent": base_rent,
        "maintenance": maintenance,
    }


def write(name, fn):
    # NOT hash(name): Python randomises string hashing per process, so that
    # would regenerate different data on every run. The engine's guarantee is
    # that it answers the same way twice, and a test harness that cannot
    # reproduce its own inputs cannot check that.
    rng = random.Random(zlib.crc32(name.encode()))
    rows, d, why, expect = fn(rng)
    d = dict(d, deal_id=f"SYNTH-{name}")
    path = os.path.join(OUT, name)
    os.makedirs(path, exist_ok=True)

    with open(os.path.join(path, "listings.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)

    with open(os.path.join(path, "deal.json"), "w") as fh:
        json.dump(d, fh, indent=2)
        fh.write("\n")

    with open(os.path.join(path, "README.md"), "w") as fh:
        fh.write(f"# {name}\n\n**SYNTHETIC. Every row here is fabricated.**\n\n"
                 f"{why}\n\n**Expected:** {expect}\n\n"
                 f"{len(rows)} listings.\n")
    return len(rows), expect


def check(name):
    """Score a scenario with the real engine and print what it actually did."""
    path = os.path.join(OUT, name)
    out = subprocess.run(
        [sys.executable, os.path.join(HERE, "trust_layer.py"),
         "--deal", os.path.join(path, "deal.json"),
         "--listings", os.path.join(path, "listings.csv")],
        capture_output=True, text=True,
    )
    text = out.stdout
    # The CLI always appends its own fully-furnished failure case. Read only
    # the primary run, or every scenario looks like it refused.
    cut = text.find("FAILURE CASE")
    if cut > 0:
        text = text[:cut]
    got = []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("Market rate") or (
                s.startswith("Confidence") and "(" in s):
            got.append(" ".join(s.split()))
        if "VERDICT: INSUFFICIENT EVIDENCE" in s:
            got.append("REFUSED: no benchmark")
        if s.startswith("CALL ") or s.startswith("ROBUSTNESS "):
            got.append(" ".join(s.split()))
    if out.returncode != 0:
        got.append(f"engine exited {out.returncode}: "
                   f"{(out.stderr or '').strip()[:120]}")
    return got or ["(no verdict lines found)"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true",
                    help="score each scenario and print what the engine did")
    args = ap.parse_args()

    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "README.md"), "w") as fh:
        fh.write(
            "# Stress data\n\n**Everything in this directory is SYNTHETIC.**\n"
            "It is generated by `trust-layer/generate_stress_data.py` to test "
            "the engine against inputs the case packet does not contain. None "
            "of it is evidence about the Bangalore rental market.\n\n"
            "Each folder holds a `listings.csv`, a `deal.json` and a README "
            "stating the defect injected and what the engine is expected to "
            "do. Two scenarios are expected to DEFEAT the engine; they are "
            "labelled, and they correspond to S1 and S2 in "
            "`trust-layer/FAILURES.md`.\n\nUpload any folder's two files at "
            "the platform's Upload page, or run:\n\n```\npython3 "
            "trust_layer.py --deal <folder>/deal.json --listings "
            "<folder>/listings.csv\n```\n"
        )

    print(f"writing {len(SCENARIOS)} scenarios to {OUT}\n")
    for name, fn in SCENARIOS.items():
        n, expect = write(name, fn)
        print(f"  {name:26} {n:3} rows   expected: {expect[:60]}")
        if args.check:
            for line in check(name):
                print(f"  {'':26}     actual: {line}")
            print()


if __name__ == "__main__":
    main()
