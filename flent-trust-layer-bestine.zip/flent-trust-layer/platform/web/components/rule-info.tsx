"use client";

import { Info } from "lucide-react";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import type { Rule } from "@/lib/api";

/**
 * The rule id with an explanation behind an info button.
 *
 * Click rather than hover: a hover tooltip is unreachable on a phone, and
 * this is the control that says why a listing was dropped, which is the one
 * thing a reviewer most needs on any device.
 *
 * The panel is portalled to <body> and positioned fixed. The ledger table
 * lives inside a scroll container, and an absolutely positioned panel would
 * be clipped by it.
 */
export function RuleInfo({ id, rule }: { id: string; rule?: Rule }) {
  // The anchor is stored, not the final position. The panel's height is not
  // known until it has rendered, and it decides whether the panel opens below
  // the button or above it.
  const [rect, setRect] = useState<DOMRect | null>(null);
  const [at, setAt] = useState<{ x: number; y: number } | null>(null);
  const btn = useRef<HTMLButtonElement | null>(null);
  const panel = useRef<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    if (!rect || !panel.current) return;
    const W = 300;
    const GAP = 6;
    const h = panel.current.offsetHeight;
    const room = window.innerHeight - rect.bottom - GAP - 8;
    // Flip above only when there is genuinely more room up there, so a panel
    // near the bottom of a long page does not get clipped.
    const flip = h > room && rect.top - GAP - 8 > room;
    setAt({
      x: Math.min(Math.max(8, rect.left), window.innerWidth - W - 8),
      y: flip
        ? Math.max(8, rect.top - h - GAP)
        : Math.min(rect.bottom + GAP, window.innerHeight - h - 8),
    });
  }, [rect]);

  useEffect(() => {
    if (!rect) return;
    const close = () => {
      setRect(null);
      setAt(null);
    };
    const away = (e: MouseEvent) => {
      if (
        !panel.current?.contains(e.target as Node) &&
        !btn.current?.contains(e.target as Node)
      ) {
        close();
      }
    };
    const esc = (e: KeyboardEvent) => e.key === "Escape" && close();
    document.addEventListener("mousedown", away);
    document.addEventListener("keydown", esc);
    // Any scroll moves the anchor out from under the panel.
    window.addEventListener("scroll", close, true);
    return () => {
      document.removeEventListener("mousedown", away);
      document.removeEventListener("keydown", esc);
      window.removeEventListener("scroll", close, true);
    };
  }, [rect]);

  if (!id) return <span className="text-muted-foreground">—</span>;

  function toggle() {
    if (rect) {
      setRect(null);
      setAt(null);
      return;
    }
    const r = btn.current?.getBoundingClientRect();
    if (r) setRect(r);
  }

  return (
    <span className="inline-flex items-center gap-1">
      <span className="font-mono text-[11.5px] text-muted-foreground">{id}</span>
      {rule && (
        <button
          ref={btn}
          onClick={toggle}
          aria-expanded={!!rect}
          aria-label={`What does rule ${id} do?`}
          className="text-muted-foreground transition hover:text-foreground"
        >
          <Info className="size-3.5" aria-hidden />
        </button>
      )}

      {rect &&
        rule &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            ref={panel}
            style={{
              left: at?.x ?? -9999,
              top: at?.y ?? -9999,
              width: 300,
              maxHeight: "min(70vh, 420px)",
              // Hidden for the one frame it takes to measure and place.
              opacity: at ? 1 : 0,
            }}
            className="fixed z-50 overflow-y-auto rounded-lg border border-border bg-card p-4 shadow-lg"
          >
            <div className="text-[13px] font-medium">{rule.name}</div>
            <div className="mt-0.5 text-[11px] tracking-[0.06em] text-muted-foreground">
              {id} · {rule.family}
            </div>
            <p className="mt-2.5 text-[12.5px] leading-relaxed text-muted-foreground">
              {rule.does}
            </p>
            <p className="mt-2 border-t border-border pt-2 text-[12.5px] leading-relaxed text-muted-foreground">
              <span className="font-medium text-foreground">Why: </span>
              {rule.why}
            </p>
          </div>,
          document.body,
        )}
    </span>
  );
}
