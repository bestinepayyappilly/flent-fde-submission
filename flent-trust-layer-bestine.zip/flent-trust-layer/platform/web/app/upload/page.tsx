import { UploadForm } from "@/components/upload-form";

export const metadata = {
  title: "Score your own pull · BOSS trust layer",
  description:
    "Upload a listings export and a deal record and score them through the same pipeline.",
};

export default function UploadPage() {
  return (
    <div className="px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
      <h1 className="text-[26px] font-semibold tracking-tight sm:text-[32px]">
        Score your own pull
      </h1>
      <p className="mt-2 max-w-3xl text-[13.5px] leading-relaxed text-muted-foreground">
        Upload a listings export and a deal record. They go through the same
        pipeline, the same thresholds and the same refusal logic as the
        case-packet deal, because there is only one implementation. Nothing is
        stored: the files live in a temp directory for one request and are
        deleted afterwards.
      </p>

      <UploadForm />
    </div>
  );
}
