"use client";

import { ApproachTracker } from "@/components/approach-tracker";
import { rupees, type Pipeline } from "@/lib/api";

/**
 * The money on the deal page: what Flent pays the landlord, what comes back
 * from tenants, and how long the capital takes to return.
 *
 * None of this is the trust layer's work. It is BOSS's own arithmetic from
 * case-packet/boss-assessment.md, recomputed from its inputs and checked
 * against the figures it publishes. It sits here because the market rate is
 * only useful next to the cost it is judging, and because every input is an
 * estimate that ought to be visible beside the result it produces.
 */

const STATUS_STYLE: Record<string, string> = {
  RECORDED: "border-border bg-secondary text-muted-foreground",
  "RECORDED, NOT SIGNED": "border-border bg-secondary text-muted-foreground",
  "VERBAL, UNCONFIRMED": "border-refuse-border bg-refuse-bg text-refuse",
  HYPOTHESIS: "border-refuse-border bg-refuse-bg text-refuse",
  PLACEHOLDER: "border-refuse-border bg-refuse-bg text-refuse",
  ASSUMPTION: "border-refuse-border bg-refuse-bg text-refuse",
  "EXERCISE ASSUMPTION": "border-refuse-border bg-refuse-bg text-refuse",
};

function Tag({ s }: { s: string }) {
  return (
    <span
      className={`ml-1.5 whitespace-nowrap rounded border px-1.5 py-px text-[10px] font-medium ${
        STATUS_STYLE[s] ?? "border-border bg-secondary text-muted-foreground"
      }`}
    >
      {s.toLowerCase()}
    </span>
  );
}

function Card({
  title,
  sub,
  children,
}: {
  title: string;
  sub?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-lg border border-border bg-card p-5 sm:p-6">
      <h3 className="text-[15.5px] font-semibold tracking-tight">{title}</h3>
      {sub && (
        <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
          {sub}
        </p>
      )}
      <div className="mt-5">{children}</div>
    </section>
  );
}

export function DealEconomics({ p }: { p: Pipeline }) {
  const opening = p.scenarios[0];
  const revenue = opening.monthly_revenue;
  const cost = opening.owner_cost;
  const capex = p.inputs.capex.value as number;
  const uncovered =
    (p.inputs.landlord_deposit.value as number) -
    (p.inputs.tenant_deposits.value as number);

  const money = [
    { k: "Flent pays the landlord", v: rupees(cost), s: "every month, rent plus maintenance" },
    { k: "Tenants pay Flent", v: rupees(revenue), s: "two rooms, at 95% occupancy" },
    { k: "Left over each month", v: rupees(opening.contribution), s: "the margin on the deal" },
    { k: "Cash tied up", v: rupees(opening.capital_employed), s: `${rupees(capex)} furnishing plus ${rupees(uncovered)} deposit gap` },
    { k: "Time to get it back", v: `${opening.payback_months} months`, s: "at the current asking rent" },
  ];

  return (
    <div className="space-y-6">
      {/* These are the largest numbers on the site and the softest. Saying so
          once, up front, rather than only in a tag beside each input. */}
      <div className="rounded-lg border border-refuse-border bg-refuse-bg p-4 sm:p-5">
        <div className="text-[11px] font-medium tracking-[0.07em] text-refuse">
          READ THESE AS ESTIMATES, NOT AGREED FIGURES
        </div>
        <p className="mt-2 text-[13px] leading-relaxed text-refuse">
          Nothing on this tab is settled. The rent is recorded but unsigned, the
          tenant revenue is a pricing hypothesis with no tenants, the furnishing
          cost is a placeholder with no vendor quote, and the occupancy is an
          assumption chosen for the exercise. The payback figures are only as
          good as those four, and every one of them is labelled below.
        </p>
      </div>

      <Card
        title="What Flent pays, and what comes back"
        sub="BOSS's own figures for this deal, not the trust layer's. Shown here because a market rate only means something next to the cost it is judging."
      >
        <div className="grid gap-x-8 gap-y-4 sm:grid-cols-2 lg:grid-cols-3">
          {money.map((m) => (
            <div key={m.k}>
              <div className="text-[12.5px] text-muted-foreground">{m.k}</div>
              <div className="tnum mt-1 text-[20px] font-semibold tracking-tight">
                {m.v}
              </div>
              <div className="mt-0.5 text-[12px] text-muted-foreground">
                {m.s}
              </div>
            </div>
          ))}
        </div>
        <p className="mt-5 border-t border-border pt-4 text-[12.5px] leading-relaxed text-muted-foreground">
          The deposit gap is real cash: the landlord wants{" "}
          {rupees(p.inputs.landlord_deposit.value as number)} and tenants are
          assumed to put up {rupees(p.inputs.tenant_deposits.value as number)},
          so Flent funds the difference until the home is let.
        </p>
      </Card>

      <Card
        title="Ways to approach this deal"
        sub="The same home under each set of terms an acquirer could pursue, with what each one is worth and what it rests on."
      >
        <div className="space-y-3">
          {p.scenarios.map((sc) => (
            <div
              key={sc.id}
              className="rounded-lg border border-border p-4 sm:p-5"
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[14.5px] font-medium">{sc.name}</span>
                    <span
                      className={`rounded-full border px-2 py-0.5 text-[11px] font-medium ${
                        sc.status === "ACQUIRE"
                          ? "border-acquire-border bg-acquire-bg text-acquire"
                          : sc.status === "NEGOTIATE"
                            ? "border-refuse-border bg-refuse-bg text-refuse"
                            : "border-border bg-secondary text-muted-foreground"
                      }`}
                    >
                      {sc.status}
                    </span>
                    <Tag s={sc.evidence} />
                  </div>
                  <div className="mt-1 text-[12.5px] text-muted-foreground">
                    {sc.sub}
                  </div>
                </div>
                <div className="flex shrink-0 gap-6 text-right">
                  <div>
                    <div className="text-[11px] tracking-[0.06em] text-muted-foreground">
                      LEFT OVER
                    </div>
                    <div className="tnum mt-0.5 text-[15px] font-medium">
                      {rupees(sc.contribution)}
                      <span className="text-[12.5px] font-normal text-muted-foreground">
                        /mo
                      </span>
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] tracking-[0.06em] text-muted-foreground">
                      PAYBACK
                    </div>
                    <div className="tnum mt-0.5 text-[15px] font-medium">
                      {sc.payback_months} mo
                    </div>
                  </div>
                </div>
              </div>
              {sc.market_note && (
                <p className="mt-3 border-t border-border pt-3 text-[12.5px] leading-relaxed text-muted-foreground">
                  {sc.market_note}
                </p>
              )}
              <div className="mt-3 border-t border-border pt-3">
                <ApproachTracker id={sc.id} />
              </div>
            </div>
          ))}
        </div>
        <p className="mt-4 text-[12.5px] leading-relaxed text-muted-foreground">
          The best payback here rests on the weakest evidence: the ₹54,000 rent
          was offered on a phone call on 17 Aug and never put in writing. Chase
          that and the maintenance question together, and two of the three rows
          resolve at once.
        </p>
        <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
          Your marks are kept in this browser and go no further. Tracking this
          across a team needs a name against each decision and a log that
          cannot be edited afterwards, which is the same gap recorded against
          the override file. A confirmation nobody signed is how an assumption
          becomes a fact.
        </p>
      </Card>

      <Card
        title="The lease terms"
        sub="Recorded by Supply on the site visit. Recorded is not the same as signed."
      >
        <div className="grid gap-x-8 gap-y-0 sm:grid-cols-2 lg:grid-cols-3">
          {p.terms.map((t) => (
            <div
              key={t.label}
              className="flex items-baseline justify-between gap-3 border-b border-border/70 py-2"
            >
              <span className="text-[12.5px] text-muted-foreground">
                {t.label}
              </span>
              <span className="text-right text-[13px] font-medium">
                {t.value}
                {t.status !== "RECORDED" && <Tag s={t.status} />}
              </span>
            </div>
          ))}
        </div>
      </Card>

      <Card
        title="What these numbers rest on"
        sub="Every input behind the figures above, and how solid each one is. Most are estimates the assessment itself flags."
      >
        <div className="space-y-2.5">
          {Object.entries(p.inputs).map(([k, i]) => (
            <div
              key={k}
              className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 border-b border-border/70 pb-2.5 last:border-0"
            >
              <div className="min-w-0">
                <span className="text-[13px] font-medium">{i.label}</span>
                <Tag s={i.status} />
                <div className="mt-0.5 text-[12px] leading-relaxed text-muted-foreground">
                  {i.note}
                </div>
              </div>
              <span className="tnum shrink-0 text-[13px] font-medium">
                {typeof i.value === "number" && i.value <= 1
                  ? `${(i.value * 100).toFixed(0)}%`
                  : rupees(i.value as number)}
              </span>
            </div>
          ))}
        </div>
        <p className="mt-4 text-[12.5px] leading-relaxed text-muted-foreground">
          The payback figures are recomputed from these inputs on every run and
          checked against the numbers the assessment publishes, so a mistyped
          input shows up as a mismatch rather than as a plausible answer.
        </p>
      </Card>
    </div>
  );
}
