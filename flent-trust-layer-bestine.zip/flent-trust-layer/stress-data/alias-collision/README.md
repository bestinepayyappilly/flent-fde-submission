# alias-collision

**SYNTHETIC. Every row here is fabricated.**

Three society names sharing a builder prefix. Two are the same development spelled differently and must merge. The third is a different project at a much higher rent and must NOT merge. v1's fuzzy matching at 0.82 merged all three.

**Expected:** merges Lakeview with Lake View, keeps Lakeside separate. A wrong merge would raise n and the median together

24 listings.
