/**
 * Plain-English names for everything the engine calls by a code.
 *
 * The audience is Supply and Acquisition, not engineers. The engine's own
 * commitment is that every exclusion reads as "a sentence a non-engineer can
 * argue with", so the labels around those sentences should not need a
 * glossary either.
 *
 * The engine's codes are kept alongside the plain names rather than hidden,
 * because a reviewer who opens the CSV export needs to match the two up.
 */

export const STATUS_LABEL: Record<string, string> = {
  INCLUDED: "Used",
  OVERRIDE_IN: "Added by hand",
  OVERRIDE_OUT: "Removed by hand",
  BENCHED_INTEGRITY: "Bad record",
  OUT_OF_SCOPE: "Different kind of home",
  REDUNDANT: "Same home, listed twice",
  STALE: "Too old",
};

export const STATUS_HELP: Record<string, string> = {
  INCLUDED: "Counted towards the market rate.",
  OVERRIDE_IN: "A named person forced this back in.",
  OVERRIDE_OUT: "A named person took this out.",
  BENCHED_INTEGRITY: "The listing itself does not add up, so it cannot be trusted.",
  OUT_OF_SCOPE: "A real listing, but not the same kind of home as this one.",
  REDUNDANT: "The same home advertised on more than one site. Counting it twice would double its weight.",
  STALE: "Last seen too long ago. It may already be let.",
};

export function statusLabel(code: string) {
  return STATUS_LABEL[code] ?? code.replace(/_/g, " ").toLowerCase();
}

/** How much to trust the published rate. */
export const TIER_LABEL: Record<string, string> = {
  HIGH: "Strong",
  MEDIUM: "Reasonable",
  LOW: "Weak",
  INSUFFICIENT: "Not enough",
};

/** How hard the answer would be to change. */
export const ROBUSTNESS_LABEL: Record<string, string> = {
  ROBUST: "Holds up",
  CONDITIONAL: "Mostly holds up",
  FRAGILE: "Easily changed",
  REFUSED: "Not decided yet",
};

export const VERDICT_LABEL: Record<string, string> = {
  INSUFFICIENT_EVIDENCE: "NOT ENOUGH EVIDENCE",
  INSUFFICIENT: "NOT ENOUGH EVIDENCE",
  "ABOVE MARKET": "ABOVE MARKET",
  "BELOW MARKET": "BELOW MARKET",
  "AT MARKET": "AT MARKET",
};

export function verdictLabel(code: string) {
  return VERDICT_LABEL[code] ?? code.replace(/_/g, " ");
}

export const PROVENANCE_LABEL: Record<string, string> = {
  EVIDENCED: "MEASURED",
  ASSUMED: "JUDGEMENT CALL",
  CONSTANT: "FIXED",
};
