"use client";

import { useState } from "react";
import { ArrowRight } from "lucide-react";
import { DealEconomics } from "@/components/deal-economics";
import { SubjectEconomics } from "@/components/subject-economics";
import { EvidenceFloor } from "@/components/evidence-floor";
import { LedgerTable } from "@/components/ledger-table";
import {
  pct,
  rupees,
  type DealSummary,
  type Pipeline,
  type Scored,
} from "@/lib/api";
import {
  PROVENANCE_LABEL,
  ROBUSTNESS_LABEL,
  TIER_LABEL,
} from "@/lib/labels";

// Short labels on purpose: seven tabs at full length overflowed the strip
// and quietly scrolled, so the last ones were invisible.
const TABS = [
  "Overview",
  "Money",
  "Removed",
  "Listings",
  "Stress test",
  "Rules",
  "Societies",
] as const;

function Card({
  title,
  sub,
  children,
}: {
  title?: string;
  sub?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-lg border border-border bg-card p-5 sm:p-6">
      {title && (
        <h3 className="text-[15.5px] font-semibold tracking-tight">{title}</h3>
      )}
      {sub && (
        <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
          {sub}
        </p>
      )}
      <div className={title ? "mt-5" : ""}>{children}</div>
    </section>
  );
}

/* ---------------------------------------------------------------- overview */

function Overview({ d }: { d: Scored }) {
  const b = d.benchmark;
  const f = d.fork;

  return (
    <div className="space-y-6">
      {b.median !== null ? (
        <Card
          title="The market rate"
          sub="We can say what similar homes are asking. That is a different question from whether this particular deal is a good price, and we answer them separately."
        >
          {/* Four stats with different numbers of lines. items-end lined up
              their BOTTOMS, which left the labels at four different heights.
              Subgrid puts every label in one row, every value in the next and
              every sub-line in the third, so the row reads across. */}
          <div className="grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-4 sm:grid-rows-[auto_auto_auto] sm:gap-y-1.5">
            <div className="sm:row-span-3 sm:grid sm:grid-rows-subgrid">
              <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
                MARKET RATE
              </div>
              <div className="tnum mt-1 self-end text-[30px] font-semibold leading-none tracking-tight sm:mt-0 sm:text-[36px]">
                {rupees(b.median)}
              </div>
              <div className="mt-1 text-[13px] text-muted-foreground sm:mt-0">
                per month
              </div>
            </div>

            <div className="sm:row-span-3 sm:grid sm:grid-rows-subgrid">
              <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
                LIKELY RANGE
              </div>
              <div className="tnum mt-2 self-end text-[16px] font-medium sm:mt-0">
                {rupees(b.ci?.[0])} – {rupees(b.ci?.[1])}
              </div>
            </div>

            <div className="sm:row-span-3 sm:grid sm:grid-rows-subgrid">
              <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
                HOW MUCH TO TRUST IT
              </div>
              <div className="mt-2 self-end text-[16px] font-medium sm:mt-0">
                {TIER_LABEL[b.tier] ?? b.tier}
              </div>
            </div>

            <div className="sm:row-span-3 sm:grid sm:grid-rows-subgrid">
              <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
                LISTINGS USED
              </div>
              <div className="tnum mt-2 self-end text-[16px] font-medium sm:mt-0">
                {b.n} homes · {b.sources.length} websites
              </div>
              <div className="mt-1 text-[12px] text-muted-foreground sm:mt-0">
                kept from the 86 we scraped
              </div>
            </div>
          </div>
          <p className="mt-5 border-t border-border pt-4 text-[13px] leading-relaxed text-muted-foreground">
            {b.tier_reason}. {b.owners} were posted by the owner rather than a
            broker.
          </p>
          {b.mean_with_bait !== null && (
            <p className="mt-3 text-[13px] leading-relaxed text-muted-foreground">
              <span className="font-medium text-foreground">
                Why we use the middle value, not the average:
              </span>{" "}
              the two fake listings we caught would have left the middle value
              at {rupees(b.median_with_bait)}, unchanged, but pulled the average
              from {rupees(b.mean)} to {rupees(b.mean_with_bait)}. One bad
              listing can move an average a long way. It barely moves the
              middle.
            </p>
          )}
        </Card>
      ) : (
        <Card
          title="No market rate"
          sub="There is not enough evidence to give you one, and saying so is the honest answer."
        >
          <EvidenceFloor
            survivors={d.verdict.survivors ?? []}
            floor={
              (d.policy.find((t) => t.name === "min_n_low")?.value as number) ??
              d.benchmark.n
            }
            dealId={d.deal.id}
          />

          <div className="mt-5">
            <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
              WHAT WOULD UNBLOCK THIS
            </div>
            <ul className="mt-2 space-y-1.5">
              {d.verdict.resolution?.map((r) => (
                <li key={r} className="text-[13.5px] leading-relaxed">
                  · {r}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-[13px] italic text-muted-foreground">
              {d.verdict.resolution_note}
            </p>
          </div>
        </Card>
      )}

      {f && (
        <Card
          title="The listings do not agree on what rent means"
          sub="Market operations, 18 Aug: “We do not capture maintenance reliably, so the listing rents are not always all-in.”"
        >
          <p className="text-[13.5px] leading-relaxed text-muted-foreground">
            Some of these listings quote rent with maintenance included and
            some quote it separately, and nothing in the data says which is
            which. Against the{" "}
            <span className="font-semibold text-foreground">
              same {rupees(f.median)} market rate
            </span>
            :
          </p>
          <div className="mt-5 grid gap-4 md:grid-cols-2">
            {[
              { k: "IF LISTINGS EXCLUDE MAINTENANCE", v: f.base },
              { k: "IF LISTINGS INCLUDE MAINTENANCE", v: f.all_in },
            ].map(({ k, v }) => (
              <div
                key={k}
                className={`rounded-lg border p-5 ${
                  v.above
                    ? "border-refuse-border bg-refuse-bg"
                    : "border-acquire-border bg-acquire-bg"
                }`}
              >
                <div className="text-[11px] font-medium tracking-[0.06em] opacity-70">
                  {k}
                </div>
                <div className="tnum mt-3 text-[24px] font-semibold leading-none tracking-tight sm:text-[27px]">
                  {v.delta > 0 ? "+" : "−"}
                  {rupees(Math.abs(v.delta))}
                </div>
                <div className="tnum mt-1.5 text-[13px] font-medium opacity-80">
                  {pct(v.pct)} · comparing {rupees(v.compare)} a month
                </div>
                <div className="mt-3 border-t border-current/15 pt-3 text-[13px] font-semibold leading-relaxed">
                  {v.reading}
                </div>
                <div className="mt-1.5 text-[12.5px] leading-relaxed opacity-80">
                  {v.implication}
                </div>
              </div>
            ))}
          </div>
          <p className="mt-5 text-[13.5px] leading-relaxed">
            The same clean data gives opposite verdicts,{" "}
            <span className="font-bold">{rupees(f.spread)}/month</span> apart.{" "}
            <span className="text-muted-foreground">
              Cleaning the data further will not fix this. The information was
              never collected in the first place, so it is{" "}
              <span className="font-semibold text-foreground">
                missing, not noisy
              </span>
              . One question to the landlord settles it.
            </span>
          </p>
        </Card>
      )}
    </div>
  );
}

/* ----------------------------------------------------------------- cascade */

function Cascade({ d }: { d: Scored }) {
  const c = d.cascade;
  return (
    <Card
      title="What we removed, and why"
      sub="Worth knowing: throwing out the bad listings barely moved the rate. What it changed is how much you can trust it."
    >
      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full min-w-[440px] text-left text-[13px]">
          <thead className="bg-secondary/60 text-[11px] font-bold tracking-[0.07em] text-muted-foreground">
            <tr>
              <th className="px-5 py-3">STAGE</th>
              <th className="px-5 py-3 text-right">ROWS</th>
              <th className="px-5 py-3 text-right">CUT</th>
              <th className="px-5 py-3 text-right">MEDIAN</th>
            </tr>
          </thead>
          <tbody>
            {c.stages.map((s, i) =>
              s.divider ? (
                <tr key={i}>
                  <td
                    colSpan={4}
                    className="border-t border-dashed border-muted-foreground/40 px-5 py-2 text-center text-[11.5px] font-semibold italic tracking-wide text-muted-foreground"
                  >
                    above: not usable at all · below: real homes, just not like this one
                  </td>
                </tr>
              ) : (
                <tr key={i} className="border-t border-border">
                  <td className="px-5 py-3">{s.stage}</td>
                  <td className="tnum px-5 py-3 text-right font-bold">
                    {s.rows}
                  </td>
                  <td className="tnum px-5 py-3 text-right text-muted-foreground">
                    {s.cut ? s.cut : ""}
                  </td>
                  <td className="tnum px-5 py-3 text-right font-semibold">
                    {rupees(s.median)}
                  </td>
                </tr>
              ),
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        {[
          {
            n: c.not_evidence,
            t: "NOT USABLE",
            d: "broken, duplicated or too old",
          },
          {
            n: c.not_comparable,
            t: "A DIFFERENT HOME",
            d: "real listings, but not this kind of home",
          },
          { n: c.included, t: "USED", d: "homes like this one" },
        ].map((x) => (
          <div key={x.t} className="rounded-lg border border-border p-4">
            <div className="tnum text-[26px] font-semibold leading-none tracking-tight">
              {x.n}
            </div>
            <div className="mt-2 text-[11px] font-medium tracking-[0.06em] text-muted-foreground">
              {x.t}
            </div>
            <div className="mt-1 text-[12.5px] leading-relaxed text-muted-foreground">
              {x.d}
            </div>
          </div>
        ))}
      </div>

      <p className="mt-5 text-[13.5px] leading-relaxed text-muted-foreground">
        <span className="font-bold text-foreground">
          {c.raw} rows to {c.included}. The median moved{" "}
          {rupees(
            Math.abs(
              (d.benchmark.median ?? c.raw_median ?? 0) - (c.raw_median ?? 0),
            ),
          )}
          .
        </span>{" "}
        Cleaning did not change the rate. It changed how many homes are behind
        it. Of the {c.raw - c.included} listings removed, only{" "}
        {c.not_evidence} were actually unusable. The rest were perfectly good
        listings about a different kind of home, and it would be misleading to
        count those as junk we caught.
      </p>
    </Card>
  );
}

/* -------------------------------------------------------------- robustness */

function Robustness({ d }: { d: Scored }) {
  const r = d.robustness;
  if (!r)
    return (
      <Card title="No call to attack">
        <p className="text-[13.5px] leading-relaxed text-muted-foreground">
          The battery tests how hard a verdict is to overturn. This
          configuration publishes no verdict, so there is nothing to attack.
          That is the correct outcome, not a gap.
        </p>
      </Card>
    );

  return (
    <div className="space-y-6">
      <Card
        title="How hard would it be to change this answer?"
        sub="We do not judge an answer by how many listings are behind it. Every problem we know about (missed duplicates, fake listings, two buildings treated as one) makes that number go UP. So instead we try about twenty ways of being wrong and count how many the answer survives."
      >
        {/* Same subgrid treatment: ROBUSTNESS carries a second line that
            the other two do not, so the labels would otherwise drift. */}
        <div className="grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-3 sm:grid-rows-[auto_auto_auto] sm:gap-x-10 sm:gap-y-1.5">
          <div className="sm:row-span-3 sm:grid sm:grid-rows-subgrid">
            <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
              THE ANSWER
            </div>
            <div className="mt-1.5 self-end text-[19px] font-semibold tracking-tight sm:mt-0">
              {r.call}
            </div>
          </div>
          <div className="sm:row-span-3 sm:grid sm:grid-rows-subgrid">
            <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
              WHAT TO DO
            </div>
            <div className="mt-1.5 self-end text-[19px] font-semibold tracking-tight sm:mt-0">
              {r.action}
            </div>
          </div>
          <div className="sm:row-span-3 sm:grid sm:grid-rows-subgrid">
            <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
              HOW SOLID
            </div>
            <div className="tnum mt-1.5 self-end text-[19px] font-semibold tracking-tight sm:mt-0">
              {ROBUSTNESS_LABEL[r.tier] ?? r.tier}
            </div>
            <div className="tnum text-[12.5px] text-muted-foreground">
              {r.survived} of {r.total} checks passed
            </div>
          </div>
        </div>
      </Card>

      <Card
        title={`The call changes under ${r.flipped.length} attack${
          r.flipped.length === 1 ? "" : "s"
        }`}
        sub="Landlords often ask more than they settle for, and nothing in listings data tells you by how much. We cannot filter that out, so instead we measure how far it would have to go before it changed the answer."
      >
        <div className="space-y-3">
          {r.flipped.map((a) => (
            <div
              key={a.id}
              className="rounded-lg border border-refuse-border bg-refuse-bg p-4"
            >
              <div className="flex flex-wrap items-baseline gap-3">
                <span className="rounded bg-refuse/10 px-2 py-0.5 font-mono text-[11px] font-medium text-refuse">
                  {a.id}
                </span>
                <span className="text-[13px] font-medium">
                  {a.description}
                </span>
              </div>
              <div className="tnum mt-2 flex items-center gap-1.5 text-[13px] text-refuse">
                <ArrowRight className="size-3.5 shrink-0" aria-hidden />
                <span>
                  median {rupees(a.median)}, call becomes{" "}
                  <span className="font-medium">{a.verdict}</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

/* -------------------------------------------------------------- thresholds */

function Thresholds({ d }: { d: Scored }) {
  const counts = d.policy.reduce<Record<string, number>>((a, t) => {
    a[t.provenance] = (a[t.provenance] ?? 0) + 1;
    return a;
  }, {});
  return (
    <Card
      title="The numbers behind the rules"
      sub="Every rule has a number in it. Each one below says whether we measured it or simply chose it, and what goes wrong if it is set badly. Nothing here is hidden in the code."
    >
      <div className="mb-5 flex flex-wrap gap-2">
        {Object.entries(counts).map(([k, v]) => (
          <span
            key={k}
            className={`rounded-full border px-2.5 py-1 text-[11.5px] font-medium ${
              k === "EVIDENCED"
                ? "border-acquire-border bg-acquire-bg text-acquire"
                : k === "ASSUMED"
                  ? "border-refuse-border bg-refuse-bg text-refuse"
                  : "border-border bg-secondary text-muted-foreground"
            }`}
          >
            {v} {PROVENANCE_LABEL[k] ?? k}
          </span>
        ))}
      </div>
      <div className="space-y-3">
        {d.policy.map((t) => (
          <div key={t.name} className="rounded-lg border border-border p-4">
            <div className="flex flex-wrap items-center gap-3">
              <code className="font-mono text-[12.5px] font-medium">
                {t.name} = {String(t.value)}
              </code>
              <span
                className={`rounded-full border px-2 py-0.5 text-[10.5px] font-medium ${
                  t.provenance === "EVIDENCED"
                    ? "border-acquire-border bg-acquire-bg text-acquire"
                    : t.provenance === "ASSUMED"
                      ? "border-refuse-border bg-refuse-bg text-refuse"
                      : "border-border bg-secondary text-muted-foreground"
                }`}
              >
                {PROVENANCE_LABEL[t.provenance] ?? t.provenance}
              </span>
            </div>
            <p className="mt-2.5 text-[12.5px] leading-relaxed text-muted-foreground">
              <span className="font-semibold text-foreground">basis · </span>
              {t.basis}
            </p>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted-foreground">
              <span className="font-semibold text-foreground">if wrong · </span>
              {t.if_wrong}
            </p>
          </div>
        ))}
      </div>
    </Card>
  );
}

/* ----------------------------------------------------------------- aliases */

function Aliases({ d }: { d: Scored }) {
  const entries = Object.entries(d.aliases);
  const variants = entries.reduce((a, [, v]) => a + v.length, 0);
  return (
    <Card
      title="Matching up society names"
      sub={`${variants} raw spellings → ${entries.length} societies, with no alias table. Hand-listing works for five societies and is unmaintainable across Bangalore's ~27,000 listings. What generalises is the suffix vocabulary, not the society list.`}
    >
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {entries.map(([canon, vs]) => (
          <div key={canon} className="rounded-lg border border-border p-4">
            <div className="text-[13.5px] font-medium">{canon}</div>
            <ul className="mt-2.5 space-y-1">
              {vs.map((v) => (
                <li
                  key={v}
                  className="text-[12.5px] text-muted-foreground before:mr-1.5 before:content-['·']"
                >
                  {v}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <p className="mt-5 text-[13px] leading-relaxed text-muted-foreground">
        This is the highest-risk automation in the engine, so it is never trusted
        blindly. Merging two genuinely different societies would silently corrupt
        every benchmark drawn from either, and the failure is self-flattering
        because it produces a <span className="italic">larger</span> comp set. Clusters are written to{" "}
        <code className="font-mono text-[11.5px]">alias_registry.csv</code> for
        review, and a human overrides any of them by hand.
      </p>
    </Card>
  );
}

/* -------------------------------------------------------------------- root */

export function DealView({
  d,
  initialTab,
  econ,
  subjectEcon,
}: {
  d: Scored;
  initialTab?: string;
  /** The packet deal's full assessment. Only the packet deal has one. */
  econ?: Pipeline | null;
  /** Every other subject: the same arithmetic, from its rent alone. */
  subjectEcon?: DealSummary["economics"];
}) {
  // The pipeline table prints a payback for every subject, so a deal page
  // that drops the money entirely contradicts the screen the reader arrived
  // from. An upload still has no costing at all, and that is the only case
  // where the tab is genuinely absent.
  const money = Boolean(econ) || Boolean(subjectEcon);
  const tabs = money ? TABS : TABS.filter((t) => t !== "Money");
  const match = TABS.find(
    (t) => t.toLowerCase() === (initialTab ?? "").toLowerCase(),
  );
  const [tab, setTab] = useState<(typeof TABS)[number]>(match ?? "Overview");

  return (
    <>
      {/* Two elements on purpose. overflow-x-auto also makes overflow-y
          "auto", so a single element that both scrolls sideways and holds the
          tabs grows a vertical scrollbar the moment anything exceeds its
          height by a pixel. The outer box scrolls; the inner row never
          wraps. */}
      <div className="-mx-4 mt-7 overflow-x-auto px-4 pb-px sm:mx-0 sm:overflow-visible sm:px-0 sm:pb-0">
        <div className="flex min-w-max gap-5 border-b border-border sm:min-w-0 sm:gap-6">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => {
              setTab(t);
              // Deep-linkable, so a reviewer can send someone the exact tab
              // rather than "open it and click Ledger".
              const u = new URL(window.location.href);
              u.searchParams.set("tab", t.toLowerCase());
              window.history.replaceState(null, "", u);
            }}
            className={`-mb-px shrink-0 whitespace-nowrap border-b-2 pb-2.5 text-[13.5px] font-medium transition sm:text-[14px] ${
              tab === t
                ? "border-foreground text-foreground"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-7">
        {tab === "Overview" && <Overview d={d} />}
        {tab === "Money" &&
          (econ ? (
            <DealEconomics p={econ} />
          ) : (
            subjectEcon && (
              <SubjectEconomics
                e={subjectEcon}
                synthetic={d.deal.synthetic}
                variant={d.deal.variant}
              />
            )
          ))}
        {tab === "Removed" && <Cascade d={d} />}
        {tab === "Listings" && (
          <LedgerTable rows={d.listings} dealId={d.deal.id} rules={d.rules} />
        )}
        {tab === "Stress test" && <Robustness d={d} />}
        {tab === "Rules" && <Thresholds d={d} />}
        {tab === "Societies" && <Aliases d={d} />}
      </div>
    </>
  );
}
