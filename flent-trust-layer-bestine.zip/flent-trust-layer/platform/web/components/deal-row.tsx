"use client";

import { useRouter } from "next/navigation";

/**
 * A table row that navigates on click.
 *
 * A <tr> cannot legally sit inside an <a>, so the row carries the click
 * handler and the cells keep a real <Link> for keyboard and screen-reader
 * users. Clicking selected text does not navigate.
 */
export function DealRow({
  href,
  children,
}: {
  href: string;
  children: React.ReactNode;
}) {
  const router = useRouter();

  return (
    <tr
      onClick={() => {
        if (window.getSelection()?.toString()) return;
        router.push(href);
      }}
      className="cursor-pointer border-b border-border last:border-0 hover:bg-secondary/40"
    >
      {children}
    </tr>
  );
}
