"use client";

import { PipelineView } from "@/components/pipeline";
import { ApiError, PipelineSkeleton } from "@/components/skeleton";
import { getDeals, getPipeline } from "@/lib/api";
import { useApi } from "@/lib/use-api";

/**
 * The deals overview, fetched in the browser on mount.
 *
 * Both calls go out together: the pipeline economics and the deal list are
 * independent, and waiting for one before starting the other would double the
 * time to first number for no reason.
 */
export function PipelineClient() {
  const { data, error, loading, reload } = useApi(
    () => Promise.all([getPipeline(), getDeals()]),
    [],
  );

  if (loading) return <PipelineSkeleton />;
  if (error) return <ApiError error={error} onRetry={reload} />;
  if (!data) return <PipelineSkeleton />;

  const [pipeline, deals] = data;
  return (
    <div className="px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
      <PipelineView p={pipeline} deals={deals} />
    </div>
  );
}
