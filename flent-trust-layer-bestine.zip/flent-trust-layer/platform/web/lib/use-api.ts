"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Fetch on mount, with the three states a screen actually has.
 *
 * The pages used to be server components, which meant every navigation went
 * Vercel -> Railway -> scoring -> HTML before the browser painted anything.
 * The shell is static; only the numbers are not. So the shell renders
 * immediately and the numbers arrive into a skeleton.
 *
 * `error` is a first-class state rather than a thrown exception, because the
 * API is a separate deployment that can be asleep, redeploying or down, and a
 * blank page is a worse answer than a legible failure with a retry.
 */
export type ApiState<T> = {
  data: T | null;
  error: string | null;
  loading: boolean;
  /** Re-runs the fetch. Bound to the retry button on the error state. */
  reload: () => void;
};

export function useApi<T>(
  fetcher: () => Promise<T>,
  deps: readonly unknown[],
): ApiState<T> {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [nonce, setNonce] = useState(0);

  // The fetcher is a new closure on every render. Keeping it in a ref means
  // `deps` alone decides when to refetch, so callers can pass an inline arrow
  // without spinning.
  const ref = useRef(fetcher);
  ref.current = fetcher;

  useEffect(() => {
    let live = true;
    setLoading(true);
    setError(null);
    ref
      .current()
      .then((d) => {
        // A navigation away mid-flight must not write into a dead component,
        // and a slow first request must not overwrite a fast second one.
        if (live) setData(d);
      })
      .catch((e: unknown) => {
        if (live) setError(e instanceof Error ? e.message : String(e));
      })
      .finally(() => {
        if (live) setLoading(false);
      });
    return () => {
      live = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, nonce]);

  const reload = useCallback(() => setNonce((n) => n + 1), []);

  return { data, error, loading, reload };
}
