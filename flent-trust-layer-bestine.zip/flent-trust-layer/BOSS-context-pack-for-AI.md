# BOSS candidate AI context pack

This file accompanies the Forward Deployed Engineer take-home, **Help us decide which homes are worth betting on**. It explains Flent and BOSS in enough detail for a useful brainstorming session with Claude, GPT, or another AI assistant. Paste the whole file into your assistant, then use the prompt at the end.

This is product context, not an answer to the assignment. You are still responsible for the choices, assumptions, calculations, and final work you submit. Disclose how you used AI.

The assignment asks you to pick **one** of three real problem statements and produce three artifacts, submitted within seven days:

1. an approach brief: how you would attack the problem (max 4 pages or 8 slides);
2. a proof of work: the assumption your approach depends on most, proven end to end, deliberately including one failure case (five minutes to review);
3. an execution plan: one parent issue and 5-8 ordered sub-issues for the first release, written as you would in Linear.

There is no hour cap; how you spend the time is your call.

The three problem statements, in the assignment's words:

- **Problem 1 - The market data lies to us.** Scraped marketplace listings (MagicBricks, NoBroker, Housing and others) set a home's market rate, and a meaningful portion of them is not useful evidence: stale listings that already rented, duplicates posted by several brokers at different rents, bait prices, aspirational asks, and mislabeled attributes. Build a trust layer for market listings: identify records you would trust less, flag or remove them, preserve the reason behind every decision, and turn the surviving evidence into a market-rate estimate with an explicit confidence level. When there is not enough evidence, say exactly that instead of manufacturing certainty. Start with `case-packet/listings.csv`.
- **Problem 2 - We never find out whether we were right.** Every recommendation contains predictions (what the home will rent for, how quickly it fills, when it recovers its upfront cost), but outcomes end up across dashboards, Slack threads and people's memories and are rarely put back beside the assumptions made at signing. Build the feedback loop: capture what actually happened to every signed home, compare it with what BOSS predicted at acquisition, and show where estimates systematically run high or low. Also say where the comparison breaks; not every decision has a clean ground-truth outcome. Start with `case-packet/outcomes.csv`, which deliberately includes censored and missing actuals.
- **Problem 3 - Nobody signs off on "the system said so".** The person signing is right to challenge the recommendation: why this call, what if the achievable rent is INR 2,000 lower, which parts are we least sure about. A single blended score cannot answer that. Build the decision page: one view that shows what drove the recommendation, what is confirmed, what was assumed, what is still missing, where people disagree, and what would have to change to flip the call - clear enough that someone from the Supply team could walk a founder through the deal without opening another spreadsheet. Start with `case-packet/boss-assessment.md` and trace it back to the deal, comments, listings and photos.

## 1. Flent's business in plain terms

Flent operates rental homes in Bangalore. It leases homes from landlords, prepares and furnishes them, and rents them to tenants.

The basic economics are:

- Flent pays fixed rent to the landlord.
- Tenants pay rent to Flent.
- Flent spends money upfront on furnishing, repairs, deposits, and acquisition.
- The deposit works like this: Flent pays the landlord's deposit upfront when it signs, then recovers it as tenants pay their own deposits. Whatever the tenant deposits do not cover stays locked in the home as capital.
- Flent earns the difference between tenant revenue and the cost of operating the home.

The main risk appears before demand is proven. Once Flent signs a landlord lease, rent and capital commitments begin, and Flent carries the occupancy risk explicitly: if the home fills later than underwritten, each empty day of rent is paid from Flent's own P&L. Roughly ten days of vacancy pushes that home's breakeven out by about a month. If tenants pay less than expected, Flent carries that downside too.

### A simplified example

Assume a 2BHK has two lettable rooms. The figures below are made up for explanation. They are not case-packet data or Flent policy.

| Item | Illustrative value |
|---|---:|
| Tenant rent for the whole home | INR 60,000/month |
| Planning occupancy | 95% |
| Landlord rent | INR 40,000/month |
| Maintenance | INR 4,000/month |
| Furnishing capex | INR 120,000 |
| Landlord deposit | INR 120,000 |
| Tenant deposit | INR 100,000 |

At 95% occupancy, planned tenant revenue is INR 57,000. After landlord rent and maintenance, the monthly contribution is INR 13,000, or INR 6,500 per lettable room. The uncovered deposit is INR 20,000, so simplified capital employed is INR 140,000. At INR 13,000 of monthly contribution, simple payback is about 10.8 months.

A real decision needs more care. First-fill timing, furnishing level, market evidence, demand confidence, property quality, and missing information can all change the read.

## 2. What BOSS is

BOSS is Flent's internal acquisition decision system. It helps the acquisition owner decide whether a proposed landlord deal is worth pursuing and on what terms.

Deals can begin as unstructured Slack messages. BOSS turns the available information into a structured deal record, asks for missing inputs, calculates the economics, compares the property with market and demand evidence, and presents a recommendation.

BOSS can also answer questions inside the deal's Slack thread. It must stay grounded in the stored deal facts. If the answer needs a number that is not available, it says what is missing instead of inventing it.

Some recommendations are provisional because important inputs have not been confirmed. A named person always authorises an acquisition. BOSS does not sign a lease, contact a landlord, or commit capital.

## 3. The people involved

### Supply team

Finds properties, speaks with landlords, records commercial terms, visits homes, and owns the deal process.

### Product or property team

Estimates furnishing and repair work, reviews property condition, and contributes quality ratings.

### Demand team

Estimates achievable tenant rent, demand strength, likely days to let, and customer objections.

### Acquisition owner

Reviews the recommendation and evidence, makes the final decision, and owns the outcome.

## 4. The four outcomes

### ACQUIRE

The property and commercial terms clear the required checks. BOSS explains why the deal works and what still needs to close before signing.

### NEGOTIATE

The property may work, but the current terms do not. A useful NEGOTIATE outcome gives the team a target landlord rent and a walk-away point.

### HOLD

There is not enough reliable information to make the call. BOSS lists the missing or conflicting inputs and who should resolve them.

### PASS

The deal has a hard policy failure or does not work within reasonable commercial terms.

## 5. The evidence BOSS works with

BOSS keeps evidence types separate because they carry different levels of trust.

### The deal terms (the landlord's ask, recorded by the Supply team)

- property, locality, society, BHK, and the number of rooms Flent can rent out (Flent often lets a home room by room)
- the rent ask, and the cost per room it implies
- the security deposit ask; anything over three months' rent counts against the deal, because it is Flent's money parked and blocked
- escalations: how much the rent steps up each year
- rent-free days before Flent's rent starts, plus key-handover and rent-start dates
- furnishing capex: what Flent will spend to furnish and fix the home before anyone moves in
- any custom terms: lock-ins, exit clauses, restrictions on use
- one-time acquisition costs where relevant

From these, together with the market and demand evidence below, BOSS works out three benchmarks: the margin opportunity (profit per room per month at the ask, and the rent at which the deal stops working), the expected time to rent the home out, and a risk level of high, medium, or low. The longer a home is likely to sit empty, the wider the loss; a home signed above market rate is harder to rent out at all.

### Market estimates

- comparable listings with similar location, BHK, and furnishing
- asking rent and asking rent per room
- distance and similarity to the subject property
- sample size, age of each listing, and spread across the sample
- median market benchmark
- difference between the landlord's ask and the market benchmark
- target or excluded society status

Public listings show asking prices, not completed transactions. A small, stale, or inconsistent comparable set should carry less confidence.

### Demand signals

- expected tenant rent as a low, target, and high range
- enquiries, visits, and visit-to-booking conversion
- expected days to let
- common customer objections and competitor losses
- sample size, recency, and the geographic grain of the data

Demand evidence is often thin. A useful system shows the sample and confidence beside the conclusion.

### Property-quality judgments

Flent's current model looks at seven factors. Roughly in order of how much they matter to us (the exact weights are internal, and you do not need to reproduce them):

| Factor | Typical evidence |
|---|---|
| Approach and access | Road, entrance, safety, parking, surrounding approach |
| Bathrooms | Condition, usability, plumbing, attached or dedicated access |
| Sunlight and ventilation | Daylight, airflow, room exposure |
| View and noise | Outlook, privacy, traffic, construction noise |
| Space | Room size and usable layout |
| Fixtures and condition | Kitchen, electricals, plumbing, finish |
| Floor and access | Floor level, lift, and power backup |

The first three carry the most weight, view and noise sit in the middle, and the last three matter least. These are human judgments supported by visits, photos, videos, and documents. Unknown factors should remain unknown.

## 6. The measures a decision may surface

The assignment does not require Flent's production formulas. These concepts explain what the current product is trying to make inspectable.

### Market deviation

How far the landlord's rent sits above or below a credible comparable-market benchmark.

### Occupancy-adjusted GPU

GPU means gross profit per lettable room per month. In simplified form:

`occupancy-adjusted GPU = (tenant rent x occupancy - landlord rent - maintenance) / lettable rooms`

The current system can also account for the first-fill period separately. The important product principle is that every line in the calculation can be checked.

### Capital employed

`capital employed = capex + max(0, landlord deposit - tenant deposit)`

Other one-time costs may be shown separately depending on the chosen model.

### Payback

`payback in months = capital employed / total monthly occupancy-adjusted contribution`

Furnishing level matters because a more fully furnished home generally needs a faster payback to justify the upfront spend.

### Negotiation target

The landlord rent at which the deal clears the chosen economic limits. A walk-away point may also be capped near the market benchmark so an economic calculation cannot justify paying far above the market.

### Deal quality and risk

A readable synthesis of economics, location and market evidence, demand, property quality, and data gaps. In the current interface this synthesis is a display aid, not a substitute for the underlying decision logic.

## 7. What can change a decision

The exact production rules are not part of this exercise. Conceptually, BOSS distinguishes three roles:

### Deciding inputs

Inputs that can move the recommendation, such as landlord rent, expected tenant rent, maintenance, capex, deposits, lettable rooms, occupancy or fill assumptions, hard property failures, and credible market constraints.

### Context inputs

Useful information that explains the deal but may not move the recommendation by itself, such as longer-term return views, team notes, or a display-only quality summary.

### Hard constraints

Conditions that make a property unacceptable regardless of headline economics. Examples could include a serious safety problem, unusable access, or a landlord condition that prevents the home from being prepared for tenants.

A candidate should define these roles for their proposed version of BOSS and explain why.

## 8. Why the problem is hard

- A comparable listing is an asking price, not a signed transaction.
- Marketplace listings contain false positives: homes that already rented but stay listed, the same flat posted by several brokers at different rents, bait prices posted to harvest leads, and mislabeled BHK, furnishing, or society names that refuse to match across sources.
- After honest filtering, a micromarket can thin out to a handful of credible comps, so a single bad listing can move the benchmark materially.
- The most similar comparable may be old; the freshest may be less similar.
- Rent cycles and hikes are micromarket-specific and reset every year, so Flent's own portfolio history is a base for pricing, not an answer.
- Demand samples can be small, stale, or measured at the wrong geographic level.
- Expected tenant rent may come from a team judgment before any tenant has committed.
- Photos can miss noise, smells, access problems, and hidden damage.
- Team members may disagree.
- Defaults can keep a calculation running while making the recommendation provisional.
- A single blended score can hide which fact actually decided the deal.
- Commercial terms can change during negotiation, so the recommendation must be reproducible when inputs change.

## 9. Product guardrails

1. Never fabricate a missing field.
2. Keep facts, estimates, signals, and judgments visibly separate.
3. Cite the source and freshness of evidence where possible.
4. Make assumptions and defaults visible.
5. Use deterministic code for arithmetic and rules. The same confirmed inputs should produce the same result.
6. Use AI to read messy material, extract candidate inputs, summarise evidence, or explain a result. AI output should carry confidence and citations and should not silently enter the decision engine.
7. Show disagreement instead of averaging it away.
8. Keep the recommendation inspectable after the fact.
9. A named human owns every capital decision.

## 10. Vocabulary

- **BHK:** Bedrooms, hall, and kitchen. A 2BHK usually has two bedrooms.
- **Lettable room:** A room Flent can rent to a tenant. It may be different from the advertised bedroom count if a room is not usable.
- **GPU:** Gross profit per lettable room per month.
- **Occupancy-adjusted:** Calculated after applying a planning assumption for vacancy or occupancy.
- **Capex:** Upfront capital spent to furnish, repair, or prepare the home.
- **CAC:** A one-time acquisition cost. If you use it, state exactly which costs it contains and where it enters your model.
- **Rent-free period:** Time after handover when landlord rent is not yet charged.
- **First fill:** The period between taking control of a home and placing the first tenants.
- **Comparable or comp:** A similar nearby home used to estimate the market rent.
- **Micromarket:** A small local rental market with similar demand and pricing behaviour.
- **Society:** A named apartment development or residential community.
- **Provisional verdict:** A recommendation produced with unconfirmed inputs or defaults. It should not be treated as final.

## 11. What this file leaves out

This file includes a ranked list of quality factors and one illustrative example that uses a made-up 95% occupancy assumption. It does not include Flent's exact economic thresholds, quality weights, private datasets, full engine code, or a preferred technical architecture. Do not try to reconstruct them. The assignment tests your ability to choose and justify a useful first version.

## 12. Prompt for your AI assistant

Copy the prompt below after sharing this file:

```text
You are my brainstorming partner for a Forward Deployed Engineer take-home. The context above describes Flent and its internal tool BOSS. My task is to pick one of the three problem statements (market-data false positives, the outcome feedback loop, or the decision surface), write a short approach brief, prove the riskiest assumption end to end with one failure path, and plan the first release as one parent issue and 5-8 ordered sub-issues.

Start by asking me which problem I picked and why, then sharp questions about my interpretation of the business risk, the users, and the decision BOSS should improve. Do not jump straight to a solution.

As we work:
- separate facts, estimates, signals, and judgments
- stress-test how my design handles missing, stale, or conflicting evidence
- identify edge cases that could change or block a property decision
- challenge which parameters I allow to change the recommendation
- challenge whether my proof-of-concept slice is the riskiest useful thing to prove
- test whether my build order learns something useful early
- check that every issue has a bounded outcome, dependency, acceptance criteria, and proof
- point out where I am hiding uncertainty behind a score or a polished interface

Do not write the assignment submission for me. Do not invent facts about Flent beyond the supplied context. If I ask for Flent's real thresholds, remind me to choose and justify my own. Push back when my reasoning is thin. At the end of each discussion, summarise the decisions I made, the assumptions still open, and the next question I should answer.
```
