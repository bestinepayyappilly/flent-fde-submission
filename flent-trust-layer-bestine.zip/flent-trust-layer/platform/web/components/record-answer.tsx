"use client";

import { Loader2, RotateCcw, Users } from "lucide-react";
import { useState } from "react";
import { API, type AnswerEntry, type Choice } from "@/lib/api";

/**
 * Record what the landlord actually said.
 *
 * This closes the loop the site was missing. The engine names the question, a
 * person goes and asks it, and until the answer lands somewhere shared, the
 * refusal has nowhere to go. Recording it re-scores the deal: the two
 * readings collapse to one and the verdict becomes a decision.
 *
 * A name is required. An answer that changes a deal from "we do not know" to
 * "sign it" without anyone's name against it is the laundering path
 * FAILURES.md warns about, so the field is not optional and the trail is
 * append-only.
 */
export function RecordAnswer({
  dealId,
  answer,
  log,
  choices,
  onRecorded,
  rescoring = false,
}: {
  dealId: string;
  answer: AnswerEntry | null;
  log: AnswerEntry[];
  choices: Record<string, Choice>;
  /** Re-runs the engine against the answer just written. */
  onRecorded?: () => void;
  /** True while that re-run is in flight. */
  rescoring?: boolean;
}) {
  const [who, setWho] = useState("");
  const [note, setNote] = useState("");
  const [picked, setPicked] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function send(value: string) {
    if (!who.trim()) {
      setError("Put your name against it. An answer nobody signed is not evidence.");
      return;
    }
    setBusy(value);
    setError(null);
    try {
      const res = await fetch(`${API}/api/deals/${dealId}/answer`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ answer: value, who: who.trim(), note: note.trim() }),
      });
      if (!res.ok) {
        setError((await res.json()).detail ?? "Could not record that.");
      } else {
        setNote("");
        setPicked(null);
        // The deal is scored in the browser now, so a server refresh would
        // change nothing. Ask the page to re-run the engine instead.
        onRecorded?.();
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(null);
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
          {answer ? "THE ANSWER, RECORDED" : "GOT THE ANSWER? RECORD IT"}
        </div>
        <span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
          <Users className="size-3.5" aria-hidden />
          shared with the team
        </span>
      </div>

      {answer ? (
        <>
          <p className="mt-3 text-[14.5px] font-medium leading-snug">
            {choices[answer.answer]?.label ?? answer.answer}
          </p>
          <p className="mt-1.5 text-[12.5px] text-muted-foreground">
            {answer.who} · {answer.at.slice(0, 10)}
            {answer.note && ` · ${answer.note}`}
          </p>
          <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-border pt-4">
            <input
              value={who}
              onChange={(e) => setWho(e.target.value)}
              placeholder="Your name"
              className="w-[150px] rounded-md border border-border bg-card px-3 py-1.5 text-[12.5px] outline-none focus:border-foreground"
            />
            <button
              onClick={() => send("withdrawn")}
              disabled={busy !== null || rescoring}
              className="inline-flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-[12px] font-medium text-muted-foreground transition hover:text-foreground disabled:opacity-40"
            >
              {busy || rescoring ? (
                <Loader2 className="size-3.5 animate-spin" aria-hidden />
              ) : (
                <RotateCcw className="size-3.5" aria-hidden />
              )}
              {busy
                ? "Saving…"
                : rescoring
                  ? "Re-scoring…"
                  : "Withdraw this answer"}
            </button>
          </div>
        </>
      ) : (
        <>
          <p className="mt-3 text-[13px] leading-relaxed text-muted-foreground">
            Once someone has asked the landlord, record what they said. It
            re-scores the deal for everyone.
          </p>

          {/* A plain form: choose, sign, submit. The first version fired on
              the choice itself and rejected it for a missing name that was
              asked for further down the card, which is a dead end. */}
          <fieldset className="mt-4">
            <legend className="text-[12.5px] font-medium">
              1 · What did they say?
            </legend>
            <div className="mt-2 space-y-2">
              {Object.entries(choices).map(([key, c]) => (
                <label
                  key={key}
                  className={`flex cursor-pointer items-start gap-3 rounded-md border px-4 py-3 transition ${
                    picked === key
                      ? "border-foreground bg-secondary"
                      : "border-border hover:border-muted-foreground/50"
                  }`}
                >
                  <input
                    type="radio"
                    name="maintenance-answer"
                    checked={picked === key}
                    onChange={() => {
                      setPicked(key);
                      setError(null);
                    }}
                    className="mt-1 size-3.5 accent-black"
                  />
                  <span>
                    <span className="block text-[13.5px] font-medium">
                      {c.label}
                    </span>
                    <span className="mt-0.5 block text-[12px] text-muted-foreground">
                      {c.detail}
                    </span>
                    {c.preview && (
                      <span className="mt-1.5 block text-[12px]">
                        <span className="text-muted-foreground">
                          {c.preview} ·{" "}
                        </span>
                        <span
                          className={`font-medium ${
                            c.result === "ABOVE MARKET"
                              ? "text-refuse"
                              : "text-acquire"
                          }`}
                        >
                          {c.result}
                        </span>
                      </span>
                    )}
                  </span>
                </label>
              ))}
            </div>
          </fieldset>

          <div className="mt-4">
            <div className="text-[12.5px] font-medium">
              2 · Who is recording it?
            </div>
            <div className="mt-2 flex flex-wrap gap-2">
              <input
                value={who}
                onChange={(e) => setWho(e.target.value)}
                placeholder="Your name"
                className="w-[170px] rounded-md border border-border bg-card px-3 py-2 text-[12.5px] outline-none focus:border-foreground"
              />
              <input
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="How do you know? e.g. called the landlord, 8 Sep"
                className="min-w-[220px] flex-1 rounded-md border border-border bg-card px-3 py-2 text-[12.5px] outline-none focus:border-foreground"
              />
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <button
              onClick={() => picked && send(picked)}
              disabled={!picked || !who.trim() || busy !== null || rescoring}
              className="inline-flex items-center gap-2 rounded-md bg-foreground px-4 py-2 text-[13px] font-medium text-background transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-30"
            >
              {(busy || rescoring) && (
                <Loader2 className="size-3.5 animate-spin" aria-hidden />
              )}
              {busy
                ? "Recording…"
                : rescoring
                  ? "Re-scoring the deal…"
                  : "Record answer"}
            </button>
            <span className="text-[11.5px] text-muted-foreground">
              {!picked
                ? "Pick what they said."
                : !who.trim()
                  ? "Add your name. An answer nobody signed is not evidence."
                  : "This changes the deal for everyone."}
            </span>
          </div>
        </>
      )}

      {error && (
        <p className="mt-3 rounded-md border border-refuse-border bg-refuse-bg px-3 py-2 text-[12.5px] text-refuse">
          {error}
        </p>
      )}

      {log.length > 0 && (
        <details className="mt-4 border-t border-border pt-3">
          <summary className="cursor-pointer text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
            TRAIL · {log.length} {log.length === 1 ? "entry" : "entries"}
          </summary>
          <ul className="mt-2 space-y-1">
            {log
              .slice()
              .reverse()
              .map((e, i) => (
                <li key={i} className="text-[12px] text-muted-foreground">
                  {e.at.slice(0, 10)} · <span className="font-medium">{e.who}</span>{" "}
                  {e.answer === "withdrawn"
                    ? "withdrew the answer"
                    : `answered "${choices[e.answer]?.label ?? e.answer}"`}
                  {e.note && ` — ${e.note}`}
                </li>
              ))}
          </ul>
          <p className="mt-2 text-[11.5px] text-muted-foreground">
            Append-only: an answer can be superseded but never deleted.
          </p>
        </details>
      )}
    </div>
  );
}
