# CLAUDE.md — Flent FDE take-home, Problem 1

Working context for this build. Read this before touching anything here.

## What this is

Flent (Bangalore rental operator) FDE take-home. The brief offers three
problems; **we chose Problem 1 — the market-listing trust layer.** The packet
lives one directory up in `../case-packet/`; `../Flent-FDE-take-home-brief.pdf`
is the brief.

Three deliverables are required. Status:

| # | Deliverable | Limit | Status |
|---|---|---|---|
| 1 | Approach note | 4 pages / 8 slides | **done** — `../approach-note.pdf`, measured at 4 pages |
| 2 | Proof of work | 5 min to review | **done** — this folder + the deployed platform |
| 3 | Execution plan | 1 parent + 5–8 sub-issues | **done** — `../execution-plan.pdf`, FLT-1 + 8 subs |

`../README.md` is the submission entry point. `README.txt` is Flent's own; untouched.

PDFs are rendered with a stdlib markdown converter in the session scratchpad plus
Chrome headless `--print-to-pdf` (no pandoc on this machine). Two bugs it had, in
case it is rebuilt: emphasis spanning a wrapped line must be joined before inline
formatting, and `\*\*([^*]+)\*\*` cannot match a bold run containing italics.

**Deadline: 10 September 2026.** Packet arrived 3 Sep; seven calendar days.
Confirmed by the user on 7 Sep, so three days remain at that point.

Deliverable 2 was built first on purpose: the approach note and execution plan
should cite measured output, not claims. Every number in the note should come
from a run, not from memory.

## How to run

```
python3 trust_layer.py                        # score the case-packet deal
python3 trust_layer.py --deal other.json      # any other deal
python3 stress_test.py                        # attack it
```

Standard library only, Python 3.8+. No install step, and keep it that way —
"five minutes of something working" beats anything needing setup.

```
trust_layer.py   pipeline + reporting; POLICY block at the top
robustness.py    the v2 core: verdict-stability battery
stress_test.py   7 reproducible failure scenarios
outcomes_check.py  tests the premise against case-packet/outcomes.csv
deal.json        the deal as INPUT, not config
overrides.csv    a named human forces a listing in/out
aliases.csv      a named human overrides a society merge (optional, absent)
FAILURES.md      9 known defects — read this before claiming anything works
out/             ledger.csv, alias_registry.csv, ledger_failure_case.csv
```

## Current results — do not re-derive these

```
cascade    86 raw -> 82 -> 69 -> 61 -> 20 included
           25 rows were not evidence (broken/duplicate/stale)
           41 were valid listings about a different kind of home
benchmark  Rs 59,500, 90% CI Rs 58,000-60,000, MEDIUM, n=20
call       INSUFFICIENT / UNRESOLVED, robustness REFUSED (18 of 20 attacks)
           flips only under A6.8% and A6.10% (systematic ask-inflation)
failure    fully-furnished variant -> n=4 -> INSUFFICIENT EVIDENCE
stress     3 fixed · 2 bounded · 2 open (+2 structural, documented)
policy     4 EVIDENCED · 6 ASSUMED · 3 CONSTANT thresholds
```

## The three findings the submission rests on

1. **Cleaning is a null result.** 86 → 20 rows, median moves ₹500. Filtering
   does not fix the number; it collapses the sample. The product of a trust
   layer is the *confidence*, not the rate.
2. **The maintenance fork decides the deal.** Comps mix base-rent and all-in
   conventions. Against the same ₹59,500: base ask ₹56,000 reads BELOW market,
   all-in cost ₹61,000 reads ABOVE. Opposite verdicts, ₹5,000/month apart. Not
   noise — *missing information*, so no cleaning fixes it. Output is a refusal
   plus one question to the landlord.
3. **Confidence must not be a function of `n`.** Every defect — duplicates,
   bait, merged societies — *raises* `n`. v1 graded on `n`, so surviving junk
   bought confidence. v2 grades on how hard the call is to flip.

## Decisions already made — do not silently reverse

- **Dedup stays strict.** A looser rule gives n=17 and a median of ₹58,500,
  which lands exactly midway between the two maintenance branches. That
  symmetry is pretty and it is an **artifact of over-collapsing 7 distinct
  homes**. It was cut. Do not reintroduce it.
- **No fuzzy society matching.** Exact match on the suffix-stripped core.
  Fuzzy 0.82 merged Prestige Lakeview with Prestige *Lakeside*. Exact matching
  is strictly better here and deleted a threshold instead of tuning one.
- **`park` and `homes` are not society suffixes.** Adding `park` split Park
  Side Terrace from Parkside Terraces and silently created a sixth society.
- **Refuse on the action, not the label.** `AT MARKET` and `BELOW MARKET` mean
  the same decision. Only "negotiate" vs "no objection" justifies refusing.
- **Cluster representative = lowest rent.** Conservative in both directions the
  benchmark is used. The engine never flatters the deal.
- **Thresholds carry provenance.** Every POLICY entry declares EVIDENCED or
  ASSUMED plus what breaks if wrong. Adding a threshold without that metadata
  breaks the engine's own stated standard.

## Known open failures

Full detail in `FAILURES.md`. The four that are not fixed:

- **Aspirational bias (critical).** Undetectable from listings — days-on-market
  correlates with rent at −0.16. Bounded by sweeping inflation 2–10%; the call
  holds to 6% and flips at 8%. Only Flent's signed rents (Problem 2) can
  calibrate it. **This is a hard dependency of Problem 1 on Problem 2.**
- **`min_n` cliff.** Two fabricated rows turn the `INSUFFICIENT` failure case
  into a published ₹68,750. Battery surfaces it as FRAGILE; cliff remains.
- **Area basis.** Carpet vs built-up vs super built-up, ~30% apart. Same class
  as the maintenance fork — a unit ambiguity — and only that one instance is
  implemented.
- **Override file is an unaudited laundering path.** Needs identity and an
  append-only log; not fixable in a local script.

## The outcomes check — read this before defending the thesis

`outcomes_check.py` reads `../case-packet/outcomes.csv`, the only file in the packet
pairing a forecast with an actual. Across 10 cases observed to day 90:

```
tenant revenue   median 0.98 actual/plan   6 of 10 worse   p = 0.75
days to fill     median 1.23               8 of 10 worse   p = 0.11
payback months   median 1.15               8 of 10 worse   p = 0.11
```

**The pricing is close to right. The timing is not.** The overrun is skewed, not flat:
median 6 days, mean 12, with two of ten at 37 and 39 days (~3.7-3.9 months of payback
each at the packet's 10-days-per-month rate). Flent's own notes name the causes and
neither is a pricing error.

Caveats that must travel with the number: n=10, p=0.11 is **not** significant at 5%,
and excluding the still-filling case biases it optimistic. Evidence, not proof.

Consequence, already written into both documents: fill-time calibration should outrank
FLT-3. Approach note §5 leads with this; execution plan carries it under FLT-3 and
"What the outcomes check changes". **Do not quietly revert either to the
calibrate-the-market-rate-first framing.**

## Rules for this submission

From the brief's "what makes us stop reading" list, plus what the packet
demands:

- **Never invent evidence.** Anything not in the packet is an assumption and
  must be labelled. Synthetic rows must say so.
- **Do not overclaim.** The README reports a null result and a refusal as
  headline outputs. Resist the urge to dress either up.
- **Report corrections.** Two findings were withdrawn after being wrong (the
  equidistance artifact, the "removing any listing changes nothing" line). That
  visibility is a credibility asset, not an embarrassment — keep it.
- **AI disclosure is required.** The README carries a short note; keep it
  accurate and specific about where judgment entered.
- **Don't rebuild BOSS.** One narrow problem, done properly.

## Next steps

Nothing outstanding on the three deliverables. If work continues:

- The approach note sits exactly at 4 pages. Any addition needs a matching cut, and
  the page count must be re-measured, not estimated from word count — a 20-word cut
  moved nothing because the spill was an unbreakable block.
- FLT-3's demotion behind fill-time calibration is the newest claim in the
  submission and rests on n=10. If more outcome records appear, re-run
  `outcomes_check.py` before repeating the 23% figure.
