"use client";

import { rupees, type DealSummary } from "@/lib/api";

/**
 * The money on a deal that has no assessment of its own.
 *
 * The packet contains one costed deal. Every other subject here is either a
 * what-if on that record or a fabricated one, so none of them has a BOQ, a
 * landlord conversation or a tenant plan. What they do have is a rent, and
 * `economics.for_subject()` costs it with the packet's own operating
 * assumptions.
 *
 * That makes these figures comparable to each other and to the packet deal,
 * and nothing more. They are not forecasts, and the basis line says which
 * assumptions produced them rather than leaving the reader to guess how a
 * fabricated subject acquired a payback figure.
 *
 * The pipeline table already publishes these same numbers. Hiding them here
 * while showing them there is how one screen ends up disagreeing with
 * another, which is the failure this project exists to argue against.
 */
export function SubjectEconomics({
  e,
  synthetic,
  variant,
}: {
  e: NonNullable<DealSummary["economics"]>;
  synthetic: boolean;
  variant: boolean;
}) {
  const rows = [
    {
      k: "Flent pays the landlord",
      v: rupees(e.owner_cost),
      s: "every month, rent plus maintenance",
    },
    {
      k: "Tenants pay Flent",
      v: rupees(e.monthly_revenue),
      s: "derived from the owner cost, not from a tenant plan",
    },
    {
      k: "Left over each month",
      v: `${rupees(e.contribution)}/mo`,
      s: "the margin under these assumptions",
    },
    {
      k: "Cash tied up",
      v: rupees(e.capital_employed),
      s: "furnishing plus the deposit gap",
    },
    {
      k: "Time to get it back",
      v: e.payback_months === null ? "—" : `${e.payback_months} months`,
      s: "at this subject's asking rent",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="rounded-lg border border-refuse-border bg-refuse-bg p-4 sm:p-5">
        <div className="text-[11px] font-medium tracking-[0.07em] text-refuse">
          {synthetic
            ? "A FABRICATED SUBJECT, COSTED FROM THE PACKET'S ASSUMPTIONS"
            : "A WHAT-IF ON THE PACKET DEAL, NOT A SECOND ASSESSMENT"}
        </div>
        <p className="mt-2 text-[13px] leading-relaxed text-refuse">
          {synthetic
            ? "This home does not exist. It was written to give the trust layer a second subject to judge, so there is no BOQ, no landlord conversation and no tenant plan behind these figures."
            : "This is the packet deal with one field changed. The lease terms are the real ones; the costing is not a separate assessment."}{" "}
          Every number below is the packet&apos;s operating assumptions applied
          to this subject&apos;s rent. Useful for comparing subjects. Not a
          forecast, and not a substitute for underwriting.
        </p>
      </div>

      <section className="rounded-lg border border-border bg-card p-5 sm:p-6">
        <h3 className="text-[15.5px] font-semibold tracking-tight">
          What this subject would cost
        </h3>
        <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">
          The same arithmetic the packet deal gets, so the two can be read side
          by side.
        </p>

        <div className="mt-5 grid gap-x-8 gap-y-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((r) => (
            <div key={r.k}>
              <div className="text-[12.5px] text-muted-foreground">{r.k}</div>
              <div className="tnum mt-1 text-[20px] font-semibold tracking-tight">
                {r.v}
              </div>
              <div className="mt-0.5 text-[12px] text-muted-foreground">
                {r.s}
              </div>
            </div>
          ))}
        </div>

        <p className="mt-5 border-t border-border pt-4 text-[12.5px] leading-relaxed text-muted-foreground">
          Basis: {e.basis}. The revenue multiple is the one the packet deal
          implies, carried across unchanged rather than tuned per subject —
          which is why these compare honestly with each other and should not be
          read as a claim about any real home.
        </p>
      </section>
    </div>
  );
}
