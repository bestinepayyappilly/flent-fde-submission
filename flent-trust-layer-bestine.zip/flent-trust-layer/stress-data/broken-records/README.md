# broken-records

**SYNTHETIC. Every row here is fabricated.**

16 good rows plus five deliberate defects: last_seen before posted, a 9,000 bait, a 240,000 bait, a 1BHK listed at 2,300 sqft, and a listing last seen 70 days ago.

**Expected:** benches all five with a rule id and a sentence, and keeps the 16

21 listings.
