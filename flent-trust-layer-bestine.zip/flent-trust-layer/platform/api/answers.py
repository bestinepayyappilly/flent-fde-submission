"""
The answer to the resolving question, recorded so the whole team sees it.

The engine refuses on this deal because the listings may or may not include
maintenance. That is a missing fact, and somebody can go and get it. Until
they can write it down where their colleagues can see it, the refusal has
nowhere to go, and the product stops one step short of being useful.

Append-only on purpose. An answer can be superseded but not erased, and every
entry carries who said it, when, and where it came from. That is the shape
the override file should have had -- FAILURES.md records the current one as
an unaudited laundering path -- so the same mistake is not repeated here.

The store is a JSONL file. On this host the filesystem does not survive a
redeploy, and the API says so rather than implying durability it does not
have. A production version belongs in the same datastore as the deal record,
behind the same identity.
"""

import json
import os
import threading
from datetime import datetime, timezone

PATH = os.environ.get("ANSWER_LOG", "/tmp/flent-answers.jsonl")
_LOCK = threading.Lock()

# What the question can be answered with, and what each answer means for the
# comparison. "included" means the scraped rents already contain maintenance,
# so the subject's all-in cost is the like-for-like figure.
CHOICES = {
    "included": {
        "label": "The listings already include maintenance in their rent",
        "compare": "all_in",
        "detail": "so compare our all-in cost, rent plus maintenance",
    },
    "excluded": {
        "label": "The listings quote rent only, maintenance is extra",
        "compare": "base_rent",
        "detail": "so compare our base rent on its own",
    },
}


def _entries() -> list:
    try:
        with open(PATH, encoding="utf-8") as fh:
            return [json.loads(line) for line in fh if line.strip()]
    except (OSError, ValueError):
        return []


def log(deal_id: str) -> list:
    """Every answer ever recorded for this deal, oldest first."""
    return [e for e in _entries() if e.get("deal_id") == deal_id]


def latest(deal_id: str) -> dict | None:
    """The answer that currently stands, or None."""
    entries = log(deal_id)
    if not entries:
        return None
    last = entries[-1]
    return None if last.get("answer") == "withdrawn" else last


def record(deal_id: str, answer: str, who: str, note: str = "") -> dict:
    """
    Append an answer. Supersedes any earlier one without deleting it.

    'withdrawn' is a valid answer: it puts the deal back to unresolved while
    leaving the trail intact, because a retraction is itself a fact worth
    keeping.
    """
    if answer not in CHOICES and answer != "withdrawn":
        raise ValueError(
            f"answer must be one of {', '.join(CHOICES)} or 'withdrawn'"
        )
    who = (who or "").strip()
    if not who:
        raise ValueError("an answer needs a name against it")

    entry = {
        "deal_id": deal_id,
        "answer": answer,
        "who": who,
        "note": (note or "").strip(),
        "at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    with _LOCK:
        with open(PATH, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry) + "\n")
    return entry
