# thin-evidence

**SYNTHETIC. Every row here is fabricated.**

Only 4 comparables in scope. Below min_n_low, which is 6.

**Expected:** refuses outright: no benchmark published

4 listings.
