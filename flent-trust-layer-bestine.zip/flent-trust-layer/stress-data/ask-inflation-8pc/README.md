# ask-inflation-8pc

**SYNTHETIC. Every row here is fabricated.**

Every ask inflated 8% above what the home would actually let for. This is S3, and no listings-only signal separates it from a real market: days-on-market correlates with rent at only -0.16.

**Expected:** publishes a confidently wrong benchmark. The robustness battery is the only thing that surfaces it, by bounding where the call flips

22 listings.
