"use client";

import { useState } from "react";
import { TriangleAlert, Upload } from "lucide-react";
import { DealView } from "@/components/deal-view";
import { API, rupees, type Scored } from "@/lib/api";

const LISTING_COLUMNS = [
  "listing_id",
  "source",
  "posted_date",
  "last_seen_date",
  "society",
  "locality",
  "bhk",
  "furnishing",
  "area_sqft",
  "rent",
  "deposit",
  "photo_count",
  "poster_type",
];

const DEAL_EXAMPLE = `{
  "deal_id": "MY-DEAL-01",
  "snapshot": "2026-08-18",
  "society": "Lakeview Residences",
  "locality": "Harlur-Sarjapur Road",
  "bhk": "2",
  "furnishing": "semi-furnished",
  "base_rent": 56000,
  "maintenance": 5000
}`;

function FilePick({
  label,
  hint,
  required,
  file,
  onPick,
}: {
  label: string;
  hint: string;
  required?: boolean;
  file: File | null;
  onPick: (f: File | null) => void;
}) {
  return (
    <label className="block cursor-pointer rounded-lg border border-dashed border-border bg-card p-4 transition hover:border-foreground/40">
      <div className="flex items-baseline justify-between gap-3">
        <span className="text-[13px] font-medium">
          {label}{" "}
          {!required && (
            <span className="font-medium text-muted-foreground">optional</span>
          )}
        </span>
        <span className="inline-flex items-center gap-1.5 text-[11.5px] font-medium text-foreground">
          <Upload className="size-3.5" aria-hidden />
          {file ? "Change" : "Choose file"}
        </span>
      </div>
      <p className="mt-1 text-[12.5px] leading-relaxed text-muted-foreground">
        {hint}
      </p>
      {file && (
        <p className="mt-2 font-mono text-[11.5px] text-foreground">
          {file.name} · {(file.size / 1024).toFixed(1)} KB
        </p>
      )}
      <input
        type="file"
        className="hidden"
        onChange={(e) => onPick(e.target.files?.[0] ?? null)}
      />
    </label>
  );
}

export function UploadForm() {
  const [listings, setListings] = useState<File | null>(null);
  const [deal, setDeal] = useState<File | null>(null);
  const [overrides, setOverrides] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<Scored | null>(null);

  async function submit() {
    if (!listings || !deal) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const body = new FormData();
      body.append("listings", listings);
      body.append("deal", deal);
      if (overrides) body.append("overrides", overrides);
      const res = await fetch(`${API}/api/upload`, { method: "POST", body });
      const json = await res.json();
      if (!res.ok) {
        setError(json.detail ?? `upload failed (${res.status})`);
      } else {
        setResult(json as Scored);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      {/* The single mobile column needs minmax(0,1fr) as much as the two
          desktop ones do. A bare `grid` gives an implicit `auto` track, and a
          grid item's default min-width is its min-content — so the widest
          line in the code samples below pushed the track past the viewport
          and took the whole page horizontal with it. The samples already
          carry overflow-x-auto; it could never fire while the track was free
          to grow instead. */}
      <div className="mt-6 grid grid-cols-[minmax(0,1fr)] gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:gap-5">
        <div className="space-y-3">
          <FilePick
            label="listings.csv"
            required
            hint="The raw pull. Header row required."
            file={listings}
            onPick={setListings}
          />
          <FilePick
            label="deal.json"
            required
            hint="The subject property and the landlord's terms."
            file={deal}
            onPick={setDeal}
          />
          <FilePick
            label="overrides.csv"
            hint="listing_id, decision, who, why. A named human outranks every rule in both directions."
            file={overrides}
            onPick={setOverrides}
          />

          <button
            onClick={submit}
            disabled={!listings || !deal || busy}
            className="w-full rounded-md bg-foreground px-5 py-2.5 text-[13.5px] font-medium text-background transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-30"
          >
            {busy ? "Scoring…" : "Score this pull"}
          </button>

          {error && (
            <div className="rounded-lg border border-refuse-border bg-refuse-bg p-4">
              <div className="flex items-center gap-1.5 text-[11px] font-medium tracking-[0.07em] text-refuse">
                <TriangleAlert className="size-3.5" aria-hidden />
                REJECTED
              </div>
              <p className="mt-2 text-[13px] leading-relaxed text-refuse">
                {error}
              </p>
            </div>
          )}
        </div>

        <div className="rounded-lg border border-border bg-card p-5 sm:p-6">
          <h2 className="text-[14.5px] font-semibold tracking-tight">
            What the files have to contain
          </h2>

          <div className="mt-4 text-[11.5px] font-bold tracking-[0.09em] text-muted-foreground">
            LISTINGS.CSV COLUMNS
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {LISTING_COLUMNS.map((c) => (
              <code
                key={c}
                className="rounded border border-border bg-secondary px-1.5 py-0.5 font-mono text-[10.5px]"
              >
                {c}
              </code>
            ))}
          </div>
          <p className="mt-2.5 text-[12.5px] leading-relaxed text-muted-foreground">
            <code className="font-mono text-[11.5px]">area_sqft</code> and{" "}
            <code className="font-mono text-[11.5px]">deposit</code> may be
            blank. Blanks stay blank and are never filled in.
          </p>

          <div className="mt-5 text-[11.5px] font-bold tracking-[0.09em] text-muted-foreground">
            DEAL.JSON
          </div>
          <pre className="mt-2 overflow-x-auto rounded-md border border-border bg-secondary p-3 font-mono text-[11px] leading-relaxed">
            {DEAL_EXAMPLE}
          </pre>
          <p className="mt-2.5 text-[12.5px] leading-relaxed text-muted-foreground">
            A deal missing any of these is rejected outright rather than
            defaulted. That is guardrail 1 enforced in code, and it is the
            easiest thing here to test: delete a field and upload it.
          </p>

          <div className="mt-5 border-t border-border pt-4">
            <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
              NOTHING TO HAND?
            </div>
            <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
              The repo ships nine labelled synthetic pulls under{" "}
              <code className="font-mono text-[11.5px]">stress-data/</code>,
              each built to exercise one known failure mode. Generate them
              with:
            </p>
            <pre className="mt-2 overflow-x-auto rounded-md border border-border bg-secondary p-3 font-mono text-[11px]">
              python3 trust-layer/generate_stress_data.py --check
            </pre>
            <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
              Two of them are expected to defeat the engine rather than be
              caught by it, and their READMEs say so.
            </p>
          </div>
        </div>
      </div>

      {result && (
        <div className="mt-10 border-t border-border pt-8">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <h2 className="text-[20px] font-semibold tracking-tight sm:text-[24px]">
              {result.deal.society} · {result.deal.bhk}BHK
            </h2>
            <span className="text-[13px] text-muted-foreground">
              {result.deal.furnishing} · {result.deal.id} · snapshot{" "}
              {result.deal.snapshot}
            </span>
          </div>

          <div
            className={`mt-5 rounded-lg p-5 sm:p-6 ${
              result.verdict.call === "INSUFFICIENT_EVIDENCE"
                ? "border border-refuse-border bg-refuse-bg text-refuse"
                : "bg-primary text-primary-foreground"
            }`}
          >
            <div className="text-[20px] font-semibold tracking-tight sm:text-[24px]">
              {result.verdict.headline}
            </div>
            <p className="mt-3 text-[13.5px] leading-relaxed opacity-90">
              {result.verdict.detail}
            </p>
            {result.benchmark.median !== null && (
              <p className="mt-3 border-t border-current/15 pt-3 text-[13px] opacity-80">
                Benchmark {rupees(result.benchmark.median)} ·{" "}
                {result.benchmark.tier} · n={result.benchmark.n}
              </p>
            )}
          </div>

          <DealView d={result} />
        </div>
      )}
    </>
  );
}
