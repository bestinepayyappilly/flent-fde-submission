"use client";

import { LayoutPanelLeft, Upload } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/", label: "Deals", icon: LayoutPanelLeft },
  { href: "/upload", label: "Upload a pull", icon: Upload },
];

function isActive(pathname: string, href: string) {
  // A deal page lives under /deals/..., so Deals stays lit there.
  return href === "/"
    ? pathname === "/" || pathname.startsWith("/deals")
    : pathname.startsWith(href);
}

/** Vertical nav, shown from lg up. */
export function Nav() {
  const pathname = usePathname();

  return (
    <nav className="mt-8 flex flex-col gap-0.5">
      {LINKS.map((l) => {
        const active = isActive(pathname, l.href);
        return (
          <Link
            key={l.href}
            href={l.href}
            aria-current={active ? "page" : undefined}
            className={`flex items-center gap-3 rounded-md px-3 py-2 text-[14px] transition ${
              active
                ? "bg-accent font-medium text-foreground"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            }`}
          >
            <l.icon className="size-4 shrink-0" aria-hidden />
            {l.label}
          </Link>
        );
      })}
    </nav>
  );
}

/**
 * Horizontal nav for the mobile and tablet header. Below lg the sidebar is
 * hidden, and before this existed there was no navigation at all on a phone.
 */
export function NavInline() {
  const pathname = usePathname();

  return (
    <nav className="-mx-4 overflow-x-auto px-4 pb-px">
      <div className="flex min-w-max gap-5">
      {LINKS.map((l) => {
        const active = isActive(pathname, l.href);
        return (
          <Link
            key={l.href}
            href={l.href}
            aria-current={active ? "page" : undefined}
            className={`-mb-px shrink-0 whitespace-nowrap border-b-2 pb-2.5 text-[14px] transition ${
              active
                ? "border-foreground font-medium text-foreground"
                : "border-transparent text-muted-foreground"
            }`}
          >
            {l.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
