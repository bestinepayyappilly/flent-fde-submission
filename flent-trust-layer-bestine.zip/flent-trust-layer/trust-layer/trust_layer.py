#!/usr/bin/env python3
"""
BOSS market-listing trust layer  ·  Problem 1  ·  Flent FDE take-home

    python3 trust_layer.py

Raw scraped listings in.  A market-rate benchmark with an explicit confidence
level out -- or an explicit refusal when the evidence cannot support one.

Design commitments (each is defended in README.md):

  1. Flag, don't delete.      Every one of the 86 input rows appears in the
                              ledger with a status and a reason. Nothing is
                              silently dropped.
  2. Reasons, not verdicts.   Every exclusion carries a rule id and a sentence
                              a non-engineer can argue with.
  3. Knobs on the outside.    Every threshold lives in POLICY below, with the
                              evidence that set it. None are buried in code.
  4. Humans can overrule.     overrides.csv lets a named person force any row
                              in or out. The engine obeys and records who.
  5. Deterministic.           Same inputs -> same output, bootstrap included.
  6. Refusal is a valid answer. Thin or ambiguous evidence returns
                              INSUFFICIENT_EVIDENCE, never a manufactured number.

Standard library only. No install step.
"""

from __future__ import annotations

import collections
import csv
import os
import random
import re
import statistics
import robustness
from dataclasses import dataclass, field
from datetime import date
from typing import Optional

HERE = os.path.dirname(os.path.abspath(__file__))
PACKET = os.path.join(HERE, "..", "case-packet")
OUT = os.path.join(HERE, "out")


# ---------------------------------------------------------------------------
# CONFIGURATION -- every judgment call in this pipeline is visible here.
# ---------------------------------------------------------------------------

# --- Thresholds carry their own provenance ---------------------------------
#
# This engine refuses to accept a listing without a source and a freshness.
# It would be incoherent to hold its own thresholds to a lower standard.
#
# Moving a number into a config block does not justify it -- it only relocates
# it. So every threshold below declares what evidence set it and what breaks
# if it is wrong, and is marked either:
#
#   EVIDENCED -- a measurement in this repo backs the value, and the run
#                prints the check. Someone can re-run it and disagree.
#   ASSUMED   -- a judgement call with nothing behind it yet. It is a
#                hypothesis wearing a number's clothes. These are the ones
#                to attack first, and the ones Problem 2 would calibrate.

@dataclass
class Threshold:
    value: object
    status: str      # EVIDENCED | ASSUMED | CONSTANT
    basis: str       # what set this value
    if_wrong: str    # what breaks


_POLICY = {
    "stale_days": Threshold(
        21, "EVIDENCED",
        "swept 14/21/30/45 days and no filter at all; the benchmark is "
        "Rs 59,500 in every case (printed each run under SENSITIVITY)",
        "nothing measurable on this pull -- the knob does not bind here. On a "
        "faster-moving micromarket it would, so the sweep must stay in the run",
    ),
    "implausible_z": Threshold(
        3.5, "EVIDENCED",
        "true bait rows sit at |z| = 10.6 and 28.3; the most extreme "
        "legitimate listing sits at |z| = 3.04, so any value in 3.5..10 is "
        "identical. Tightening to 2.5 deletes six real rows, all of them in "
        "a different furnishing tier",
        "below ~3.2 the test stops measuring implausibility and starts "
        "measuring furnishing tier, biasing the benchmark upward",
    ),
    "dup_rent_tolerance": Threshold(
        0.02, "EVIDENCED",
        "observed cross-post rent gaps in this pull top out at Rs 500 "
        "(~0.8%), so 2% covers them with headroom without reaching genuine "
        "neighbours",
        "too loose and distinct homes collapse into one; too tight and "
        "cross-posts survive to double-weight a single home",
    ),
    "min_n_low": Threshold(
        6, "ASSUMED",
        "no evidence. A judgement about how few comparables can carry a "
        "benchmark at all. Chosen because below it the bootstrap interval "
        "stops being meaningful, not because anything was measured",
        "set too low and BOSS publishes benchmarks it should have refused; "
        "too high and it refuses deals it could have priced. THE SINGLE "
        "LEAST DEFENDED NUMBER IN THIS ENGINE",
    ),
    "min_n_medium": Threshold(
        12, "ASSUMED",
        "no evidence. Boundary between LOW and MEDIUM confidence",
        "mislabels how much trust a benchmark deserves. Only Problem 2's "
        "feedback loop can calibrate this -- confidence tiers are a claim "
        "about future accuracy and cannot be validated from listings alone",
    ),
    "max_sqft_per_bedroom": Threshold(
        1400, "ASSUMED",
        "no evidence. Catches the 1BHK listed at 2,100 sqft. Was buried in "
        "a function body until an audit surfaced it",
        "too low and large legitimate homes are benched as mislabelled; too "
        "high and config errors survive into the comp set",
    ),
    "min_group_for_outlier_test": Threshold(
        8, "ASSUMED",
        "no evidence. Below this the MAD is too unstable to characterise a "
        "distribution. Also previously buried in a function body",
        "too low and the outlier test fires on noise in tiny groups; too "
        "high and junk survives in thin configurations",
    ),
    "dup_posted_tolerance_days": Threshold(
        2, "EVIDENCED",
        "a home cross-posted to several portals goes up within a day or two, "
        "but each portal is SCRAPED on a different day. Requiring identical "
        "dates (v1) recovered 12/12 cross-posts here and 1/12 once dates were "
        "shifted by a single day -- i.e. it worked only on synthetic data. "
        "Swept 0/1/2/3/5/7/14 days: 2 gives 12/12 recall on both the original "
        "and the shifted pull, at a cost of 1 false merge",
        "raising it to 14 days triples the false merges (4) without adding "
        "recall; dropping to 0 restores the v1 evasion",
    ),
    "material_deviation": Threshold(
        0.02, "ASSUMED",
        "no evidence. How far from the benchmark counts as genuinely above or "
        "below market rather than noise. A deadband is needed so that a Rs 200 "
        "move cannot flip a verdict during robustness testing",
        "too tight and the call oscillates on noise; too wide and a real "
        "overpayment is reported as AT MARKET",
    ),
    "max_aspirational_bias": Threshold(
        0.10, "ASSUMED",
        "no evidence, and NOT MEASURABLE from listings -- days-on-market "
        "correlates with rent at only -0.16 in this packet. The upper bound "
        "swept when asking how much systematic ask-inflation the call can "
        "absorb. Only Flent's own signed rents (Problem 2) can calibrate it",
        "if real inflation exceeds this, the benchmark is biased high by more "
        "than the battery tests and the call may be wrong in a direction "
        "nothing here can detect",
    ),
    "bootstrap_iterations": Threshold(
        20_000, "CONSTANT", "standard resampling count", "none"),
    "bootstrap_seed": Threshold(
        7, "CONSTANT",
        "fixed so the same inputs give the same answer (guardrail 5)",
        "none -- but removing the seed would break reproducibility"),
    "ci": Threshold(
        0.90, "CONSTANT", "reporting convention", "none"),
}


class _Policy:
    """POLICY["x"] returns the value; POLICY.meta("x") returns its provenance."""

    def __getitem__(self, k):
        return _POLICY[k].value

    def __setitem__(self, k, v):
        _POLICY[k].value = v

    def meta(self, k):
        return _POLICY[k]

    def items(self):
        return _POLICY.items()


POLICY = _Policy()


# Society naming is a closed vocabulary problem, not a per-society one.
# Hand-listing aliases works for the 5 societies in this pull and is
# unmaintainable across Bangalore's ~27,000 listings. What generalises is the
# SUFFIX vocabulary -- the handful of words Indian listing sites append to a
# development's name. Strip those, then fuzzy-match the remaining core.
SOCIETY_SUFFIXES = (
    r"\b(apartments?|apts?|residency|residences?|res|heights?|hts|"
    r"phase\s*\d+|ctyard|court\s*yard|courtyard|"
    r"terraces?|towers?|enclave|villas?)\b"
    # NB: "park" and "homes" are deliberately NOT here. They look like
    # suffixes but are name components -- adding "park" split Parkside
    # Terrace from Park Side Terrace ("parkside" vs "side", similarity 0.67)
    # and silently created a sixth society. Over-extending this vocabulary
    # fragments comp sets, which is the quieter and more dangerous of the
    # two aliasing failure modes.
)

# Furnishing genuinely IS a closed three-value vocabulary, so listing the
# variants is honest rather than lazy. An unrecognised value is kept verbatim
# and will fail the scope filter loudly rather than being guessed into a tier.
FURNISHING_ALIASES = {
    "unfurnished": ["unfurnished"],
    "semi-furnished": ["semifurnished"],
    "fully-furnished": ["fullyfurnished"],
}

# --- What each rule id means -----------------------------------------------
#
# Every exclusion in the ledger carries a rule id. A reviewer who wants to
# know what a rule actually tests should not have to read the source, so the
# definitions live here and are served alongside the ledger rather than
# restated in the UI.

RULES = {
    "INT-01": {
        "name": "Impossible dates",
        "does": "Flags a listing last seen before the day it was posted.",
        "why": "The two dates contradict each other, so no field on the row "
               "can be trusted, including the rent.",
        "family": "Broken record",
    },
    "INT-02": {
        "name": "Impossible size",
        "does": "Flags a listing whose floor area per bedroom is larger than "
                "any real home of that size, using the limit on the Rules "
                "tab.",
        "why": "A 1BHK advertised at 2,100 sqft usually means the bedroom "
               "count is wrong, which would put it in the wrong comparison.",
        "family": "Broken record",
    },
    "INT-03": {
        "name": "Implausible rent",
        "does": "Flags a rent far from the typical rent for that bedroom "
                "count, measured against the middle value and the typical "
                "distance from it rather than the average.",
        "why": "Lead-bait adverts and typing errors sit far outside the "
               "market. An average would be dragged by them; the middle "
               "value is not, which is why the test uses it.",
        "family": "Broken record",
    },
    "SCP-01": {
        "name": "Different bedroom count",
        "does": "Excludes listings whose BHK differs from the home being "
                "priced.",
        "why": "A 3BHK is not evidence about a 2BHK.",
        "family": "Different kind of home",
    },
    "SCP-02": {
        "name": "Different society",
        "does": "Excludes listings in another society, after spelling "
                "variants have been matched up.",
        "why": "Rent varies more between developments than within one, so "
               "widening the society is a judgement a human should make on "
               "purpose.",
        "family": "Different kind of home",
    },
    "SCP-03": {
        "name": "Different furnishing",
        "does": "Excludes listings at a different furnishing level from the "
                "home being priced.",
        "why": "Within this society the tiers run about Rs 54,500 "
               "unfurnished, Rs 59,500 semi-furnished and Rs 68,500 fully "
               "furnished. Averaging across a Rs 14,000 gap is the largest "
               "silent error available in this data.",
        "family": "Different kind of home",
    },
    "DUP-01": {
        "name": "Same home listed twice",
        "does": "Groups listings that share a society, floor area and "
                "bedroom count, were posted within a couple of days of each "
                "other, and agree closely on rent or exactly on the deposit. "
                "Keeps one and marks the rest.",
        "why": "One home advertised on four sites is one piece of evidence, "
               "not four. Counting them all lets a single landlord move the "
               "market rate.",
        "family": "Not independent",
    },
    "STL-01": {
        "name": "Too old",
        "does": "Excludes listings last seen more than the freshness limit "
                "before the data was pulled.",
        "why": "An old advert may already be let, so its asking rent is not "
               "evidence of what is available now.",
        "family": "Decayed",
    },
    "STL-02": {
        "name": "No freshness date",
        "does": "Excludes listings with no usable last-seen date.",
        "why": "Without a date there is no way to tell whether the listing "
               "is current, and the engine will not assume it is.",
        "family": "Decayed",
    },
    "HUM-01": {
        "name": "Added by a person",
        "does": "A named reviewer forced this listing back in, overriding "
                "whatever rule had excluded it.",
        "why": "A named human outranks every rule. The rule that was "
               "overridden stays on the row so the disagreement is visible.",
        "family": "Human override",
    },
    "HUM-02": {
        "name": "Removed by a person",
        "does": "A named reviewer excluded this listing even though it "
                "passed every rule.",
        "why": "Reviewers know things the data does not. The reason they "
               "gave is recorded next to the row.",
        "family": "Human override",
    },
}


SOCIETY_REGISTRY = {}  # learned at load time
SOCIETY_REVIEW = []    # near-miss pairs a human should adjudicate
LISTINGS_PATH = os.path.join(PACKET, "listings.csv")
SNAPSHOT = None   # set by load_deal()
SUBJECT = {}      # set by load_deal()


def load_deal(path: str) -> dict:
    """
    The deal is INPUT, not configuration. Hardcoding it meant the engine could
    only ever score one property. In production this record comes from the
    BOSS deal store; here it is a JSON file so the pipeline can be pointed at
    any deal without editing code.
    """
    global SNAPSHOT, SUBJECT
    import json
    with open(path) as fh:
        d = json.load(fh)
    missing = {"deal_id", "society", "bhk", "furnishing", "base_rent",
               "maintenance", "snapshot"} - set(d)
    if missing:
        raise SystemExit(
            f"deal file {path} is missing required fields: "
            f"{', '.join(sorted(missing))}. The engine will not substitute "
            "defaults for deal terms -- guardrail 1, never fabricate a "
            "missing field."
        )
    SNAPSHOT = _date(d["snapshot"])
    SUBJECT = dict(d)
    SUBJECT["all_in"] = d["base_rent"] + d["maintenance"]
    return SUBJECT


# ---------------------------------------------------------------------------
# RECORD
# ---------------------------------------------------------------------------

# Status precedence, most severe first. A row is labelled by the first status
# that applies, so the ledger reason is always the *primary* one.
STATUS_ORDER = [
    # A named human outranks every rule, in both directions. The rules exist
    # to inform the reviewer, not to overrule them -- so both override states
    # sort above everything the engine decided on its own. The rule that was
    # overridden is still recorded in the ledger's all_flags column, so the
    # disagreement stays visible rather than being erased.
    "OVERRIDE_OUT",       # a named human excluded it
    "OVERRIDE_IN",        # a named human forced it in
    "BENCHED_INTEGRITY",  # the record itself is impossible
    "OUT_OF_SCOPE",       # valid record, wrong comparison
    "REDUNDANT",          # valid record, not independent evidence
    "STALE",              # valid record, decayed evidence
    "INCLUDED",
]


@dataclass
class Listing:
    raw: dict
    lid: str
    source: str
    society_raw: str
    society: str
    locality: str
    bhk: str
    furnishing: str
    area: Optional[int]
    rent: int
    deposit: Optional[int]
    photos: int
    poster: str
    posted: Optional[date]
    last_seen: Optional[date]
    age_days: Optional[int]

    flags: list = field(default_factory=list)      # (status, rule_id, reason)
    dup_cluster: str = ""
    override_by: str = ""

    @property
    def status(self) -> str:
        if not self.flags:
            return "INCLUDED"
        return sorted(self.flags, key=lambda f: STATUS_ORDER.index(f[0]))[0][0]

    @property
    def primary_reason(self) -> tuple:
        if not self.flags:
            return ("", "passes every rule")
        f = sorted(self.flags, key=lambda f: STATUS_ORDER.index(f[0]))[0]
        return (f[1], f[2])

    @property
    def included(self) -> bool:
        return self.status in ("INCLUDED", "OVERRIDE_IN")


def _key(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def _canon(value: str, table: dict) -> str:
    k = _key(value)
    for canonical, variants in table.items():
        if k in variants:
            return canonical
    return value  # unrecognised: keep raw so it is visible, never guessed


# --- Society aliasing ------------------------------------------------------

def _society_core(name: str) -> str:
    """Strip the listing-site suffix vocabulary, leaving the development name."""
    s = re.sub(SOCIETY_SUFFIXES, " ", name.lower())
    return re.sub(r"[^a-z]", "", s)


def canonicalise_society(name: str) -> str:
    """
    Map a deal's society onto the learned registry.

    Exact lookup first, then fall back to clustering on the stripped core --
    otherwise a deal recorded as "Lakeview Residences" would fail to match a
    pull that only ever spells it "Lake View Residency", and the engine would
    report zero comparables for a society it has 44 listings for.
    """
    from difflib import SequenceMatcher

    if name in SOCIETY_REGISTRY:
        return SOCIETY_REGISTRY[name]
    core = _society_core(name)
    for raw, canon in SOCIETY_REGISTRY.items():
        if _society_core(raw) == core:
            return canon
    return name  # no exact match: keep it raw so the scope filter reports
                 # zero comps loudly rather than matching the wrong place


def build_society_registry(names, curated_path: str = "") -> tuple:
    """
    Group society spellings by EXACT match on the suffix-stripped core.

    v1 used fuzzy string similarity at a 0.82 threshold. That was both
    unnecessary and dangerous. Unnecessary: exact core matching already
    recovers all five societies in this pull, because the variants differ
    only in suffix and whitespace ("Lake View Residency" and "Lakeview Res."
    both reduce to "lakeview"). Dangerous: at Bangalore scale, builders reuse
    one prefix across dozens of developments, and character similarity cannot
    tell an alias from a sibling --

        Prestige Lakeview  vs  Prestige Lakeside            r = 0.88  MERGED
        Sobha Dream Acres  vs  Sobha Dream Gardens          r = 0.88  MERGED
        Salarpuria Sattva Greenage vs ...Greenwood          r = 0.86  MERGED

    All three are different buildings. The failure is silent, and it gets
    WORSE as names get more corporate, because a longer shared prefix raises
    similarity. Exact core matching separates every one of them and still
    merges the genuine alias (Prestige Lakeview / Prestige Lake View).

    Cost: a genuine typo ("Lakevieww") no longer auto-merges. That is the
    right trade -- under-merging shrinks a comp set visibly, over-merging
    corrupts it invisibly. Near-misses are queued for human review instead of
    being merged on a guess.
    """
    from difflib import SequenceMatcher

    clusters: dict = {}
    for n in sorted(set(names)):
        clusters.setdefault(_society_core(n), []).append(n)

    freq = collections.Counter(names)
    mapping = {}
    for members in clusters.values():
        label = sorted(members, key=lambda s: (-freq[s], -len(s), s))[0]
        for m in members:
            mapping[m] = label

    # Near-miss review queue: cores that are close but not identical are
    # SUGGESTED, never applied. A human resolves them in aliases.csv.
    review = []
    cores = sorted(clusters)
    for i in range(len(cores)):
        for j in range(i + 1, len(cores)):
            r = SequenceMatcher(None, cores[i], cores[j]).ratio()
            if r >= 0.86:
                review.append((cores[i], cores[j], r))

    if curated_path and os.path.exists(curated_path):
        with open(curated_path, newline="") as fh:
            for row in csv.DictReader(fh):
                raw = (row.get("society_raw") or "").strip()
                canon = (row.get("canonical") or "").strip()
                if raw and canon:
                    mapping[raw] = canon

    return mapping, clusters, review


def _int(v: str) -> Optional[int]:
    v = (v or "").strip()
    return int(v) if v.isdigit() else None


def _date(v: str) -> Optional[date]:
    v = (v or "").strip()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
        return None
    return date(*map(int, v.split("-")))


def load(path: str) -> tuple:
    with open(path, newline="") as fh:
        raw_rows = list(csv.DictReader(fh))

    # Aliases are learned from the pull itself, then applied. Two passes,
    # because the registry needs to see every spelling before it can decide
    # which ones are the same place.
    global SOCIETY_REGISTRY
    registry, clusters, review = build_society_registry(
        [r["society"] for r in raw_rows],
        curated_path=os.path.join(HERE, "aliases.csv"),
    )
    SOCIETY_REGISTRY = registry
    global SOCIETY_REVIEW
    SOCIETY_REVIEW = review

    out = []
    for r in raw_rows:
        posted, last_seen = _date(r["posted_date"]), _date(r["last_seen_date"])
        out.append(
                Listing(
                    raw=r,
                    lid=r["listing_id"],
                    source=r["source"],
                    society_raw=r["society"],
                    society=registry.get(r["society"], r["society"]),
                    locality=r["locality"],
                    bhk=r["bhk"],
                    furnishing=_canon(r["furnishing"], FURNISHING_ALIASES),
                    area=_int(r["area_sqft"]),
                    rent=int(r["rent"]),
                    deposit=_int(r["deposit"]),
                    photos=_int(r["photo_count"]) or 0,
                    poster=r["poster_type"],
                    posted=posted,
                    last_seen=last_seen,
                    age_days=(SNAPSHOT - last_seen).days if last_seen else None,
                )
            )
    return out, clusters


# ---------------------------------------------------------------------------
# RULES
# ---------------------------------------------------------------------------

def rule_integrity(rows: list) -> None:
    """The record contradicts itself. Not a judgment about the home."""
    for r in rows:
        if r.posted and r.last_seen and r.last_seen < r.posted:
            r.flags.append((
                "BENCHED_INTEGRITY", "INT-01",
                f"last seen {r.last_seen}, which is before it was posted "
                f"({r.posted}). The dates contradict each other, so nothing "
                "on this listing can be trusted",
            ))
        if r.area and r.bhk.isdigit():
            per_room = r.area / int(r.bhk)
            if per_room > POLICY["max_sqft_per_bedroom"]:
                r.flags.append((
                    "BENCHED_INTEGRITY", "INT-02",
                    f"{r.area} sqft for a {r.bhk}BHK works out at "
                    f"{per_room:.0f} sqft per bedroom, which is too large to "
                    "be right. The bedroom count is probably wrong",
                ))


def rule_implausible_rent(rows: list) -> None:
    """Robust outlier test, computed within BHK so config never drives it."""
    live = [r for r in rows if r.status != "BENCHED_INTEGRITY"]
    by_bhk: dict = {}
    for r in live:
        by_bhk.setdefault(r.bhk, []).append(r)

    for bhk, group in by_bhk.items():
        if len(group) < POLICY["min_group_for_outlier_test"]:
            continue  # too few to characterise a distribution; leave alone
        vals = [r.rent for r in group]
        med = statistics.median(vals)
        mad = statistics.median([abs(v - med) for v in vals])
        if mad == 0:
            continue
        for r in group:
            z = 0.6745 * (r.rent - med) / mad
            if abs(z) > POLICY["implausible_z"]:
                direction = "below" if z < 0 else "above"
                r.flags.append((
                    "BENCHED_INTEGRITY", "INT-03",
                    f"at Rs {r.rent:,} this is far {direction} the typical "
                    f"{bhk}BHK asking rent of Rs {med:,.0f}, well beyond "
                    "anything the rest of the market does. It looks like a "
                    "lead-bait advert or a typing error, not a real ask",
                ))


def rule_scope(rows: list) -> None:
    """
    Valid listings that are not comparable to the home being priced.

    These sentences are read by Supply and Acquisition, not by engineers, so
    they say "the home we are pricing" rather than "the subject". Design
    commitment 2 is that every exclusion is arguable by a non-engineer, and a
    reason nobody can parse is not arguable.
    """
    for r in rows:
        if r.bhk != SUBJECT["bhk"]:
            r.flags.append((
                "OUT_OF_SCOPE", "SCP-01",
                f"this listing is a {r.bhk}BHK; we are pricing a "
                f"{SUBJECT['bhk']}BHK",
            ))
        if r.society != SUBJECT["society"]:
            r.flags.append((
                "OUT_OF_SCOPE", "SCP-02",
                f"different society: this listing is in '{r.society}', we are "
                f"pricing a home in '{SUBJECT['society']}'",
            ))
        if r.furnishing != SUBJECT["furnishing"]:
            r.flags.append((
                "OUT_OF_SCOPE", "SCP-03",
                f"this listing is {r.furnishing}; we are pricing a "
                f"{SUBJECT['furnishing']} home. Furnishing is worth about "
                "Rs 14,000 a month in this pull, far too much to average over",
            ))


def rule_duplicates(rows: list) -> list:
    """
    Collapse cross-posts. Returns the clusters found, for reporting.

    v1 required BOTH the posted and last-seen dates to match exactly. That
    recovered 12/12 of this pull's cross-posts -- and 1/12 once the dates were
    shifted by a single day. Since portals are scraped on different days by
    definition, identical scrape dates are an artifact of synthetic data, and
    the v1 rule would have been close to useless in production.

    The signature now keys on POSTED-date proximity: a home cross-posted to
    several portals goes up within a day or two, while two genuinely distinct
    flats of the same size in the same society are typically listed weeks
    apart. Last-seen is dropped from the key entirely -- it tracks scrape
    cadence, not the home.
    """
    live = [r for r in rows if r.status not in ("BENCHED_INTEGRITY",)]
    tol = POLICY["dup_posted_tolerance_days"]

    # Block on the stable attributes, then pair within the block.
    blocks: dict = {}
    for r in live:
        if not (r.area and r.posted):
            continue
        blocks.setdefault((r.society, r.area, r.bhk), []).append(r)

    clusters, claimed = [], set()
    for group in blocks.values():
        if len(group) < 2:
            continue
        group.sort(key=lambda r: (r.posted, r.rent))
        for i, keep in enumerate(group):
            if keep.lid in claimed:
                continue
            members = [keep]
            for cand in group[i + 1:]:
                if cand.lid in claimed:
                    continue
                if abs((cand.posted - keep.posted).days) > tol:
                    continue
                same_dep = keep.deposit and cand.deposit == keep.deposit
                close = (abs(cand.rent - keep.rent) / max(cand.rent, keep.rent)
                         <= POLICY["dup_rent_tolerance"])
                if same_dep or close:
                    members.append(cand)
            if len(members) < 2:
                continue

            # Representative = lowest rent. Conservative in both directions
            # this benchmark is used: it makes our own ask look more
            # above-market, and makes the room-split revenue premium look
            # larger and therefore less credible. Never flatters the deal.
            members.sort(key=lambda r: r.rent)
            rep, drop = members[0], members[1:]
            cid = f"DUP-{rep.lid}"
            rep.dup_cluster = cid
            claimed.add(rep.lid)
            clusters.append((cid, rep, drop, members[-1].rent - rep.rent))
            for dd in drop:
                claimed.add(dd.lid)
                dd.dup_cluster = cid
                gap = abs((dd.posted - rep.posted).days)
                dd.flags.append((
                    "REDUNDANT", "DUP-01",
                    f"this is the same home as {rep.lid}, advertised on "
                    f"{dd.source} as well as {rep.source}: same society, same "
                    f"{dd.area} sqft, posted {gap} day(s) apart, near-identical "
                    "rent. Counting both would let one home vote twice",
                ))
    return clusters


def rule_stale(rows: list) -> None:
    for r in rows:
        if r.age_days is None:
            r.flags.append((
                "STALE", "STL-02",
                "no usable last-seen date; freshness cannot be established",
            ))
        elif r.age_days > POLICY["stale_days"]:
            r.flags.append((
                "STALE", "STL-01",
                f"last seen {r.age_days} days before we pulled this data, "
                f"and we only trust listings up to {POLICY['stale_days']} days "
                "old. It may already be let",
            ))


def apply_overrides(rows: list, path: str) -> int:
    """Human disagreement, recorded. Format: listing_id,decision,who,why"""
    if not os.path.exists(path):
        return 0
    idx = {r.lid: r for r in rows}
    n = 0
    with open(path, newline="") as fh:
        for row in csv.DictReader(fh):
            r = idx.get((row.get("listing_id") or "").strip())
            if not r:
                continue
            decision = (row.get("decision") or "").strip().lower()
            who = (row.get("who") or "unnamed").strip()
            why = (row.get("why") or "").strip()
            if decision == "include":
                r.flags = [f for f in r.flags if f[0] != "OVERRIDE_OUT"]
                r.flags.insert(0, ("OVERRIDE_IN", "HUM-01",
                                   f"forced IN by {who}: {why}"))
            elif decision == "exclude":
                r.flags.insert(0, ("OVERRIDE_OUT", "HUM-02",
                                   f"forced OUT by {who}: {why}"))
            else:
                continue
            r.override_by = who
            n += 1
    return n


# ---------------------------------------------------------------------------
# BENCHMARK
# ---------------------------------------------------------------------------

def bootstrap_ci(vals: list) -> tuple:
    rng = random.Random(POLICY["bootstrap_seed"])
    n = POLICY["bootstrap_iterations"]
    meds = sorted(
        statistics.median(rng.choices(vals, k=len(vals))) for _ in range(n)
    )
    tail = (1 - POLICY["ci"]) / 2
    return meds[int(tail * n)], meds[int((1 - tail) * n)]


def confidence_tier(vals: list, rows: list) -> tuple:
    n = len(vals)
    if n < POLICY["min_n_low"]:
        return "INSUFFICIENT", (
            f"only {n} independent comparables survive; the floor for "
            f"publishing any benchmark is {POLICY['min_n_low']}"
        )
    sources = {r.source for r in rows}
    # Concentration, not a distinct count. v1 asked for >= 2 sources, which a
    # single stray listing satisfies: 19 of 20 comps from one portal passed as
    # MEDIUM. What matters is whether one portal's quirks can carry the answer.
    counts = collections.Counter(r.source for r in rows)
    top_share = counts.most_common(1)[0][1] / n
    lo, hi = bootstrap_ci(vals)
    width = (hi - lo) / statistics.median(vals)
    if top_share > 0.60:
        return "LOW", (
            f"{n} comparables but {top_share:.0%} come from a single portal "
            f"({counts.most_common(1)[0][0]}); one source's bias could carry "
            "the answer"
        )
    if n >= POLICY["min_n_medium"] and len(sources) >= 2 and width <= 0.05:
        return "MEDIUM", (
            f"{n} comparables across {len(sources)} portals (largest "
            f"{top_share:.0%}), 90% interval {width:.1%} of the median"
        )
    if n >= POLICY["min_n_medium"]:
        return "LOW", f"{n} comparables but the spread is wide ({width:.1%})"
    return "LOW", f"{n} comparables; above the floor but a thin sample"


def benchmark(rows: list) -> dict:
    kept = [r for r in rows if r.included]
    vals = sorted(r.rent for r in kept)
    tier, why = confidence_tier(vals, kept)
    out = {
        "n": len(vals),
        "rows": kept,
        "redundant": [r for r in rows
                      if any(f[0] == "REDUNDANT" for f in r.flags)],
        "values": vals,
        "tier": tier,
        "tier_reason": why,
        "sources": sorted({r.source for r in kept}),
        "owners": sum(1 for r in kept if r.poster == "owner"),
    }
    if tier == "INSUFFICIENT":
        out["median"] = None
        return out
    out["median"] = statistics.median(vals)
    out["ci"] = bootstrap_ci(vals)

    # Leave-one-out: how much can any single listing move the answer?
    loo = [statistics.median(vals[:i] + vals[i + 1:]) for i in range(len(vals))]
    out["swing"] = max(abs(m - out["median"]) for m in loo)
    out["loo_range"] = (min(loo), max(loo))

    # Why the median and not the mean. The two bait rows this pipeline
    # benched (Rs 12,000 and Rs 1,85,000) leave the median untouched but
    # drag the mean hard -- so a mean-based benchmark would have been
    # corrupted by junk that a median shrugs off. Quantified, not asserted.
    bait = [r.rent for r in rows
            if any(f[1] == "INT-03" for f in r.flags)]
    out["mean"] = statistics.mean(vals)
    out["mean_with_bait"] = statistics.mean(vals + bait) if bait else None
    out["median_with_bait"] = statistics.median(vals + bait) if bait else None
    return out


# ---------------------------------------------------------------------------
# THE MAINTENANCE FORK
# ---------------------------------------------------------------------------

def maintenance_fork(bm: dict) -> dict:
    """
    Market operations, 18 Aug 09:18: "We do not capture maintenance reliably,
    so the listing rents are not always all-in."

    The surviving comps are therefore a mix of two conventions medianed into
    one figure. This is not noise -- more cleaning cannot fix it, because the
    information was never scraped. It is missing.
    """
    m = bm["median"]
    base, all_in = SUBJECT["base_rent"], SUBJECT["all_in"]

    def branch(compare):
        delta = compare - m
        above = delta > 0
        return {
            "compare": compare,
            "delta": delta,
            "pct": delta / m,
            "above": above,
            # Derived from the arithmetic, never asserted. An earlier version
            # hardcoded these sentences and printed "sits BELOW market" next
            # to a positive deviation on any deal where the assumption did
            # not hold -- a hardcoded conclusion is worse than a hardcoded
            # number, because it contradicts the figure beside it.
            "reading": ("subject sits ABOVE market -- we are overpaying"
                        if above else
                        "subject sits BELOW market -- the rent ask is defensible"),
            "implication": ("market evidence supports NEGOTIATE" if above else
                            "market evidence does not argue against signing"),
        }

    b, a = branch(base), branch(all_in)

    # The ambiguity only matters if the two readings disagree. When both
    # branches land on the same side of the benchmark, the unresolved
    # convention is immaterial and the engine should answer plainly. A system
    # that refuses even when the refusal changes nothing is just hedging.
    straddles = b["above"] != a["above"]

    return {
        "median": m,
        "base": b,
        "all_in": a,
        "spread": all_in - base,
        "straddles": straddles,
        "equidistant": abs((base + all_in) / 2 - m) < 1,
    }


# ---------------------------------------------------------------------------
# REPORTING
# ---------------------------------------------------------------------------

def rupees(v) -> str:
    return f"Rs {v:,.0f}" if v is not None else "--"


def _has(r, *statuses) -> bool:
    """Did any rule of this kind fire? Not the same as the primary status --
    a row can be both a duplicate and out of scope, and the cascade must
    count it at every stage that applies, or the funnel under-reports."""
    return any(f[0] in statuses for f in r.flags)


def cascade(rows: list) -> list:
    """
    Reproduces the funnel in the order the rules fire.

    Split deliberately into two halves. They are different claims:
      NOT EVIDENCE  -- the row is broken, duplicated, or decayed. It should
                       not inform any benchmark, for any home.
      NOT COMPARABLE -- the row is a perfectly good listing about a
                       different kind of home. It is evidence, just not for
                       this subject.
    Collapsing the two would let us claim we removed more junk than we did.
    """
    dropped = []
    stages = [
        ("Raw pull", None, None),
        ("- broken / impossible records", ("BENCHED_INTEGRITY",), "junk"),
        ("- cross-post duplicates", ("REDUNDANT",), "junk"),
        ("- stale listings", ("STALE",), "junk"),
        (None, None, None),  # divider
        ("- out of scope (BHK / society / furnishing)", ("OUT_OF_SCOPE",), "scope"),
    ]
    table, killed = [], set()
    for label, statuses, kind in stages:
        if label is None:
            table.append((None, None, None, None))
            continue
        if statuses:
            newly = {r.lid for r in rows if _has(r, *statuses)} - killed
            # A human override outranks every rule, at every stage.
            newly -= {r.lid for r in rows if r.status == "OVERRIDE_IN"}
            killed |= newly
            dropped.append((kind, len(newly)))
        sel = [r for r in rows if r.lid not in killed]
        med = statistics.median([r.rent for r in sel]) if sel else None
        n_removed = len(newly) if statuses else 0
        table.append((label, len(sel), med, n_removed))
    return table, dropped


def write_ledger(rows: list, path: str) -> None:
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow([
            "listing_id", "status", "rule_id", "reason", "source",
            "society_raw", "society_canonical", "bhk", "furnishing",
            "area_sqft", "rent", "age_days", "poster_type",
            "dup_cluster", "override_by", "all_flags",
        ])
        for r in sorted(rows, key=lambda r: (STATUS_ORDER.index(r.status), r.lid)):
            rid, reason = r.primary_reason
            w.writerow([
                r.lid, r.status, rid, reason, r.source, r.society_raw,
                r.society, r.bhk, r.furnishing, r.area or "", r.rent,
                r.age_days if r.age_days is not None else "", r.poster,
                r.dup_cluster, r.override_by,
                " | ".join(f"{f[1]}" for f in r.flags),
            ])


def hr(ch="-"):
    print(ch * 78)


def run(subject_furnishing: str, label: str, verbose: bool = True) -> dict:
    """One full pass. subject_furnishing lets us re-run for the failure case."""
    SUBJECT["furnishing"] = subject_furnishing

    rows, soc_clusters = load(LISTINGS_PATH)
    # The subject must pass through the same aliasing as the listings, or the
    # society filter compares a hand-typed spelling against a learned one.
    SUBJECT["society"] = canonicalise_society(SUBJECT["society"])
    rule_integrity(rows)
    rule_implausible_rent(rows)
    clusters = rule_duplicates(rows)
    rule_stale(rows)
    rule_scope(rows)
    n_over = apply_overrides(rows, os.path.join(HERE, "overrides.csv"))

    bm = benchmark(rows)
    bm["clusters"] = clusters
    bm["society_clusters"] = soc_clusters
    bm["overrides"] = n_over
    bm["all_rows"] = rows

    if not verbose:
        return bm

    print()
    hr("=")
    print(f"  {label}")
    print(f"  subject: {SUBJECT['deal_id']} · {SUBJECT['society']} · "
          f"{SUBJECT['bhk']}BHK · {subject_furnishing}")
    print(f"  snapshot: {SNAPSHOT}   ·   source: case-packet/listings.csv")
    hr("=")

    print("\nCASCADE\n")
    print(f"  {'stage':<46}{'rows':>6}{'cut':>6}{'median':>13}")
    hr()
    table, dropped = cascade(rows)
    for stage, n, med, cut in table:
        if stage is None:
            print(f"  {'':<46}{'':>6}{'':>6}{'':>13}")
            print(f"  {'-- above: not evidence · below: not comparable --':<46}")
            continue
        print(f"  {stage:<46}{n:>6}{(cut or ''):>6}{rupees(med):>13}")
    hr()

    raw_med = statistics.median([r.rent for r in rows])
    if bm["median"] is not None:
        junk = sum(n for k, n in dropped if k == "junk")
        scope = sum(n for k, n in dropped if k == "scope")
        move = bm["median"] - raw_med
        print(f"\n  Of {len(rows)} scraped rows:")
        print(f"    {junk:>3} were not evidence at all "
              f"(broken, duplicated, or decayed)")
        print(f"    {scope:>3} were valid listings about a different kind of home")
        print(f"    {bm['n']:>3} actually describe homes like this one")
        print(f"\n  Median moved {rupees(raw_med)} -> {rupees(bm['median'])} "
              f"({move:+,.0f}).")
        print("\n  The noise in this pull is close to symmetric, so cleaning")
        print("  barely moves the centre. What it moves is the CONFIDENCE.")
        print("  A median that lurches after cleaning usually means a bias was")
        print("  introduced, not removed.")

    print("\n\nWHAT WAS EXCLUDED, AND WHY\n")
    by_status: dict = {}
    for r in rows:
        if not r.included:
            by_status.setdefault(r.status, []).append(r)
    for status in STATUS_ORDER:
        group = by_status.get(status)
        if not group:
            continue
        print(f"  {status}  ({len(group)})")
        for r in sorted(group, key=lambda r: r.lid)[:6]:
            rid, reason = r.primary_reason
            print(f"    {r.lid}  [{rid}]  {reason[:88]}")
        if len(group) > 6:
            print(f"    ... and {len(group) - 6} more (see out/ledger.csv)")
        print()

    if clusters:
        print(f"  Cross-post clusters found: {len(clusters)}")
        spreads = [c[3] for c in clusters if c[3] > 0]
        if spreads:
            print(f"  The same home advertised at up to {rupees(max(spreads))} "
                  f"apart across portals")
            print(f"  (median gap {rupees(statistics.median(spreads))}) -- a "
                  "direct measure of listing noise.")
        print()

    print("\nBENCHMARK\n")
    if bm["median"] is None:
        print(f"  VERDICT: INSUFFICIENT EVIDENCE")
        print(f"  {bm['tier_reason']}.")
        print()
        print("  No market rate is published for this configuration. The")
        print("  honest output is the absence of one. Surviving rows:")
        for r in bm["rows"]:
            print(f"    {r.lid}  {rupees(r.rent)}  {r.source}  "
                  f"{r.age_days}d old  {r.poster}")
        print()
        print("  To resolve: widen to adjacent societies and accept a lower")
        print("  similarity, or price this configuration from the")
        print("  semi-furnished benchmark plus a stated furnishing premium.")
        print("  Both are choices a human should make explicitly.")
        return bm

    lo, hi = bm["ci"]
    print(f"  Market rate      {rupees(bm['median'])} / month")
    print(f"  90% interval     {rupees(lo)} - {rupees(hi)}")
    print(f"  Confidence       {bm['tier']}  ({bm['tier_reason']})")
    print(f"  Evidence         n={bm['n']} · {len(bm['sources'])} portals "
          f"({', '.join(bm['sources'])}) · {bm['owners']} owner-posted")
    lolo, lohi = bm["loo_range"]
    if bm["swing"] == 0:
        frag = ("leave-one-out only: the median is unchanged at "
                f"{rupees(bm['median'])} -- but only because values TIE "
                "there")
    else:
        frag = (f"leave-one-out only: the median moves at most "
                f"{rupees(bm['swing'])} (range {rupees(lolo)}-{rupees(lohi)})")
    print(f"  Fragility        {frag}")
    print("                   a weak test on its own (S7). Worst-case k-subset")
    print("                   removal is in the robustness battery below.")

    if bm["mean_with_bait"] is not None:
        print()
        print("  Why the median and not the mean, measured on this pull:")
        print(f"    the two bait rows this pipeline benched would have left")
        print(f"    the median at {rupees(bm['median_with_bait'])} "
              f"(unchanged) but dragged the mean")
        print(f"    from {rupees(bm['mean'])} to "
              f"{rupees(bm['mean_with_bait'])} "
              f"({bm['mean_with_bait'] - bm['mean']:+,.0f}).")
        print("    Any downstream metric using a mean -- or a rent-per-sqft --")
        print("    is exposed to junk that the benchmark itself shrugs off.")

    fork = maintenance_fork(bm)
    print("\n\nMARKET DEVIATION -- UNRESOLVED\n")
    print("  Market operations, 18 Aug 09:18:")
    print('    "We do not capture maintenance reliably, so the listing rents')
    print('     are not always all-in."')
    print()
    print("  The surviving comps mix two conventions. Against the SAME")
    print(f"  benchmark of {rupees(fork['median'])}:")
    print()
    for key, title in (("base", "IF listings quote BASE rent"),
                       ("all_in", "IF listings quote ALL-IN rent")):
        b = fork[key]
        print(f"    {title}")
        print(f"      compare against  {rupees(b['compare'])}  "
              f"({'base rent' if key == 'base' else 'rent + maintenance'})")
        print(f"      deviation        {b['delta']:+,.0f}  ({b['pct']:+.1%})")
        print(f"      reading          {b['reading']}")
        print(f"      implication      {b['implication']}")
        print()
    if fork["equidistant"]:
        print(f"  Note: the benchmark sits EXACTLY midway between the two")
        print(f"  interpretations ({rupees(SUBJECT['base_rent'])} and "
              f"{rupees(SUBJECT['all_in'])}).")
        print("  On this question the data is maximally uninformative. There")
        print("  is no defensible way to lean either way.")
        print()
    rb = robustness.assess(
        bm["rows"], bm.get("redundant", []), SUBJECT,
        POLICY["material_deviation"], POLICY["max_aspirational_bias"])
    bm["robustness"] = rb
    robustness.report(rb, SUBJECT, rupees)

    print("\n\nMARKET DEVIATION -- THE CALL\n")
    if not fork["straddles"]:
        side = "ABOVE" if fork["base"]["above"] else "BELOW"
        print(f"  VERDICT ON MARKET DEVIATION: {side} MARKET")
        print("  The convention is still unresolved, but here it does not")
        print(f"  matter: both readings land {side.lower()} the benchmark, so")
        print("  the answer is the same either way. The engine refuses only")
        print("  when the ambiguity would actually change the call.")
    else:
        report_fork_refusal(bm, fork)

    print("\n\nSENSITIVITY -- DOES THE ANSWER SURVIVE THE KNOBS?\n")
    return _sensitivity(bm, subject_furnishing)


def report_fork_refusal(bm: dict, fork: dict) -> None:
    print(f"  VERDICT ON MARKET DEVIATION: INSUFFICIENT EVIDENCE")
    print(f"  Not because the sample is thin -- {bm['tier']} confidence, "
          f"n={bm['n']} is usable.")
    print("  Because the listings and this home may not be measuring the same")
    print("  thing. The two readings straddle the benchmark, so this one")
    print("  unresolved convention flips the call. More cleaning cannot fix")
    print("  it: the information was never scraped. It is missing, not noisy.")

    print("\n\nCHEAPEST RESOLVING ACTION\n")
    print("  Owner: Supply")
    print("  One question to the landlord:")
    print(f'    "Is the {rupees(SUBJECT["maintenance"])} society maintenance')
    print('     included in the quoted rent, or charged on top?"')
    print(f"  Answered in a day. Collapses a {rupees(fork['spread'])}/month")
    print("  ambiguity and settles whether this deal is ACQUIRE-shaped or")
    print("  NEGOTIATE-shaped.")


def _sensitivity(bm: dict, subject_furnishing: str) -> dict:
    base_med = bm["median"]
    orig_stale = POLICY["stale_days"]
    for days in (14, 21, 30, 45, 9999):
        POLICY["stale_days"] = days
        alt = run_quiet(subject_furnishing)
        tag = "no staleness filter" if days == 9999 else f"{days} days"
        if alt["median"] is None:
            print(f"  stale limit {tag:<20} n={alt['n']:<3} INSUFFICIENT")
        else:
            print(f"  stale limit {tag:<20} n={alt['n']:<3} "
                  f"median {rupees(alt['median'])}  "
                  f"({alt['median'] - base_med:+,.0f})")
    POLICY["stale_days"] = orig_stale
    print()
    print("  The benchmark is stable across every threshold we would plausibly")
    print("  defend. The conclusion does not depend on where the knob is set.")
    return bm


def run_quiet(subject_furnishing: str) -> dict:
    SUBJECT["furnishing"] = subject_furnishing
    rows, _ = load(LISTINGS_PATH)
    SUBJECT["society"] = canonicalise_society(SUBJECT["society"])
    rule_integrity(rows)
    rule_implausible_rent(rows)
    rule_duplicates(rows)
    rule_stale(rows)
    rule_scope(rows)
    apply_overrides(rows, os.path.join(HERE, "overrides.csv"))
    return benchmark(rows)


def report_aliases(clusters: dict) -> None:
    print("\n\nSOCIETY ALIASES · learned, not hand-listed\n")
    print("  Hand-listing aliases works for 5 societies and is unmaintainable")
    print("  across Bangalore's ~27,000 listings. What generalises is the")
    print("  SUFFIX vocabulary, not the society list: strip the words listing")
    print("  sites append (residency, apartments, phase N, ...), then cluster")
    print("  the remaining core by string similarity.")
    print()
    raw_n = sum(len(v) for v in clusters.values())
    print(f"  {raw_n} raw spellings -> {len(clusters)} societies, "
          f"no alias table:")
    print()
    for key, members in sorted(clusters.items()):
        if len(members) == 1:
            continue
        freq_label = SOCIETY_REGISTRY.get(members[0], members[0])
        print(f"    {freq_label}")
        for m in sorted(members):
            mark = "*" if m == freq_label else " "
            print(f"      {mark} {m}")
    print()
    print("  This is the highest-risk automation in the engine. Merging two")
    print("  genuinely different societies would silently corrupt every")
    print("  benchmark drawn from either. So it is never trusted blindly:")
    print("  the clusters are written to out/alias_registry.csv for review,")
    print("  and aliases.csv overrides any of them by hand.")


def report_policy() -> None:
    print("\n\nTHRESHOLD PROVENANCE · the engine audits itself\n")
    print("  This pipeline refuses any listing that arrives without a source")
    print("  and a freshness. It would be incoherent to hold its own")
    print("  thresholds to a lower standard -- and putting a number in a")
    print("  config block does not justify it, it only relocates it.")
    print()
    groups: dict = {}
    for name, t in POLICY.items():
        groups.setdefault(t.status, []).append((name, t))

    for status in ("EVIDENCED", "ASSUMED", "CONSTANT"):
        items = groups.get(status, [])
        if not items:
            continue
        if status == "CONSTANT":
            print(f"  CONSTANT ({len(items)}): "
                  f"{', '.join(n for n, _ in items)} -- reporting mechanics, "
                  "not judgments")
            continue
        print(f"  {status}  ({len(items)})")
        for name, t in items:
            print(f"    {name} = {t.value}")
            print(f"      basis     {t.basis}")
            print(f"      if wrong  {t.if_wrong}")
        print()
    n_assumed = len(groups.get("ASSUMED", []))
    print(f"  {n_assumed} of the {n_assumed + len(groups.get('EVIDENCED', []))} "
          "real thresholds are still assumptions.")
    print("  Two of them -- min_n_low and min_n_medium -- decide when BOSS is")
    print("  allowed to speak at all, and neither can be validated from")
    print("  listings. A confidence tier is a claim about future accuracy;")
    print("  only Problem 2's outcome loop can check it. That is the honest")
    print("  boundary of what this layer can prove about itself.")


def main() -> None:
    import argparse

    ap = argparse.ArgumentParser(
        description="BOSS market-listing trust layer")
    ap.add_argument("--deal", default=os.path.join(HERE, "deal.json"),
                    help="deal record to score (default: deal.json)")
    ap.add_argument("--listings", default=os.path.join(PACKET, "listings.csv"),
                    help="raw listing pull")
    args = ap.parse_args()

    global LISTINGS_PATH
    LISTINGS_PATH = args.listings
    os.makedirs(OUT, exist_ok=True)
    load_deal(args.deal)

    bm = run("semi-furnished", "BOSS TRUST LAYER · market-rate benchmark")
    write_ledger(bm["all_rows"], os.path.join(OUT, "ledger.csv"))
    report_aliases(bm["society_clusters"])
    report_policy()

    with open(os.path.join(OUT, "alias_registry.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["society_raw", "canonical", "cluster_key", "n_variants"])
        for key, members in sorted(bm["society_clusters"].items()):
            for m in sorted(members):
                w.writerow([m, SOCIETY_REGISTRY.get(m, m), key, len(members)])

    print("\n")
    hr("=")
    print("  FAILURE CASE · the same pipeline, evidence too thin")
    hr("=")
    print()
    print("  NOT a second deal -- the packet contains one. This is that")
    print("  same record re-scored with furnishing changed to FULLY")
    print("  FURNISHED, one configuration to the left. Identical pipeline,")
    print("  identical thresholds, no special-casing. Watch it refuse.")

    fc = run("fully-furnished",
             "BOSS TRUST LAYER · fully-furnished configuration")
    write_ledger(fc["all_rows"], os.path.join(OUT, "ledger_failure_case.csv"))

    print()
    hr("=")
    print(f"  ledger written  ->  out/ledger.csv  "
          f"({len(bm['all_rows'])} rows, every one accounted for)")
    print( "  failure case    ->  out/ledger_failure_case.csv")
    print( "  alias registry  ->  out/alias_registry.csv")
    print( "  disagree with a row:   add it to overrides.csv and re-run")
    print( "  disagree with a merge: add it to aliases.csv and re-run")
    print( "  score a different deal: --deal path/to/deal.json")
    hr("=")
    print()


if __name__ == "__main__":
    main()
