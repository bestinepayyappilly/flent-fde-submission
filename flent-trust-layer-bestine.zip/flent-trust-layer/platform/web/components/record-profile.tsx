"use client";

import { rupees, type Listing } from "@/lib/api";

/**
 * A five-axis profile of the RECORD, not of the home.
 *
 * BOSS's own radar is labelled "display-only" and synthesises five pillars
 * this packet has no data for, so none of those axes are reproduced here.
 * Every axis below is a formula over a field that was actually scraped, and
 * each one prints its raw value next to its scaled value so the scaling can
 * be argued with.
 *
 * The scalings are CHOICES, not measurements. They are labelled as such,
 * the same way the engine's POLICY block separates EVIDENCED from ASSUMED.
 * Nothing here feeds the benchmark: the engine's decision is the verdict
 * block, and this panel only describes the record it decided on.
 */

const PHOTO_CAP = 12;

type Axis = {
  key: string;
  label: string;
  value: number; // 0..1
  raw: string;
  rule: string;
  chosen: boolean;
};

function clamp01(n: number) {
  return Math.max(0, Math.min(1, n));
}

export function buildAxes(
  r: Listing,
  staleDays: number | null,
  median: number | null,
  compLo: number | null,
  compHi: number | null,
): Axis[] {
  // 1. Freshness: measured against the engine's own stale threshold.
  const fresh =
    r.age_days === null || staleDays === null
      ? 0
      : clamp01(1 - r.age_days / staleDays);

  // 2. Completeness: how many optional fields actually arrived.
  const optional = [r.area_sqft, r.deposit, r.posted_date, r.last_seen_date];
  const present = optional.filter((v) => v !== null && v !== "").length;

  // 3. Photo depth, capped. The cap is chosen, not derived.
  const photos = clamp01(r.photo_count / PHOTO_CAP);

  // 4. Independence: a cross-post is not a second piece of evidence.
  //
  // NB: both members of a cluster carry dup_cluster, but only the one the
  // engine flagged REDUNDANT is the duplicate. Scoring on dup_cluster alone
  // penalised the surviving representative for having been cross-posted,
  // which is backwards.
  const isRedundant = r.all_flags.some((f) => f.status === "REDUNDANT");
  const independent = isRedundant ? 0 : 1;

  // 5. Typicality: distance from the median, scaled by half the comp spread.
  let typical = 0;
  let typicalRaw = "no market rate to compare against";
  if (median !== null && compLo !== null && compHi !== null) {
    const half = (compHi - compLo) / 2 || 1;
    const d = Math.abs(r.rent - median);
    typical = clamp01(1 - d / half);
    typicalRaw = `${rupees(d)} from the middle price`;
  }

  return [
    {
      key: "fresh",
      label: "Recent",
      value: fresh,
      raw:
        r.age_days === null
          ? "no last-seen date"
          : `last seen ${r.age_days}d ago`,
      rule:
        staleDays === null
          ? "no threshold available"
          : `counts as fresh up to ${staleDays} days old`,
      chosen: false,
    },
    {
      key: "complete",
      label: "Complete",
      value: present / optional.length,
      raw: `${present} of ${optional.length} optional details filled in`,
      rule: "area, deposit, date posted, date last seen",
      chosen: false,
    },
    {
      key: "photos",
      label: "Photos",
      value: photos,
      raw: `${r.photo_count} photos`,
      rule: `${PHOTO_CAP} or more photos counts as full. That cap is our choice`,
      chosen: true,
    },
    {
      key: "independent",
      label: "Not a copy",
      value: independent,
      raw: isRedundant
        ? `the same home also listed as ${r.dup_cluster}`
        : r.dup_cluster
          ? `listed twice; this is the copy we kept`
          : "only listed once",
      rule: "full marks unless the same home was listed twice",
      chosen: false,
    },
    {
      key: "typical",
      label: "Normal price",
      value: typical,
      raw: typicalRaw,
      rule: "how close to the middle price. The scale is our choice",
      chosen: true,
    },
  ];
}

export function RecordProfile({
  axes,
  included,
}: {
  axes: Axis[];
  included: boolean;
}) {
  const R = 56;
  const cx = 140;
  const cy = 92;
  const n = axes.length;
  const angle = (i: number) => (Math.PI * 2 * i) / n - Math.PI / 2;
  const pt = (i: number, m: number) => [
    cx + Math.cos(angle(i)) * R * m,
    cy + Math.sin(angle(i)) * R * m,
  ];
  const poly = (m: number) =>
    axes.map((_, i) => pt(i, m).join(",")).join(" ");
  const shape = axes.map((a, i) => pt(i, Math.max(a.value, 0.02)).join(",")).join(" ");

  return (
    <div>
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <span className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
          LISTING QUALITY
        </span>
        <span className="text-[12px] text-muted-foreground">
          how good this listing is as evidence, not how good the home is
        </span>
      </div>

      <div className="mt-3 grid gap-5 sm:grid-cols-[280px_minmax(0,1fr)] sm:items-center">
        <svg viewBox="0 0 280 184" className="w-full max-w-[280px]">
          {[0.25, 0.5, 0.75, 1].map((m) => (
            <polygon
              key={m}
              points={poly(m)}
              fill="none"
              stroke="var(--border)"
              strokeWidth="1"
            />
          ))}
          {axes.map((_, i) => {
            const [x, y] = pt(i, 1);
            return (
              <line
                key={i}
                x1={cx}
                y1={cy}
                x2={x}
                y2={y}
                stroke="var(--border)"
                strokeWidth="1"
              />
            );
          })}
          <polygon
            points={shape}
            fill={included ? "var(--acquire)" : "var(--refuse)"}
            fillOpacity="0.14"
            stroke={included ? "var(--acquire)" : "var(--refuse)"}
            strokeWidth="1.75"
            strokeLinejoin="round"
          />
          {axes.map((a, i) => {
            const [x, y] = pt(i, 1);
            return (
              <circle
                key={a.key}
                cx={x}
                cy={y}
                r="0"
                fill="var(--foreground)"
              />
            );
          })}
          {axes.map((a, i) => {
            const [x, y] = pt(i, 1.34);
            return (
              <text
                key={a.key}
                x={x}
                y={y}
                textAnchor={
                  Math.abs(x - cx) < 6 ? "middle" : x > cx ? "start" : "end"
                }
                dominantBaseline="middle"
                fontSize="10"
                fill="var(--muted-foreground)"
              >
                {a.label}
              </text>
            );
          })}
        </svg>

        <div className="min-w-0">
          {axes.map((a) => (
            <div
              key={a.key}
              className="flex items-baseline justify-between gap-3 border-b border-border py-2 last:border-0"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[12.5px] font-medium">{a.label}</span>
                  {a.chosen && (
                    <span className="rounded border border-refuse-border bg-refuse-bg px-1.5 py-px text-[9.5px] font-medium text-refuse">
                      OUR JUDGEMENT
                    </span>
                  )}
                </div>
                <div className="text-[11.5px] leading-relaxed text-muted-foreground">
                  {a.raw} · {a.rule}
                </div>
              </div>
              <span className="tnum shrink-0 text-[12.5px] font-medium">
                {Math.round(a.value * 100)}
              </span>
            </div>
          ))}
        </div>
      </div>

      <p className="mt-3 text-[12.5px] leading-relaxed text-muted-foreground">
        None of this feeds the market rate. The decision is the block on the
        left and it is made by rules, not by a score. Two of the five scales
        below are our judgement rather than anything measured, and they say so.
      </p>
    </div>
  );
}
