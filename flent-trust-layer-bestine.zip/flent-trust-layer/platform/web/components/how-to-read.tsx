"use client";

import { BookOpen, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";

function Term({ k, children }: { k: string; children: React.ReactNode }) {
  return (
    <p className="text-[13px] leading-relaxed text-muted-foreground">
      <span className="font-medium text-foreground">{k}</span> {children}
    </p>
  );
}

export function HowToRead() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 text-[12.5px] font-medium text-muted-foreground transition hover:border-foreground/40 hover:text-foreground"
      >
        <BookOpen className="size-3.5" aria-hidden />
        {open ? "Hide" : "How to read this page"}
        {open ? (
          <ChevronUp className="size-3.5" aria-hidden />
        ) : (
          <ChevronDown className="size-3.5" aria-hidden />
        )}
      </button>

      {open && (
        <div className="mt-4 rounded-lg border border-border bg-card p-5 sm:p-6">
          <h2 className="text-[15.5px] font-semibold tracking-tight">
            How to read this page
          </h2>

          <p className="mt-3 max-w-3xl text-[13.5px] leading-relaxed text-muted-foreground">
            Start with the big block at the top. That is the answer. If it says
            we do not have enough evidence, that is a finished answer, not a
            missing one: it means the numbers cannot settle the question yet,
            and the card next to it names the one thing that would settle it
            and who should go and ask.
          </p>

          <div className="mt-6 grid gap-7 lg:grid-cols-2">
            <div>
              <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
                WHAT THE NUMBERS MEAN
              </div>
              <div className="mt-3 space-y-2.5">
                <Term k="Market rate">
                  the middle asking price of the homes we judged similar to this
                  one. Half ask more, half ask less.
                </Term>
                <Term k="Likely range">
                  where the true middle probably sits. A wide range means the
                  listings disagree with each other.
                </Term>
                <Term k="Listings used">
                  how many of the 86 scraped listings survived every check and
                  actually describe a home like this one. The rate is worked out
                  from those and nothing else.
                </Term>
                <Term k="How much to trust it">
                  Strong, Reasonable or Weak. Weak usually means too few homes,
                  or too many of them from one website.
                </Term>
                <Term k="How hard to change">
                  we try about twenty ways of being wrong and count how many the
                  answer survives. An answer backed by lots of listings can still
                  be easy to overturn, so this is the number to look at.
                </Term>
              </div>
            </div>

            <div>
              <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
                WHAT IS ON EACH TAB
              </div>
              <div className="mt-3 space-y-2.5">
                <Term k="Overview">
                  the market rate, and the one disagreement in the data that
                  decides this deal.
                </Term>
                <Term k="Money">
                  what Flent pays, what comes back, and how long the cash takes
                  to return.
                </Term>
                <Term k="Removed">
                  which listings were dropped, split into the ones that were
                  unusable and the ones that were fine but about a different
                  kind of home.
                </Term>
                <Term k="Listings">
                  all 86, with a plain reason for each. Search and filter here.
                  This is where you disagree with us.
                </Term>
                <Term k="Stress test">
                  the ways we tried to break the answer, and the ones that
                  worked.
                </Term>
                <Term k="Rules">
                  every number the checks rely on, and whether we measured it or
                  chose it.
                </Term>
                <Term k="Societies">
                  how spellings like “Lakeview Res.” and “Lake View Residency”
                  were matched up.
                </Term>
              </div>
            </div>
          </div>

          <p className="mt-6 border-t border-border pt-4 text-[12.5px] leading-relaxed text-muted-foreground">
            If you only open one tab, open Listings. Nothing was deleted
            quietly, so you can check any single home we dropped and tell us we
            got it wrong.
          </p>
        </div>
      )}
    </>
  );
}
