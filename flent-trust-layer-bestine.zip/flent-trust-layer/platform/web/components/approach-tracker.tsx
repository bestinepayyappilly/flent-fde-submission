"use client";

import { Check, RotateCcw, X } from "lucide-react";
import { useEffect, useState } from "react";

/**
 * Mark an approach confirmed or rejected, so a reviewer can track which ones
 * they have chased.
 *
 * Stored in this browser only. That is a real limit, not a shortcut: a
 * shared record of who confirmed what needs identity and an append-only log,
 * which is the same governance gap FAILURES.md records against overrides.csv.
 * A "confirmed" button with no name behind it is exactly the thing that
 * launders an assumption into a fact, so the UI says whose mark it is and
 * that it goes no further than this device.
 *
 * The engine's own evidence tag is left untouched beside it. Marking a row
 * confirmed records that YOU believe it; it does not change what the packet
 * actually contains.
 */

type Mark = {
  state: "confirmed" | "rejected";
  at: string;
  /** Why. A mark with no reason is the thing FAILURES.md warns about. */
  note?: string;
} | null;

const KEY = "flent-approach-marks";

function read(): Record<string, Mark> {
  try {
    return JSON.parse(localStorage.getItem(KEY) ?? "{}");
  } catch {
    return {};
  }
}

function write(all: Record<string, Mark>) {
  try {
    localStorage.setItem(KEY, JSON.stringify(all));
  } catch {
    // Private windows and blocked site data both throw. Losing the mark is
    // acceptable; breaking the page is not.
  }
}

export function ApproachTracker({ id }: { id: string }) {
  const [mark, setMark] = useState<Mark>(null);
  const [note, setNote] = useState("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const m = read()[id] ?? null;
    setMark(m);
    setNote(m?.note ?? "");
    setReady(true);
  }, [id]);

  function persist(next: Mark) {
    setMark(next);
    const all = read();
    all[id] = next;
    write(all);
  }

  function set(state: "confirmed" | "rejected" | null) {
    persist(
      state
        ? {
            state,
            at: new Date().toLocaleDateString("en-IN", {
              day: "numeric",
              month: "short",
              year: "numeric",
            }),
            note: note.trim() || undefined,
          }
        : null,
    );
    if (!state) setNote("");
  }

  /** Keep the note with the mark it belongs to, on blur rather than per key. */
  function saveNote() {
    if (!mark) return;
    persist({ ...mark, note: note.trim() || undefined });
  }

  // Nothing renders until localStorage has been read, or the server-rendered
  // markup and the client's first paint disagree.
  if (!ready) return <div className="h-[34px]" />;

  if (mark) {
    return (
      <div className="space-y-2">
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11.5px] font-medium ${
              mark.state === "confirmed"
                ? "border-acquire-border bg-acquire-bg text-acquire"
                : "border-border bg-secondary text-muted-foreground"
            }`}
          >
            {mark.state === "confirmed" ? (
              <Check className="size-3.5" aria-hidden />
            ) : (
              <X className="size-3.5" aria-hidden />
            )}
            You marked this {mark.state} · {mark.at}
          </span>
          <button
            onClick={() => set(null)}
            className="inline-flex items-center gap-1 text-[11.5px] text-muted-foreground hover:text-foreground"
          >
            <RotateCcw className="size-3" aria-hidden />
            Undo
          </button>
        </div>
        <input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          onBlur={saveNote}
          placeholder="Why? e.g. landlord confirmed on the phone, 8 Sep"
          className="w-full rounded-md border border-border bg-card px-3 py-1.5 text-[12.5px] outline-none focus:border-foreground"
        />
      </div>
    );
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <button
        onClick={() => set("confirmed")}
        className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 text-[12px] font-medium transition hover:border-acquire hover:text-acquire"
      >
        <Check className="size-3.5" aria-hidden />
        Confirmed
      </button>
      <button
        onClick={() => set("rejected")}
        className="inline-flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 text-[12px] font-medium text-muted-foreground transition hover:border-muted-foreground/50 hover:text-foreground"
      >
        <X className="size-3.5" aria-hidden />
        Rejected
      </button>
      <input
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Why? (optional)"
        className="min-w-[200px] flex-1 rounded-md border border-border bg-card px-3 py-1.5 text-[12.5px] outline-none focus:border-foreground"
      />
      <span className="text-[11.5px] text-muted-foreground">
        saved in this browser only
      </span>
    </div>
  );
}
