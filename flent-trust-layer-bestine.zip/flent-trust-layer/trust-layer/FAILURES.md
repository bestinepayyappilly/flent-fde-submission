# Known failures

Nine defects found by attacking the v1 trust layer, what each costs, and what
was done about it. Seven are reproducible:

```
python3 stress_test.py
```

Every claim below is printed by that harness against the real case packet with
one defect injected at a time. Nothing here is a hypothetical.

| # | Failure | Severity | Status |
|---|---|---|---|
| S6 | Society aliasing merged different buildings | Critical | **Fixed** |
| S5 | One portal supplying nearly every comp | Moderate | **Fixed** |
| S7 | Leave-one-out overstated stability | Low | **Fixed** |
| S1 | Cross-post dedup evaded by a date shift | High | **Bounded** |
| S2 | Plausible bait passes the outlier test | High | **Bounded** |
| S3 | Systematic aspirational pricing | Critical | **Open by design** |
| S4 | The refusal is only two rows deep | High | **Open** |
| — | Area basis (carpet / built-up / super built-up) | High | **Open** |
| — | The override file is an unaudited laundering path | Governance | **Open** |

**Bounded** means no filter can reliably remove the defect, so the engine
instead measures how far the defect would have to go before it changes the
call, and reports that. **Open** means not even that — and it is listed so
nobody mistakes silence for safety.

---

## The pattern underneath all of them

Five of these defects make the system **more** confident, not less:

- undetected duplicates raise `n`
- bait rows tighten the cluster
- wrongly merged societies enlarge the comp set
- two fabricated rows convert a refusal into a published number

v1 graded confidence on sample size. **Sample size is what every defect
inflates.** Surviving junk bought confidence — the exact inversion of what a
trust layer is for.

That is why v2 stopped asking *"what is the market rate, and how confident am
I?"* and started asking **"what is the verdict, and how hard is it to flip?"**
Confidence is now a property of the decision's stability under attack, not of
how many rows survived filtering. A call that holds when you assume every
defence failed deserves trust that no sample size can justify on its own.

---

## Fixed

### S6 · Society aliasing merged different buildings — critical

v1 clustered society names by character similarity at a 0.82 threshold. On the
case packet that recovered all five societies. At Bangalore scale it is
catastrophic, because builders reuse one prefix across dozens of developments:

```
MERGED (r=0.88)  Prestige Lakeview           + Prestige Lakeside
MERGED (r=0.88)  Sobha Dream Acres           + Sobha Dream Gardens
MERGED (r=0.86)  Salarpuria Sattva Greenage  + Salarpuria Sattva Greenwood
MERGED (r=1.00)  Prestige Lakeview           + Prestige Lake View   ← the only real alias
```

Three of four merges are wrong. The failure is silent and *self-flattering*:
merging two societies produces a larger comp set, which reads as better
evidence. It also gets **worse** as names get more corporate, because a longer
shared prefix raises similarity.

**Fix.** Exact match on the suffix-stripped core. `Lake View Residency`,
`Lakeview Res.` and `Lakeview Residences Phase 1` all reduce to `lakeview`;
`Prestige Lakeside` and `Prestige Lakeview` do not collide. This recovers all
five case-packet societies *and* separates every scale collision — and it
deleted the `society_match_ratio` threshold rather than tuning it. The fuzzy
matching was never buying anything; it was pure risk.

**Residual.** A genuine typo (`Lakevieww`) no longer auto-merges. That is the
correct trade: under-merging shrinks a comp set visibly, over-merging corrupts
it invisibly. Near-misses are queued in `out/alias_registry.csv` for a human,
never applied automatically.

### S5 · One portal supplying nearly every comp — moderate

19 of 20 comps from a single portal passed as `MEDIUM`. v1's check was "at
least 2 distinct sources", which one stray listing satisfies.

**Fix.** A concentration limit, not a distinct count: no portal above 60% of
the comp set, or the tier drops to `LOW` and says which portal dominates.

### S7 · Leave-one-out overstated stability — low

v1 printed *"removing any single listing leaves the median unchanged"*. True,
but only because values tie at the median:

```
drop 1 → Rs 0        drop 2 → Rs 500        drop 3 → Rs 1,000
```

**Fix.** The battery uses worst-case *k*-subset removal — the adversarially
chosen subset, not a random one.

---

## Bounded — the defect survives, the decision is tested against it

### S1 · Cross-post dedup evaded by a date shift — high

v1 required both the posted and last-seen dates to match exactly. That caught
12 of 12 cross-posts here, and **1 of 12** once dates moved by a single day.
Since portals are scraped on different days *by definition*, identical scrape
dates were an artifact of synthetic data — the v1 rule would have been close to
useless in production.

**Improved.** Keyed on posted-date proximity (±2 days), last-seen dropped from
the key entirely since it tracks scrape cadence rather than the home. Swept
0/1/2/3/5/7/14 days: 2 gives 12/12 recall on both the original and the shifted
pull, at one false merge.

**Still broken.** A tolerance is always evadable beyond its width — a 3-day
shift leaks again, and widening costs precision (14 days → 4 false merges for
zero extra recall). A real fix needs photo hashes or description similarity.
`listings.csv` supplies a `photo_count` but no marketplace images and no
description text; the packet's four photos are subject-home site-visit stills,
so neither signal is available for the comps.

**Bounded by attack A1:** the call is re-tested assuming dedup caught nothing
at all and every cross-post double-counted a home.

### S2 · Plausible bait passes the outlier test — high

Four rows at ₹51,000–₹52,500 all survived the MAD test and moved the median
₹59,500 → ₹58,500. Bait posted to harvest leads is *plausibly* cheap, not
absurdly cheap. The ₹12,000 and ₹1,85,000 rows v1 caught were free wins, not
evidence the test works.

Bait sits **inside** the distribution, so no outlier test can reach it.

**Bounded by attacks A3.k:** the call is re-tested with the *k* cheapest
listings removed, for *k* up to 15% of the sample.

**Owned by FLT-7** in the execution plan. The fix is not a better outlier test —
no test reaches inside the distribution — it is capturing what the landlord
quotes when Supply actually calls. Bait is defined by the price changing on
contact, which makes it a missing fact rather than a statistical problem: the
same shape as the maintenance question this engine already refuses on.

---

## Open

### S3 · Systematic aspirational pricing — critical, and unfixable here

Inflating every ask by 8% moves the median **+₹4,760** and the tier stays
`MEDIUM` with a tight interval. Nothing detects it.

I tested the obvious signal — an aspirational ask should sit unsold longer:

```
correlation(days on market, rent) = -0.162   → no usable signal
```

Wrong sign, negligible magnitude. **There is no signal in a listings-only
dataset that separates an aspirational ask from a real one.** Listings are
asks: a ₹70,000 ask that settles at ₹62,000 leaves only ₹70,000 in the data.

This is the most important entry in this document, for two reasons.

**It breaks a headline claim.** The README's central finding — cleaning barely
moves the median because the noise is roughly symmetric — is true of *this
pull*. Real listing noise is one-directional by construction. The null result
may be an artifact of synthetic data rather than a property of the market, and
it is labelled as an assumption, not a finding.

**A confidence interval is the wrong instrument.** The bootstrap measures
*sampling error*. This is *bias*. A tight interval around a biased estimate is
more dangerous than a wide one — it is confidently wrong, which is precisely
the brief's *"a bad market rate looks just as precise on a dashboard as a good
one."*

**Bounded by attack A6**, which sweeps inflation 2–10% and reports where the
call flips. On the case-packet deal:

```
A6.8%   asks inflated 8%  → median Rs 54,740, call becomes ABOVE MARKET
A6.10%  asks inflated 10% → median Rs 53,550, call becomes ABOVE MARKET
```

So the call is stable against ask-inflation up to 6% and flips at 8%. That
turns an unmeasurable risk into a stated threshold.

**Who can resolve it:** nobody working from listings. Only Flent's own signed
rents — Problem 2's dataset — can calibrate the gap between ask and achieved.
This is the concrete dependency between the two problems, and the strongest
argument that the trust layer cannot be finished alone.

### S4 · The refusal is only two rows deep — high

The fully-furnished failure case is the centrepiece of the proof:

```
baseline       n=4  →  INSUFFICIENT EVIDENCE
+2 fake rows   n=6  →  LOW, publishes Rs 68,750
```

Two fabricated rows convert "we don't know" into a number someone will act on.
A `min_n` cliff is a step function applied to a dirty input, and `min_n_low` is
the least defended threshold in the engine — chosen, not measured.

**Partially mitigated:** the robustness battery now runs alongside the tier, so
a two-row answer surfaces as `FRAGILE` rather than silently as `LOW`. **Not
fixed:** the cliff itself remains. The right answer is a graded floor derived
from calibration data, which again needs Problem 2.

### Area basis — high, untested

Indian listings quote carpet, built-up and super built-up area
interchangeably, with differences around 30%. The dedup keys on `area_sqft` and
`max_sqft_per_bedroom` tests it, so a mixed basis both fragments duplicate
detection and misfires the config check.

This is the same class of defect as the maintenance fork: a **unit ambiguity,
not noise**. The maintenance question is not one bug — it is one *instance* of
a category, and only that instance is implemented. A general basis-declaration
mechanism is the right fix.

### The override file — governance, not code

`overrides.csv` lets anyone force any listing in or out, signed with a name
they type themselves. Someone motivated to close a deal can force in exactly
the comps that flatter the ask. **The feature built for trust is the cheapest
way to launder a number.**

Nothing in a local script fixes this. It needs identity, an append-only audit
log, and a reviewer who is not the deal owner.

---

## What would change these conclusions

- **Photo hashes or listing text** would make dedup content-based rather than
  a heuristic tolerance, closing S1 properly.
- **Flent's signed rents** would calibrate the ask-to-achieved gap, closing S3
  and turning the confidence tiers from assertions into measurements.
- **A basis field on the scrape** — is the quoted rent all-in, is the area
  carpet or super built-up — would collapse both fork categories to a lookup.

Two of those three are scraping changes, not modelling ones. The most valuable
next move on this problem is **capturing more about each listing**, not
filtering the existing fields harder.
