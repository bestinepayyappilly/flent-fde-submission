import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import Link from "next/link";
import { FlentMark } from "@/components/flent-mark";
import { Nav, NavInline } from "@/components/nav";
import "./globals.css";

// Geist, the typeface Vercel ships. This replaces the Plus Jakarta Sans that
// matched the BOSS screenshots.
const geist = Geist({
  variable: "--font-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "BOSS · market-listing trust layer",
  description:
    "Raw scraped listings in, a benchmark with an explicit confidence out, or an explicit refusal when the evidence cannot support one.",
};

function Wordmark({ compact }: { compact?: boolean }) {
  return (
    <Link href="/" className="block shrink-0">
      <div className="flex items-baseline gap-2">
        <span
          className={`font-semibold tracking-tight ${
            compact ? "text-[17px]" : "text-[19px]"
          }`}
        >
          BOSS
        </span>
        {/* Height-only sizing keeps the aspect; the baseline row aligns its
            bottom edge with the BOSS baseline, and the mark has no
            descenders, so they sit level. */}
        <FlentMark
          className={`w-auto text-muted-foreground ${
            compact ? "h-[11px]" : "h-[12px]"
          }`}
        />
      </div>
      {!compact && (
        <div className="mt-1 text-[11px] tracking-[0.1em] text-muted-foreground">
          SUPPLY ACQUISITION
        </div>
      )}
    </Link>
  );
}

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={`${geist.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full">
        <div className="flex min-h-screen flex-col lg:flex-row">
          {/* Phone and tablet: a sticky header. The sidebar is hidden below
              lg, and before this there was no way to navigate on a phone. */}
          <header className="sticky top-0 z-30 border-b border-border bg-background/85 px-4 pt-4 backdrop-blur lg:hidden">
            <Wordmark compact />
            <div className="mt-3">
              <NavInline />
            </div>
          </header>

          {/* Sticky and capped at viewport height. As a plain flex item it
              stretched to the DOCUMENT height, which pushed the mt-auto
              footer far below the fold on any long page. */}
          <aside className="hidden w-[248px] shrink-0 flex-col border-r border-border bg-sidebar px-5 py-6 lg:sticky lg:top-0 lg:flex lg:h-screen lg:self-start lg:overflow-y-auto">
            <Wordmark />
            <Nav />
            <div className="mt-auto space-y-2 border-t border-border pt-4 text-[11px] leading-relaxed text-muted-foreground">
              <p className="font-medium tracking-[0.09em] text-foreground/60">
                TRUST LAYER · PROBLEM 1
              </p>
              <p>
                Every number on this site comes from the same program the
                analysis runs. There is no second version of it, so what you
                see here cannot drift from what was actually checked.
              </p>
            </div>
          </aside>

          <main className="min-w-0 flex-1">{children}</main>
        </div>
      </body>
    </html>
  );
}
