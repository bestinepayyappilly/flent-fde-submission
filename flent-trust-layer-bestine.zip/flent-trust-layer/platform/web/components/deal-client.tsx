"use client";

import { ArrowLeft, Ban, Check, Loader2, MessagesSquare } from "lucide-react";
import Link from "next/link";
import { DealView } from "@/components/deal-view";
import { HowToRead } from "@/components/how-to-read";
import { RecordAnswer } from "@/components/record-answer";
import { ResolvingAction } from "@/components/resolving-action";
import { ApiError, DealSkeleton } from "@/components/skeleton";
import {
  getDeal,
  getDeals,
  getPipeline,
  rupees,
  type DealSummary,
  type Pipeline,
} from "@/lib/api";
import { verdictLabel } from "@/lib/labels";
import { useApi } from "@/lib/use-api";
import { useEffect, useRef, useState } from "react";

export function DealClient({ id, tab }: { id: string; tab?: string }) {
  const { data: d, error, loading, reload } = useApi(() => getDeal(id), [id]);

  // Economics exist for the packet deal only. The fully-furnished variant is
  // a what-if on the same record and an upload has no costings at all, so
  // neither gets a money section rather than a guessed one.
  //
  // It loads alongside the score rather than after it: the two are
  // independent, and the money tab is one click away from first paint.
  const {
    data: econ,
    loading: econLoading,
    reload: reloadEcon,
  } = useApi<Pipeline | null>(
    () => (id === "FLT-FDE-2026-01" ? getPipeline() : Promise.resolve(null)),
    [id],
  );

  // What the call was before the last re-score, so the page can say what the
  // answer actually did rather than silently redrawing itself.
  const prevCall = useRef<string | null>(null);
  const [changed, setChanged] = useState<{ from: string; to: string } | null>(
    null,
  );
  const call = d?.verdict.call ?? null;
  useEffect(() => {
    if (!call) return;
    if (prevCall.current && prevCall.current !== call) {
      setChanged({ from: prevCall.current, to: call });
    }
    prevCall.current = call;
  }, [call]);

  // Every other subject is costed from its rent alone by
  // economics.for_subject, and the deals list already carries the result --
  // it is what the pipeline table prints in the payback column. Reading it
  // from the same place means the two screens cannot disagree.
  const { data: subjectEcon, reload: reloadSubject } = useApi<
    DealSummary["economics"]
  >(
    () =>
      id === "FLT-FDE-2026-01"
        ? Promise.resolve(null)
        : getDeals().then((ds) => ds.find((x) => x.id === id)?.economics ?? null),
    [id],
  );

  // An answer changes every view of this deal, not just the verdict: the
  // approach rows are scored from the same fork, so refreshing one and not
  // the other is how the Money tab ends up still saying "needs the
  // maintenance answer" under a card that has already resolved.
  const rescore = () => {
    reload();
    reloadEcon();
    reloadSubject();
  };
  const rescoring = loading || econLoading;

  // Only the first load gets a skeleton. A re-score after an answer keeps
  // the current verdict on screen and marks it stale, because blanking the
  // page would hide the very thing the reader is waiting to see change.
  if (error && !d) return <ApiError error={error} onRetry={reload} />;
  if (!d) return <DealSkeleton />;

  const refuse = d.verdict.call === "INSUFFICIENT_EVIDENCE";
  // Green means "no market objection". Ochre means "go and negotiate". A
  // resolved ABOVE MARKET is an instruction, not a failure, so it must not
  // look like the refusal it replaced.
  const negotiate = d.verdict.call === "ABOVE MARKET";

  // The whole page in four lines, for someone who will not read the rest.
  //
  // Every line is computed from the fields the sections below render at
  // length, so a summary cannot drift from what it summarises. Nothing is
  // asserted that the engine did not produce: where a fact is missing the
  // row is dropped rather than filled in.
  const showsRate = d.verdict.published_benchmark && d.benchmark.median !== null;
  const tldr: { k: string; v: string }[] = [];

  // Only when the line above it did not already say so.
  if (!showsRate) {
    tldr.push({
      k: "The number",
      v: `None. ${d.benchmark.n} comparable ${
        d.benchmark.n === 1 ? "home" : "homes"
      } is below the floor for publishing a benchmark, so nothing is published rather than published weakly.`,
    });
  }

  if (d.fork) {
    // The engine's own signed formatter reads "-5.9% below", which says the
    // direction twice. Here the word carries it and the number does not.
    const delta = (b: typeof d.fork.base) =>
      `${(Math.abs(b.pct) * 100).toFixed(1)}% ${b.above ? "above" : "below"}`;
    const side = (b: typeof d.fork.base) =>
      `${rupees(b.compare)} reads ${delta(b)}`;
    const chosen =
      d.answer && d.answer_choices[d.answer.answer]?.compare === "all_in"
        ? d.fork.all_in
        : d.fork.base;

    if (d.fork.straddles) {
      tldr.push({
        k: "The catch",
        v: `The comps do not agree on what "rent" covers, and the two readings sit ${rupees(
          d.fork.spread,
        )} a month apart: our base rent ${side(
          d.fork.base,
        )}, our all-in cost ${side(
          d.fork.all_in,
        )}. Opposite answers off the same clean data.`,
      });
    } else if (d.answer) {
      // `straddles` is forced false once an answer lands, so the raw branches
      // may still disagree. Claiming they agree here would be a lie the
      // engine never told.
      tldr.push({
        k: "Now settled",
        v: `${
          d.answer_choices[d.answer.answer]?.label ?? d.answer.answer
        }, so we compare our ${rupees(chosen.compare)} — ${delta(
          chosen,
        )} the benchmark. The other reading is out of play. Recorded by ${
          d.answer.who
        } on ${d.answer.at.slice(0, 10)}.`,
      });
    } else if (d.fork.base.above === d.fork.all_in.above) {
      tldr.push({
        k: "The check",
        v: `Both readings land the same side of the benchmark — base rent ${side(
          d.fork.base,
        )}, all-in ${side(
          d.fork.all_in,
        )} — so the maintenance question cannot change the call.`,
      });
    }
  }

  if (d.robustness) {
    // "A and B and C" is not a list. This is the only place several attack
    // ids print in one sentence.
    const ids = d.robustness.flipped.map((f) => f.id);
    const list =
      ids.length > 1
        ? `${ids.slice(0, -1).join(", ")} and ${ids[ids.length - 1]}`
        : ids[0];
    tldr.push({
      k: "How solid",
      v: `The call held under ${d.robustness.survived} of ${
        d.robustness.total
      } attempts to break it${
        ids.length > 0 ? `, and flips only under ${list}` : ""
      }.`,
    });
  }

  if (d.verdict.action) {
    // Deliberately does not repeat the question. It is set in full in the
    // panel beside this one, and quoting it twice in one screen reads as
    // padding — but "the panel on the right" is wrong on a phone, where that
    // panel is below, so this points at the act rather than the place.
    const stop = (s: string) =>
      /[.?!]$/.test(s.trim()) ? s.trim() : `${s.trim()}.`;
    tldr.push({
      k: "What to do",
      v: `${d.verdict.action.owner} has one question to put to the landlord. ${stop(
        d.verdict.action.cost,
      )} Recording the answer re-scores the deal for everyone.`,
    });
  }

  return (
    <div className="px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
      <Link
        href="/"
        className="inline-flex items-center gap-1.5 text-[13px] font-medium text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-3.5" aria-hidden />
        Deals
      </Link>

      <h1 className="mt-3 text-[24px] font-semibold leading-tight tracking-tight sm:text-[30px] lg:text-[34px]">
        {d.deal.society} · {d.deal.bhk}BHK
      </h1>
      <p className="mt-1.5 text-[13px] text-muted-foreground">
        {d.deal.furnishing} · {d.deal.id} · data as of {d.deal.snapshot} ·
        landlord asking {rupees(d.deal.base_rent)} rent plus{" "}
        {rupees(d.deal.maintenance)} maintenance
      </p>
      <p className="mt-3 max-w-3xl text-[13.5px] italic leading-relaxed text-muted-foreground">
        {d.deal.note}
      </p>

      <div className="mt-5">
        <HowToRead />
      </div>

      {/* The hero. In BOSS this block is a green ACQUIRE. Here it is a
          refusal — same slot, same weight, because "we don't know yet" is a
          first-class output rather than a missing one. */}
      <div
        className={`mt-6 grid items-start gap-4 lg:gap-5 ${
          d.verdict.action
            ? "lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)]"
            : "lg:grid-cols-1"
        }`}
      >
        <div
          className={`rounded-lg p-6 sm:p-7 ${
            refuse || negotiate
              ? "border border-refuse-border bg-refuse-bg text-refuse"
              : "border border-acquire-border bg-acquire-bg text-acquire"
          }`}
        >
          <div className="flex items-center gap-3">
            <span
              className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${
                refuse || negotiate ? "bg-refuse/12" : "bg-acquire/12"
              }`}
            >
              {refuse ? (
                <Ban className="size-4.5" aria-hidden />
              ) : negotiate ? (
                <MessagesSquare className="size-4.5" aria-hidden />
              ) : (
                <Check className="size-4.5" aria-hidden />
              )}
            </span>
            <span className="text-[22px] font-semibold leading-tight tracking-tight sm:text-[28px]">
              {verdictLabel(d.verdict.call)}
            </span>
            {/* The engine is re-running against the answer just recorded. The
                figures below are the previous ones until it returns. */}
            {rescoring && (
              <span
                className="inline-flex items-center gap-1.5 rounded-full border border-current/25 px-2.5 py-1 text-[11px] font-medium opacity-80"
                role="status"
              >
                <Loader2 className="size-3 animate-spin" aria-hidden />
                Re-scoring
              </span>
            )}
          </div>

          {/* Said once, plainly, after the score actually moves. Without this
              the page silently redraws and the reader has to work out for
              themselves whether their answer did anything. */}
          {changed && !rescoring && (
            <p className="mt-4 flex flex-wrap items-center gap-x-2 gap-y-1 rounded-md border border-current/20 px-3 py-2 text-[12.5px] font-medium">
              <Check className="size-3.5 shrink-0" aria-hidden />
              Answer recorded. This deal moved from{" "}
              {verdictLabel(changed.from)} to {verdictLabel(changed.to)}.
            </p>
          )}
          <p
            className={`mt-5 text-[14px] leading-relaxed transition-opacity ${
              rescoring ? "opacity-50" : "opacity-90"
            }`}
          >
            {d.verdict.detail}
          </p>
          {d.verdict.published_benchmark && d.benchmark.median !== null && (
            <p className="mt-4 border-t border-current/15 pt-4 text-[13px] leading-relaxed opacity-80">
              Market rate{" "}
              <span className="font-medium">
                {rupees(d.benchmark.median)} a month
              </span>
              , from {d.benchmark.n} similar homes.
              {!d.verdict.resolved &&
                " What we cannot tell you is whether this deal sits above or below it."}
            </p>
          )}

          {tldr.length > 0 && (
            <div className="mt-5 border-t border-current/15 pt-4">
              <div className="text-[11px] font-medium tracking-[0.07em] opacity-70">
                TL;DR
              </div>
              <dl className="mt-3 space-y-2.5">
                {tldr.map((r) => (
                  <div
                    key={r.k}
                    className="flex flex-col gap-x-4 gap-y-0.5 sm:flex-row"
                  >
                    <dt className="shrink-0 text-[12.5px] font-semibold sm:w-[92px]">
                      {r.k}
                    </dt>
                    <dd className="text-[12.5px] leading-relaxed opacity-85">
                      {r.v}
                    </dd>
                  </div>
                ))}
              </dl>
            </div>
          )}
        </div>

        {d.verdict.action ? (
          <ResolvingAction
            question={d.verdict.action.question}
            owner={d.verdict.action.owner}
            cost={d.verdict.action.cost}
            unlocks={d.verdict.action.unlocks}
          >
            <RecordAnswer
              dealId={d.deal.id}
              answer={d.answer}
              log={d.answer_log}
              choices={d.answer_choices}
              onRecorded={rescore}
              rescoring={rescoring}
            />
          </ResolvingAction>
        ) : (
          d.answer && (
            <div className="rounded-lg border border-border bg-card p-6 sm:p-7">
              <RecordAnswer
                dealId={d.deal.id}
                answer={d.answer}
                log={d.answer_log}
                choices={d.answer_choices}
                onRecorded={rescore}
                rescoring={rescoring}
              />
            </div>
          )
        )}
      </div>

      <DealView
        d={d}
        initialTab={tab}
        econ={econ}
        subjectEcon={subjectEcon}
      />
    </div>
  );
}
