#!/usr/bin/env python3
"""
What Flent's own history says about which forecast is wrong.

    python3 outcomes_check.py

The trust layer assumes the market rate is the input worth making honest.
case-packet/outcomes.csv is the only file in the packet that can test that
assumption, because it pairs what was predicted at acquisition with what
actually happened by day 90. Nothing else here has been checked against
reality.

Read this before believing the rest of the submission. It does not confirm
the thesis.

Every number printed is computed from the packet. Where the sample is too
small to support a claim, the run says so rather than rounding the doubt
away.
"""

import csv
import os
import statistics
from math import comb

HERE = os.path.dirname(os.path.abspath(__file__))
PATH = os.path.join(HERE, "..", "case-packet", "outcomes.csv")


def num(v):
    return float(v) if v not in ("", None) else None


def load():
    with open(PATH) as fh:
        return list(csv.DictReader(fh))


def sign_test(ratios, worse_is_above=True):
    """
    Probability of seeing a split this lopsided if the forecast were unbiased.

    A coin-flip null: with no systematic bias, each case should land either
    side with equal chance. Reported two-sided, and reported even when it
    fails to reach significance -- especially then.
    """
    n = len(ratios)
    k = sum(1 for r in ratios if (r > 1.0 if worse_is_above else r < 1.0))
    hi = max(k, n - k)
    p_one = sum(comb(n, i) for i in range(hi, n + 1)) / 2 ** n
    return k, n, min(1.0, 2 * p_one)


def ratios(rows, pred, act):
    out = []
    for r in rows:
        p, a = num(r[pred]), num(r[act])
        if p and a:
            out.append((r["case_id"], p, a, a / p))
    return out


def rule(ch="-"):
    print("  " + ch * 74)


def main():
    rows = load()
    observed = [r for r in rows if r["outcome_status"] == "observed"]
    other = [r for r in rows if r["outcome_status"] != "observed"]

    print("\n" + "=" * 78)
    print("  WHICH FORECAST IS ACTUALLY WRONG")
    print("  case-packet/outcomes.csv  ·  Flent's own acquisition history")
    print("=" * 78)

    print(f"\n  {len(rows)} historical cases. {len(observed)} observed to day 90.")
    print("  The rest are excluded because they have no actual to compare:")
    for r in other:
        print(f"    {r['case_id']}  {r['outcome_status']:24} {r['notes'][:44]}")

    # --- the three forecasts, side by side ---------------------------------
    tests = [
        ("Tenant revenue", "predicted_tenant_revenue",
         "actual_tenant_revenue_day_90", False),
        ("Days to fill", "predicted_full_fill_days",
         "actual_full_fill_days", True),
        ("Payback months", "predicted_payback_months",
         "actual_payback_months_day_90", True),
    ]

    print("\n\n  HOW EACH FORECAST HELD UP\n")
    print(f"  {'forecast':18}{'median actual/plan':>20}{'worse than plan':>18}"
          f"{'sign test':>16}")
    rule()
    results = {}
    for label, pred, act, worse_above in tests:
        rs = ratios(observed, pred, act)
        vals = [r[3] for r in rs]
        med = statistics.median(vals)
        k, n, p = sign_test(vals, worse_above)
        results[label] = (med, vals, p)
        print(f"  {label:18}{med:>20.3f}{f'{k} of {n}':>18}{f'p = {p:.3f}':>16}")

    rev_med = results["Tenant revenue"][0]
    fill_med = results["Days to fill"][0]

    print("\n\n  THE FINDING\n")
    print(f"  Revenue forecasts land within {abs(1 - rev_med) * 100:.0f}% of plan.")
    print(f"  Fill-time forecasts are out by {(fill_med - 1) * 100:.0f}%.")
    print()
    print("  The pricing is close to right. The timing is not. Payback misses")
    print("  because homes take longer to fill than anyone planned, not")
    print("  because the rent was wrong.")

    # --- what it costs -----------------------------------------------------
    fills = ratios(observed, "predicted_full_fill_days", "actual_full_fill_days")
    extra = [a - p for _, p, a, _ in fills]
    med_extra = statistics.median(extra)
    print("\n\n  WHAT THE TIMING MISS COSTS\n")
    over = sorted(extra)
    mean_extra = statistics.mean(extra)
    tail = [d for d in extra if d >= 20]
    print(f"  Median overrun {med_extra:.0f} days, mean {mean_extra:.0f} days.")
    print(f"  Spread: {', '.join(f'{d:+.0f}' for d in over)}")
    print()
    print("  The mean is four times the median, so this is not a flat tax on")
    print(f"  every deal. {len(tail)} of {len(extra)} ran 20+ days late; the rest were close")
    print("  to plan. The brief puts ten extra vacancy days at a month of")
    print("  breakeven, so those two cost roughly")
    print(f"  {min(tail) / 10:.1f} to {max(tail) / 10:.1f} months of payback each, while the median deal")
    print(f"  lost about {med_extra / 10:.1f}.")
    print()
    print("  That shape matters more than the average. A tail risk needs a")
    print("  different fix from a systematic bias: you cannot correct it with")
    print("  a multiplier, you have to catch the cases early.")

    # --- why ---------------------------------------------------------------
    print("\n\n  WHY, IN FLENT'S OWN WORDS\n")
    worst = sorted(fills, key=lambda x: -x[3])[:3]
    by_id = {r["case_id"]: r for r in observed}
    for cid, p, a, ratio in worst:
        print(f"  {cid}  {p:.0f} -> {a:.0f} days  ({ratio:.2f}x)")
        print(f"      {by_id[cid]['notes']}")
    print()
    print("  None of these are pricing errors. One is a clock that starts at")
    print("  handover while the work runs late. One is a three-room average")
    print("  hiding a room nobody wanted. They are measurement problems of")
    print("  exactly the kind this trust layer was built for -- applied to the")
    print("  wrong input.")

    # --- what this does NOT establish --------------------------------------
    print("\n\n  WHAT THIS DOES NOT ESTABLISH\n")
    _, _, p_fill = results["Days to fill"]
    print(f"  Ten observed cases. The sign test returns p = {p_fill:.3f}, so the")
    print("  direction is consistent but NOT significant at the 5% level. This")
    print("  is evidence worth acting on, not proof.")
    print()
    print("  It is also biased OPTIMISTIC. The four excluded cases include one")
    print("  still filling and one cancelled before launch. A home still")
    print("  filling at the observation date is a slow fill by definition, so")
    print("  dropping it understates the overrun. The real number is worse")
    print("  than 23%.")
    print()
    print("  And these are sanitised exercise records, not production data.")

    print("\n\n  WHAT I WOULD CHANGE\n")
    print("  The execution plan makes calibrating the market rate the first")
    print("  thing to validate. This says it should be second. Fill time is")
    print("  the larger error, it is measurable from data Flent already has,")
    print("  and unlike aspirational pricing it has named causes that can be")
    print("  fixed one at a time.")
    print()
    print("  The trust layer still stands: a benchmark nobody can argue with")
    print("  is worth building, and refusing beats guessing. But it is not")
    print("  where this portfolio is losing money.")
    print("\n" + "=" * 78 + "\n")


if __name__ == "__main__":
    main()
