# determinate-acquire

**SYNTHETIC. Every row here is fabricated.**

The subject is well below the comps on BOTH readings: base 52,000 and all-in 55,000 against a benchmark near 65,000. The maintenance convention is just as unresolved as on the real deal, but here it cannot change the answer.

**Expected:** gives a determinate BELOW MARKET call: the rent is defensible, sign it

22 listings.
