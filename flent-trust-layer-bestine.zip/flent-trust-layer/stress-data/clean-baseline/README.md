# clean-baseline

**SYNTHETIC. Every row here is fabricated.**

A healthy pull: 24 comparables, four portals, no injected defect. The control case. If this one refuses, something is wrong with the engine rather than with the data.

**Expected:** publishes a benchmark at MEDIUM or better

24 listings.
