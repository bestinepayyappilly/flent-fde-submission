# Deal record — FLT-FDE-2026-01

Captured by Supply on **17 August 2026**. Evidence cut-off: **18 August 2026**.

## Home

| Field | Recorded value |
|---|---|
| Society | Lakeview Residences *(anonymised)* |
| Locality | Harlur–Sarjapur Road micromarket, Bengaluru |
| Configuration | 2 BHK, 2 bathrooms, 1 balcony |
| Built-up area | 1,175 sq ft *(owner-stated; floor plan not supplied)* |
| Furnishing | Semi-furnished: wardrobes, kitchen cabinets, geysers and lights |
| Floor | 2 of 12 |
| Outlook | Internal courtyard |
| Availability | Keys available; owner proposes a 1 September start |

## Landlord's opening ask

| Term | Recorded value |
|---|---|
| Base rent | ₹56,000 per month |
| Society maintenance | ₹5,000 per month, payable by Flent |
| Total monthly owner cost | ₹61,000 |
| Security deposit | ₹2,80,000 |
| Escalation | 7% after month 11 |
| Rent-free period | 15 days from handover |
| Contract term | 33 months |
| Lock-in | 11 months |
| Notice | 3 months after lock-in |
| Exit charge | One month's base rent for painting |

The Supply owner wrote that the landlord *may* consider ₹54,000 base rent if Flent
keeps the full deposit and signs within the week. That alternative is verbal and is
not an agreed term.

## Working estimates, not agreed facts

| Input | Current working value | Evidence status |
|---|---:|---|
| Improvement / furnishing capex | ₹1,60,000 | Property team's placeholder; no vendor BOQ |
| Tenant revenue | ₹72,000 per month across two rooms | Pricing hypothesis; no signed tenants |
| Tenant deposits | ₹1,80,000 total | Finance assumption based on 2.5 months of hypothesised revenue |
| First-fill time | 18 days for room 1; 32 days for room 2 | Demand estimate from a small nearby sample |

## Custom terms and constraints

- Working professionals sharing the home are allowed, subject to society KYC.
- Pets are allowed, but the owner asks Flent to cover any society penalty.
- Flent must service the installed geysers and chimney after handover.
- The owner says there are no pending society dues; no statement has been supplied.

## Not supplied by the evidence cut-off

- Signed term sheet or written confirmation of the ₹54,000 alternative.
- Floor plan or independent area measurement.
- Maintenance invoice and society-dues statement.
- Vendor BOQ for capex.
- Electrical-load, plumbing, seepage and appliance inspection sign-off.
- Signed tenant or room-level price evidence.
