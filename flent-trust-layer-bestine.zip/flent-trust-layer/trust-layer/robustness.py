"""
Verdict robustness  ·  the v2 core

v1 asked: "what is the market rate, and how confident am I?"
Confidence was a function of n -- which is exactly backwards, because every
undetected duplicate, every bait row and every wrongly merged society RAISES
n. Surviving junk bought confidence. That is the precise inversion of what a
trust layer is for.

v2 asks: "what is the verdict, and how hard is it to flip?"

The shift matters because some of the defects found in stress testing cannot
be cleaned at all:

  - Aspirational pricing (landlords ask high) leaves no signal in a
    listings-only dataset. Measured on this packet, the correlation between
    days-on-market and rent is -0.16: nothing usable.
  - Duplicate detection is a tolerance, so it is always evadable by spacing
    posts beyond it. Content signals (photo hashes, description similarity)
    would fix it; the packet has neither.

Neither can be filtered away. Both can be BOUNDED: instead of pretending the
comp set is clean, assume each defence fails and ask whether the decision
still holds. A verdict that survives every attack we can construct deserves
trust that no sample size can justify on its own.
"""

from __future__ import annotations

import itertools
import statistics

ABOVE, BELOW, AT = "ABOVE MARKET", "BELOW MARKET", "AT MARKET"

# What each position means for the person signing. Two positions that imply
# the same action are not a disagreement worth refusing over.
ACTION = {
    ABOVE: "NEGOTIATE -- market evidence says we are overpaying",
    AT: "NO MARKET OBJECTION -- the ask is defensible",
    BELOW: "NO MARKET OBJECTION -- the ask is defensible",
    "INSUFFICIENT": "UNRESOLVED",
}
# When two positions imply the same action, report the more cautious one.
ORDER = {BELOW: 0, AT: 1, ABOVE: 2, "INSUFFICIENT": 3}


def position(median: float, compare: float, deadband: float) -> str:
    """Where the subject sits, with a deadband so noise cannot flip a verdict."""
    if median is None:
        return "INSUFFICIENT"
    delta = (compare - median) / median
    if abs(delta) < deadband:
        return AT
    return ABOVE if delta > 0 else BELOW


def verdict(median, subject: dict, deadband: float) -> dict:
    """
    The decision, across every unresolved basis convention.

    A basis ambiguity is not noise -- it is a missing field. The maintenance
    question is one instance of a category: are the comps and the subject
    measuring the same thing? When the branches disagree, no amount of
    cleaning resolves it and the honest answer is a refusal plus the cheapest
    question that would settle it.
    """
    branches = {
        "listings quote base rent": subject["base_rent"],
        "listings quote all-in rent": subject["all_in"],
    }
    positions = {k: position(median, v, deadband) for k, v in branches.items()}

    # Refuse on a disagreement about the ACTION, not about the label.
    # AT MARKET and BELOW MARKET are different descriptions of the same
    # decision -- market evidence does not argue against signing. Only a
    # split into "negotiate" versus "no objection" actually costs anyone
    # anything, and only that should stop the engine committing.
    actions = {k: ACTION[p] for k, p in positions.items()}
    distinct_actions = set(actions.values())
    distinct_pos = set(positions.values())
    return {
        "branches": branches,
        "positions": positions,
        "actions": actions,
        "agreed": len(distinct_actions) == 1,
        "verdict": (sorted(distinct_pos, key=lambda p: ORDER[p])[-1]
                    if len(distinct_actions) == 1 else "INSUFFICIENT"),
        "action": (distinct_actions.pop() if len(distinct_actions) == 1
                   else "UNRESOLVED"),
    }


# ---------------------------------------------------------------------------
# The perturbation battery
# ---------------------------------------------------------------------------
#
# Each attack encodes a defect that stress testing actually demonstrated
# against v1. They are not hypothetical; every one has a reproduction in
# stress_test.py.

def _median(vals):
    return statistics.median(vals) if vals else None


def attacks(included: list, redundant: list, max_bias: float = 0.10):
    """
    Yield (attack_id, description, mutated_rents).

    `included` are the surviving comps; `redundant` are the rows dedup
    removed, needed to simulate dedup failing.
    """
    vals = sorted(r.rent for r in included)
    n = len(vals)
    k_max = max(1, round(n * 0.15))

    # A1 -- dedup failed entirely. The rule is a tolerance and therefore
    # evadable; assume every cross-post survived and double-counted a home.
    if redundant:
        merged = sorted(vals + [r.rent for r in redundant])
        yield ("A1", f"dedup failed: {len(redundant)} cross-posts double-counted",
               merged)

    # A2 -- dedup over-merged. The mirror risk: distinct homes collapsed.
    if redundant:
        yield ("A2", "dedup over-merged: representatives replaced by their "
                     "highest-rent twin",
               sorted([max(r.rent for r in redundant)] + vals[1:]))

    # A3/A4 -- plausible bait and aspirational outliers sit INSIDE the
    # distribution, so the MAD test cannot see them. Drop the tails instead.
    for k in range(1, k_max + 1):
        yield (f"A3.{k}", f"{k} cheapest listings were bait", vals[k:])
        yield (f"A4.{k}", f"{k} dearest listings were aspirational", vals[:-k])

    # A5 -- worst-case removal. Not random: the k-subset that moves the
    # median furthest. If the verdict survives an adversary choosing which
    # rows to delete, sampling noise is not going to break it.
    for k in range(1, min(k_max, 3) + 1):
        worst, worst_gap = None, -1.0
        base = _median(vals)
        for combo in itertools.combinations(range(n), k):
            rest = [v for i, v in enumerate(vals) if i not in combo]
            gap = abs(_median(rest) - base)
            if gap > worst_gap:
                worst, worst_gap = rest, gap
        yield (f"A5.{k}", f"worst-case removal of {k} listings "
                          f"(moves median Rs {worst_gap:,.0f})", worst)

    # A6 -- systematic aspirational inflation. Listings are ASKS. If landlords
    # systematically ask b% above what they accept, true market is lower by b.
    # No signal in the data can detect this, so it is swept rather than
    # estimated: the output states the inflation level at which the call flips.
    step = 0.02
    b = step
    while b <= max_bias + 1e-9:
        yield (f"A6.{b:.0%}", f"asks inflated {b:.0%} above achieved rents",
               [v * (1 - b) for v in vals])
        b += step

    # A7 -- one portal dominates. A distinct-source count is trivially
    # satisfied by a single stray listing, so drop each portal in turn.
    by_source: dict = {}
    for r in included:
        by_source.setdefault(r.source, []).append(r.rent)
    if len(by_source) > 1:
        for src, rents in by_source.items():
            share = len(rents) / n
            if share >= 0.25:
                rest = [r.rent for r in included if r.source != src]
                yield (f"A7.{src}", f"portal {src} ({share:.0%} of comps) "
                                    "excluded", sorted(rest))

    # A8 -- broker listings may be marked up relative to owner listings.
    owners = [r.rent for r in included if r.poster == "owner"]
    if 2 <= len(owners) < n:
        yield ("A8", f"owner-posted listings only ({len(owners)} of {n})",
               sorted(owners))


def assess(included: list, redundant: list, subject: dict,
           deadband: float, max_bias: float = 0.10) -> dict:
    """Run the battery and report which attacks flip the call."""
    vals = sorted(r.rent for r in included)
    base_med = _median(vals)
    base = verdict(base_med, subject, deadband)

    survived, flipped = [], []
    for aid, desc, mutated in attacks(included, redundant, max_bias):
        if not mutated:
            continue
        v = verdict(_median(mutated), subject, deadband)
        row = {
            "id": aid, "description": desc,
            "median": _median(mutated), "verdict": v["verdict"],
        }
        (survived if v["verdict"] == base["verdict"] else flipped).append(row)

    total = len(survived) + len(flipped)
    return {
        "base": base,
        "median": base_med,
        "survived": survived,
        "flipped": flipped,
        "total": total,
        "stability": (len(survived) / total) if total else 0.0,
        "tier": _tier(base, survived, flipped),
    }


def _tier(base: dict, survived: list, flipped: list) -> str:
    """
    Confidence is a property of the DECISION, not of the sample.

    Deliberately not a function of n. n is what every defect inflates, so
    grading on it rewards exactly the junk this layer exists to remove.
    """
    if base["verdict"] == "INSUFFICIENT":
        return "REFUSED"
    if not flipped:
        return "ROBUST"
    ratio = len(survived) / (len(survived) + len(flipped))
    if ratio >= 0.85:
        return "CONDITIONAL"
    return "FRAGILE"


def report(a: dict, subject: dict, rupees) -> None:
    print("\n\nVERDICT ROBUSTNESS · does the call survive being attacked?\n")
    print("  Confidence here is NOT a function of sample size. Every defect")
    print("  found in stress testing -- undetected duplicates, bait, merged")
    print("  societies -- RAISES n. Grading on n rewards the junk this layer")
    print("  exists to remove. So the question is not how much evidence there")
    print("  is, but how hard the decision is to overturn.")
    print()
    for label, compare in a["base"]["branches"].items():
        pos = a["base"]["positions"][label]
        print(f"    if {label:<30} ({rupees(compare)})  ->  {pos}")
    print()
    print(f"  CALL        {a['base']['verdict']}")
    print(f"  ACTION      {a['base']['action']}")
    print(f"  ROBUSTNESS  {a['tier']}  "
          f"({len(a['survived'])} of {a['total']} attacks survived)")

    if a["flipped"]:
        print()
        print(f"  The call changes under {len(a['flipped'])} attack(s):")
        for f in a["flipped"][:8]:
            print(f"    [{f['id']:<8}] {f['description']}")
            print(f"               -> median {rupees(f['median'])}, "
                  f"call becomes {f['verdict']}")
        if len(a["flipped"]) > 8:
            print(f"    ... and {len(a['flipped']) - 8} more")
    else:
        print()
        print("  No attack in the battery changes the call.")
