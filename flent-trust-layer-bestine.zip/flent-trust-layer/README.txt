Flent - Forward Deployed Engineer take-home
============================================

What's in this folder

1. Flent-FDE-take-home-brief.pdf
   The brief. Start here. Nine pages: what BOSS is for, what feeds it, three
   problems we haven't solved, what we'd like you to build, and how we'll read it.

2. BOSS-context-pack-for-AI.md
   A longer explanation of BOSS written to be pasted straight into Claude, GPT or
   whichever assistant you use. Use it to brainstorm and to challenge your own
   approach. It ends with a ready-to-use prompt.

3. screenshots/
   Two captures of the current BOSS interface populated with seeded, sanitised
   demo records (a scored deal and the deal pipeline). See screenshots/README.md.

4. case-packet/
   The anonymised deal, raw comparable listings, historical prediction-versus-
   outcome records and provisional BOSS assessment. See case-packet/README.md.

How to submit

Reply to the email that carried this folder within seven calendar days with your
approach note (PDF or deck), your proof of work (link, prototype, repo or short
video) and your execution plan. You'll hear back from us either way.
