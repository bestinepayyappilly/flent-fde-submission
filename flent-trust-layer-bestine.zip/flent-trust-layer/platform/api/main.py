"""
BOSS trust layer — read API.

Thin by design. Every number this serves is computed by trust_layer.py, the
same script the CLI runs. There is no second implementation of the pipeline
here, so the UI cannot drift from the proof.
"""

import os

import csv
import io as _io
import json
import shutil
import tempfile

from fastapi import Body, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

import answers
import economics
import engine


def rupees_plain(v):
    return f"\u20b9{v:,.0f}"

app = FastAPI(
    title="BOSS trust layer",
    description=(
        "Market-listing trust layer for BOSS. Raw scraped listings in, a "
        "benchmark with an explicit confidence out — or an explicit refusal "
        "when the evidence cannot support one."
    ),
    version="1.0.0",
)

# The frontend is deployed separately (Vercel), so it is cross-origin.
_origins = os.environ.get("ALLOWED_ORIGINS", "*")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in _origins.split(",")] if _origins != "*" else ["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# Scoring the packet is fast but not free, and the inputs are static files.
# Cache per deal id; a real deployment would key this on the pull's snapshot.
_cache = {}


def _scored(deal_id: str) -> dict:
    if deal_id not in engine.DEALS:
        raise HTTPException(404, f"unknown deal '{deal_id}'")
    if deal_id not in _cache:
        _cache[deal_id] = engine.score(deal_id)
    return _cache[deal_id]


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/api/deals")
def list_deals():
    """Triage list — every configuration, with its call."""
    return {"deals": engine.deals()}


@app.get("/api/deals/{deal_id}")
def get_deal(deal_id: str):
    """Everything: cascade, benchmark, fork, robustness, verdict, policy."""
    return _scored(deal_id)


@app.get("/api/deals/{deal_id}/ledger")
def get_ledger(deal_id: str, status: str = "", q: str = ""):
    """
    All 86 rows, every one accounted for. The engine never deletes, so this
    is the whole pull with a status and a reason on each row — not the
    survivors.
    """
    rows = _scored(deal_id)["listings"]
    if status:
        wanted = {s.strip().upper() for s in status.split(",")}
        rows = [r for r in rows if r["status"] in wanted]
    if q:
        n = q.lower()
        rows = [
            r for r in rows
            if n in r["id"].lower()
            or n in (r["society_raw"] or "").lower()
            or n in (r["source"] or "").lower()
            or n in (r["reason"] or "").lower()
        ]
    return {"count": len(rows), "listings": rows}


@app.get("/api/deals/{deal_id}/policy")
def get_policy(deal_id: str):
    """
    Thresholds with provenance. The engine refuses any listing arriving
    without a source and a freshness; holding its own numbers to a lower
    standard would be incoherent.
    """
    pol = _scored(deal_id)["policy"]
    counts = {}
    for t in pol:
        counts[t["provenance"]] = counts.get(t["provenance"], 0) + 1
    return {"thresholds": pol, "counts": counts}


@app.get("/api/deals/{deal_id}/aliases")
def get_aliases(deal_id: str):
    """Learned society clusters, for human review rather than blind trust."""
    return {"clusters": _scored(deal_id)["aliases"]}


# ---------------------------------------------------------------------------
# UPLOAD
# ---------------------------------------------------------------------------

MAX_BYTES = 4 * 1024 * 1024      # a 27,000-row pull is well under this
MAX_ROWS = 20000


@app.get("/api/upload/spec")
def upload_spec():
    """What a caller has to provide, so the UI does not hardcode it."""
    return {
        "listings_csv": {
            "required": True,
            "columns": engine.REQUIRED_LISTING_COLUMNS,
            "note": (
                "Header row required. area_sqft and deposit may be blank; "
                "blanks stay blank and are never filled in."
            ),
        },
        "deal_json": {
            "required": True,
            "fields": engine.REQUIRED_DEAL_FIELDS,
            "note": (
                "A deal missing any of these is rejected outright rather "
                "than defaulted."
            ),
            "example": {
                "deal_id": "MY-DEAL-01",
                "snapshot": "2026-08-18",
                "society": "Lakeview Residences",
                "locality": "Harlur-Sarjapur Road",
                "bhk": "2",
                "furnishing": "semi-furnished",
                "base_rent": 56000,
                "maintenance": 5000,
            },
        },
        "overrides_csv": {
            "required": False,
            "columns": ["listing_id", "decision", "who", "why"],
            "note": (
                "decision is include or exclude. A named human outranks "
                "every rule in both directions, and the overridden rule "
                "stays visible in the ledger."
            ),
        },
        "limits": {"max_bytes": MAX_BYTES, "max_rows": MAX_ROWS},
    }


async def _save(upload: UploadFile, dest: str) -> bytes:
    data = await upload.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(413, f"{upload.filename} exceeds {MAX_BYTES} bytes")
    with open(dest, "wb") as fh:
        fh.write(data)
    return data


@app.post("/api/upload")
async def upload(
    listings: UploadFile = File(...),
    deal: UploadFile = File(...),
    overrides: UploadFile | None = File(None),
):
    """
    Score an uploaded pull through the same pipeline as everything else.

    Nothing is persisted. The files live in a temp directory for the length
    of one request and are deleted afterwards.
    """
    work = tempfile.mkdtemp(prefix="trust-upload-")
    try:
        lpath = f"{work}/listings.csv"
        dpath = f"{work}/deal.json"
        raw = await _save(listings, lpath)
        await _save(deal, dpath)

        # Validate before handing anything to the engine, so a bad upload
        # gets a useful message instead of a stack trace.
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            raise HTTPException(400, "listings file is not UTF-8 text")

        reader = csv.reader(_io.StringIO(text))
        try:
            header = next(reader)
        except StopIteration:
            raise HTTPException(400, "listings file is empty")
        missing = [c for c in engine.REQUIRED_LISTING_COLUMNS
                   if c not in header]
        if missing:
            raise HTTPException(
                400,
                "listings file is missing required columns: "
                + ", ".join(missing),
            )
        if sum(1 for _ in reader) > MAX_ROWS:
            raise HTTPException(413, f"more than {MAX_ROWS} listing rows")

        try:
            json.loads(open(dpath, encoding="utf-8-sig").read())
        except (ValueError, UnicodeDecodeError) as e:
            raise HTTPException(400, f"deal file is not valid JSON: {e}")

        # overrides.csv is read from the work dir by name, if supplied.
        if overrides is not None and overrides.filename:
            await _save(overrides, f"{work}/overrides.csv")

        try:
            return engine.score_upload(lpath, dpath, work)
        except engine.UploadError as e:
            raise HTTPException(400, str(e))
    finally:
        shutil.rmtree(work, ignore_errors=True)


# ---------------------------------------------------------------------------
# PIPELINE
# ---------------------------------------------------------------------------

@app.get("/api/pipeline")
def pipeline():
    """
    The deal as an acquisition lead sees it: BOSS's own economics beside the
    one column this layer produces.

    The economics come from case-packet/boss-assessment.md and are recomputed
    from its inputs rather than copied, so a bad encoding shows up as a
    mismatch. The trust layer contributes `market` and nothing else, which is
    the boundary the UI states rather than blurs.
    """
    s = _scored("FLT-FDE-2026-01")
    bm, v = s["benchmark"], s["verdict"]

    if bm["median"] is None:
        market = {"label": "THIN", "detail": "too few comparable homes to price"}
    elif v["call"] == "INSUFFICIENT_EVIDENCE":
        market = {
            "label": "UNRESOLVED",
            "detail": "rate published, but it cannot say above or below",
        }
    else:
        market = {"label": v["call"], "detail": v.get("detail", "")}

    market.update({
        "median": bm["median"],
        "tier": bm["tier"],
        "n": bm["n"],
        "deal_id": s["deal"]["id"],
        "question": (v.get("action") or {}).get("question"),
        "owner": (v.get("action") or {}).get("owner"),
    })

    # The three base scenarios cannot be called while the market evidence is
    # unresolved, so they stay AWAITING. But the engine already computes both
    # readings of the maintenance question, and on one of them the ask is
    # defensible. Those two rows show what the answer is worth: ask Supply one
    # question and the deal becomes actionable.
    rows = economics.scenarios()
    fork = s.get("fork")
    if fork:
        # The opening ask is REPLACED by a single row carrying the call.
        #
        # When the two readings of the rent disagree, this view takes the
        # CONSERVATIVE one and says NEGOTIATE. That is a product decision for
        # the triage screen, not a finding: the engine still refuses, because
        # the evidence genuinely cannot settle it. The asymmetry is what
        # justifies picking a side here — asking for a lower rent costs
        # nothing if the ask was already fair, while signing an overpriced
        # deal is locked in for 33 months.
        opening = rows.pop(0)
        recorded = s.get("answer")

        if recorded:
            # An answer has been recorded, so only the branch it selects is
            # the like-for-like comparison. Reading BOTH branches here made
            # the triage row contradict the deal page, which had already
            # resolved on the answer.
            key = "base" if recorded["answer"] == "excluded" else "all_in"
            branch = fork[key]
            rows.insert(0, {
                **opening,
                "status": "NEGOTIATE" if branch["above"] else "ACQUIRE",
                "evidence": "ANSWERED",
                "market_note": (
                    f"{recorded['who']} confirmed the maintenance question: "
                    f"compared against {rupees_plain(branch['compare'])}, "
                    f"{'above' if branch['above'] else 'below'} the "
                    f"{rupees_plain(fork['median'])} market rate"
                ),
                "conservative": False,
            })

            # The other rows were left AWAITING even after the answer, which
            # made the section contradict its own closing line about the
            # question resolving more than one row. The answer settles which
            # figure is comparable, so every row's rent can now be read
            # against the benchmark -- each on its OWN rent, not the
            # opening ask's.
            #
            # What the answer does NOT do is confirm the evidence behind a
            # row. The Rs 54,000 is still a verbal offer nobody put in
            # writing, so its evidence tag is untouched: the market read
            # resolves, the provenance does not.
            med = fork["median"]
            for i, row in enumerate(rows):
                if i == 0:
                    continue
                compare = row["base_rent"] if key == "base" else row["owner_cost"]
                above = compare > med
                same_rent = compare == branch["compare"]
                rows[i] = {
                    **row,
                    "status": "NEGOTIATE" if above else "ACQUIRE",
                    "market_note": (
                        "the same rent as the opening ask, so the same read: "
                        f"{rupees_plain(compare)} sits "
                        f"{'above' if above else 'at or below'} the "
                        f"{rupees_plain(med)} market rate"
                        if same_rent else
                        f"{rupees_plain(compare)} sits "
                        f"{'above' if above else 'at or below'} the "
                        f"{rupees_plain(med)} market rate on the answered "
                        f"reading. {row['evidence'].capitalize()} either way."
                    ),
                }

            return {
                "status": "PROVISIONAL HOLD",
                "status_note": (
                    "The home may work on better terms, but the current "
                    "evidence is not strong enough to authorise an "
                    "acquisition."
                ),
                "property": economics.PROPERTY,
                "terms": economics.TERMS,
                "scenarios": rows,
                "inputs": economics.INPUTS,
                "market": market,
                "checks": [
                    {"name": n, "expected": list(w), "got": list(g), "ok": ok}
                    for n, w, g, ok in economics.check()
                ],
            }

        above = [k for k in ("base", "all_in") if fork[k]["above"]]
        unresolved = fork["straddles"]

        if unresolved:
            status = "NEGOTIATE"
            note = (
                f"unresolved: {rupees_plain(fork['base']['compare'])} reads "
                f"below the {rupees_plain(fork['median'])} market rate, "
                f"{rupees_plain(fork['all_in']['compare'])} reads above. "
                "Treated as negotiate until the maintenance question is "
                "answered."
            )
            evidence = "NEEDS THE MAINTENANCE ANSWER"
        else:
            status = "NEGOTIATE" if above else "ACQUIRE"
            note = (
                f"both readings agree: "
                f"{'above' if above else 'at or below'} the "
                f"{rupees_plain(fork['median'])} market rate"
            )
            evidence = opening["evidence"]

        rows.insert(0, {
            **opening,
            "status": status,
            "evidence": evidence,
            "market_note": note,
            "conservative": unresolved,
        })

        # Unanswered, the other rows cannot be called either -- and the reason
        # is the same one question, not a separate gap per row. Saying so on
        # each row is what makes the single question look worth asking.
        if unresolved:
            med = fork["median"]
            for i, row in enumerate(rows):
                if i == 0:
                    continue
                rows[i] = {
                    **row,
                    "market_note": (
                        f"also unresolved: {rupees_plain(row['base_rent'])} "
                        f"reads below the {rupees_plain(med)} market rate, "
                        f"{rupees_plain(row['owner_cost'])} reads above. The "
                        "same maintenance answer settles this row too."
                        if row["base_rent"] < med < row["owner_cost"] else
                        f"{rupees_plain(row['base_rent'])} rent and "
                        f"{rupees_plain(row['owner_cost'])} all-in both read "
                        f"{'above' if row['base_rent'] > med else 'at or below'}"
                        f" the {rupees_plain(med)} market rate, so the "
                        "maintenance answer does not change this row."
                    ),
                }

    return {
        "status": "PROVISIONAL HOLD",
        "status_note": (
            "The home may work on better terms, but the current evidence is "
            "not strong enough to authorise an acquisition."
        ),
        "property": economics.PROPERTY,
        "terms": economics.TERMS,
        "scenarios": rows,
        "inputs": economics.INPUTS,
        "market": market,
        "checks": [
            {"name": n, "expected": list(w), "got": list(g), "ok": ok}
            for n, w, g, ok in economics.check()
        ],
    }


# ---------------------------------------------------------------------------
# THE ANSWER
# ---------------------------------------------------------------------------

@app.post("/api/deals/{deal_id}/answer")
def record_answer(
    deal_id: str,
    answer: str = Body(..., embed=True),
    who: str = Body(..., embed=True),
    note: str = Body("", embed=True),
):
    """
    Record what the landlord actually said, for everyone.

    This is the step the site was missing: the engine names the question, a
    person goes and asks it, and the answer has to land somewhere the next
    person can see. Appending here re-resolves the deal on the next read.
    """
    if deal_id not in engine.DEALS:
        raise HTTPException(404, f"unknown deal '{deal_id}'")
    try:
        entry = answers.record(deal_id, answer, who, note)
    except ValueError as e:
        raise HTTPException(400, str(e))
    # The scored deal is cached; an answer changes it.
    _cache.pop(deal_id, None)
    return {"recorded": entry, "log": answers.log(deal_id)}


@app.get("/api/deals/{deal_id}/answer")
def get_answer(deal_id: str):
    return {
        "answer": answers.latest(deal_id),
        "log": answers.log(deal_id),
        "choices": answers.CHOICES,
        "storage": (
            "Shared with everyone using this site. Append-only: an answer can "
            "be superseded but not deleted. Not durable across a redeploy on "
            "this host."
        ),
    }
