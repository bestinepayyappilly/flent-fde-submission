/**
 * The Flent wordmark, from flentinbengaluru.svg.
 *
 * Inlined rather than loaded as an <img> so the paths inherit currentColor:
 * the mark sits in muted-foreground beside BOSS, and has to invert with the
 * theme. The source file carries no fill on its paths, which is what makes
 * that work — `fill` is inherited in SVG, so setting it once on the root
 * colours all five letterforms.
 *
 * Sized by height alone. The viewBox aspect is 324.52 / 118.61, and letting
 * width follow from it keeps the mark from being subtly stretched at any of
 * the sizes it appears in.
 */
export function FlentMark({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 324.52 118.61"
      fill="currentColor"
      role="img"
      aria-label="Flent"
      className={className}
    >
      <path d="M52.77,0C22.98,0,4.4,23.72,11.18,46.87l-11.18.04v14.89h11.2v55.3h25.57v-55.3h19.83v-15.03h-9.07c-12.57,0-19.83-7-19.83-16.78,0-8.17,8.27-14.48,17.64-14.48,20.93,0,27.1,18.05,27.1,18.05v83.54h25.57V21.32C92.2,13.76,76.2,0,52.77,0Z" />
      <path d="M131.86,80.84l46.68-14.05c0-.91,0-1.81-.15-2.72-1.21-12.54-10.88-25.53-33.24-25.53-20.7,0-38.07,16.01-38.07,41.24,0,23.72,17.83,38.83,38.52,38.83s31.73-10.27,33.24-26.29c-4.38,3.93-11.78,6.35-20.24,6.35-9.22,0-22.06-4.08-26.74-17.83ZM142.89,50.48c6.8,0,12.09,4.83,11.03,18.28h-23.87c0-10.88,5.44-18.28,12.84-18.28Z" />
      <path d="M237.33,38.54c-13.29,0-20.7,7.25-24.32,14.96v-14.81l-25.38,2.87v75.54h25.38v-60.28c2.11-.6,4.08-1.06,6.5-1.06,10.27,0,15.11,5.89,15.11,17.37v43.96h25.38v-52.12c0-18.43-10.12-26.44-22.66-26.44Z" />
      <polygon points="304.13 40.05 304.13 17.39 278.75 20.41 278.75 40.05 266.96 40.05 266.96 53.65 278.75 53.65 278.75 117.1 304.13 117.1 304.13 53.65 324.52 53.65 324.52 40.05 304.13 40.05" />
    </svg>
  );
}
