import { PipelineClient } from "@/components/pipeline-client";

export const metadata = {
  title: "Deals · BOSS trust layer",
  description:
    "Every deal in the pipeline, with the market call and the confidence behind it.",
};

export default function Page() {
  return <PipelineClient />;
}
