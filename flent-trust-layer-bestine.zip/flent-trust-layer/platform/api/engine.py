"""
Adapter over trust_layer.py.

The engine is a script with module-level state (SUBJECT, SNAPSHOT,
LISTINGS_PATH are globals that load_deal() and run() mutate). That is fine
for a CLI and wrong for a server, so every scoring call here holds a lock.
Nothing in trust_layer.py was changed to make this work -- the API is a
reader of the engine, not a fork of it.
"""

import os
import sys
import threading
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
TRUST_LAYER = os.path.join(ROOT, "trust-layer")

sys.path.insert(0, TRUST_LAYER)

import answers as ANS            # noqa: E402
import economics as ECON         # noqa: E402
import trust_layer as TL          # noqa: E402
import robustness as RB           # noqa: E402

# The engine resolves overrides.csv / listings.csv relative to its own file,
# so it works unchanged as long as the repo layout is intact.
_LOCK = threading.Lock()

DEAL_PATH = os.path.join(TRUST_LAYER, "deal.json")

# The two configurations the submission rests on. The second is not a staged
# demo: it is the same pipeline, same thresholds, one configuration to the
# left, and it refuses.
DEALS = {
    "FLT-FDE-2026-01": {
        "id": "FLT-FDE-2026-01",
        "furnishing": "semi-furnished",
        "label": "BOSS TRUST LAYER · market-rate benchmark",
        "note": "The property as Supply recorded it on the site visit.",
        "variant": False,
        "synthetic": False,
    },
    # Four more subjects, scored against the SAME 86-row pull. The listings
    # are the packet's; the subject properties and their asking rents are
    # fabricated, and every one is labelled so nobody mistakes them for real
    # deals. Without them 66 of the 86 listings never get used, and there is
    # no way to see whether the layer behaves sensibly anywhere except the
    # one society the packet happens to describe.
    "SYNTH-FERNGROVE": {
        "id": "SYNTH-FERNGROVE",
        "society": "FernGrove Apartments",
        "furnishing": "semi-furnished",
        "base_rent": 52000,
        "maintenance": 3000,
        "label": "BOSS TRUST LAYER · FernGrove Apartments",
        "note": ("FABRICATED SUBJECT. The listings are the packet's; this "
                 "property and its asking rent are invented, to see what the "
                 "layer does in a society with thinner evidence."),
        "variant": False,
        "synthetic": True,
    },
    "SYNTH-BLUEWATER": {
        "id": "SYNTH-BLUEWATER",
        "society": "Bluewater Height",
        "furnishing": "semi-furnished",
        "base_rent": 58000,
        "maintenance": 4000,
        "label": "BOSS TRUST LAYER · Bluewater Heights",
        "note": ("FABRICATED SUBJECT. Five comparables survive, one short of "
                 "the floor. The near miss is the point."),
        "variant": False,
        "synthetic": True,
    },
    "SYNTH-PARKSIDE": {
        "id": "SYNTH-PARKSIDE",
        "society": "Parkside Terraces",
        "furnishing": "semi-furnished",
        "base_rent": 55000,
        "maintenance": 4000,
        "label": "BOSS TRUST LAYER · Parkside Terraces",
        "note": "FABRICATED SUBJECT. Too few comparables to price at all.",
        "variant": False,
        "synthetic": True,
    },
    "SYNTH-MAPLE": {
        "id": "SYNTH-MAPLE",
        "society": "Maple Courtyard",
        "furnishing": "unfurnished",
        "base_rent": 46000,
        "maintenance": 3000,
        "label": "BOSS TRUST LAYER · Maple Courtyard",
        "note": ("FABRICATED SUBJECT. An unfurnished home in a society with "
                 "barely any unfurnished listings."),
        "variant": False,
        "synthetic": True,
    },
    "FLT-FDE-2026-01-FF": {
        "id": "FLT-FDE-2026-01-FF",
        "furnishing": "fully-furnished",
        "label": "BOSS TRUST LAYER · fully-furnished configuration",
        "note": (
            "This is not a second property. There is one deal, and this is "
            "the same one priced as if it were fully furnished instead of "
            "semi-furnished. Nothing else changed: same listings, same "
            "checks, same rules. Watch it refuse."
        ),
        "variant": True,
        "synthetic": False,
    },
}


def _prose(t):
    """
    The engine writes for a terminal: ASCII double-hyphens and "Rs".
    The web UI sets em dashes and the rupee sign everywhere else, so
    normalise at the boundary. Presentation only -- no figure is changed,
    and the CLI is untouched.
    """
    if not isinstance(t, str):
        return t
    return t.replace(" -- ", " \u2014 ").replace("Rs ", "\u20b9")


def _iso(d):
    return d.isoformat() if isinstance(d, date) else None


def _listing(r):
    rule, reason = r.primary_reason
    return {
        "id": r.lid,
        "source": r.source,
        "society_raw": r.society_raw,
        "society": r.society,
        "locality": r.locality,
        "bhk": r.bhk,
        "furnishing": r.furnishing,
        "area_sqft": r.area,
        "rent": r.rent,
        "deposit": r.deposit,
        "photo_count": r.photos,
        "poster_type": r.poster,
        "posted_date": _iso(r.posted),
        "last_seen_date": _iso(r.last_seen),
        "age_days": r.age_days,
        "status": r.status,
        "rule": rule,
        "reason": _prose(reason),
        # Every flag, not just the winning one, so an overridden rule stays
        # visible instead of being erased by the override.
        "all_flags": [
            {"status": f[0], "rule": f[1], "reason": _prose(f[2])}
            for f in r.flags
        ],
        "dup_cluster": r.dup_cluster,
        "override_by": r.override_by,
        "included": r.included,
    }


def _branch(b):
    return {
        "compare": b["compare"],
        "delta": b["delta"],
        "pct": b["pct"],
        "above": b["above"],
        "reading": _prose(b["reading"]),
        "implication": _prose(b["implication"]),
    }


def _policy():
    out = []
    for name, t in TL.POLICY.items():
        out.append({
            "name": name,
            "value": t.value,
            "provenance": t.status,
            "basis": _prose(t.basis),
            "if_wrong": _prose(t.if_wrong),
        })
    order = {"EVIDENCED": 0, "ASSUMED": 1, "CONSTANT": 2}
    out.sort(key=lambda x: (order.get(x["provenance"], 9), x["name"]))
    return out


def score(deal_id: str) -> dict:
    """One full pass through the real engine. Returns everything the UI needs."""
    cfg = DEALS[deal_id]
    answer = ANS.latest(deal_id)

    with _LOCK:
        TL.load_deal(DEAL_PATH)
        if cfg.get("synthetic"):
            TL.SUBJECT["deal_id"] = cfg["id"]
            TL.SUBJECT["society"] = cfg["society"]
            TL.SUBJECT["base_rent"] = cfg["base_rent"]
            TL.SUBJECT["maintenance"] = cfg["maintenance"]
            TL.SUBJECT["all_in"] = cfg["base_rent"] + cfg["maintenance"]
        bm = TL.run(cfg["furnishing"], cfg["label"], verbose=False)
        subject = dict(TL.SUBJECT)
        snapshot = TL.SNAPSHOT
        rows = bm["all_rows"]
        table, dropped = TL.cascade(rows)

        fork = None
        rob = None
        if bm["median"] is not None:
            fork = TL.maintenance_fork(bm)

            # If someone has answered the maintenance question, the two
            # readings collapse to one. Rather than special-casing the
            # verdict, the resolved figure is written into BOTH branches so
            # the engine's own logic finds them in agreement and commits.
            # No second implementation of the decision.
            rob_subject = dict(subject)
            if answer:
                fixed = subject[ANS.CHOICES[answer["answer"]]["compare"]]
                rob_subject["base_rent"] = fixed
                rob_subject["all_in"] = fixed

            rob = RB.assess(
                bm["rows"], bm["redundant"], rob_subject,
                TL.POLICY["material_deviation"],
                TL.POLICY["max_aspirational_bias"],
            )

        aliases = {
            canon: sorted(variants)
            for canon, variants in bm["society_clusters"].items()
        }

    return _assemble(cfg, bm, rows, table, dropped, subject, snapshot,
                     fork, rob, aliases, answer)


def _assemble(cfg, bm, rows, table, dropped, subject, snapshot,
              fork, rob, aliases, answer=None) -> dict:
    """Build the JSON payload. Shared by packet deals and uploads so the
    two cannot diverge."""
    cascade = []
    for label, n, med, cut in table:
        if label is None:
            cascade.append({"divider": True})
        else:
            cascade.append({
                "divider": False, "stage": label,
                "rows": n, "cut": cut, "median": med,
            })

    junk = sum(n for kind, n in dropped if kind == "junk")
    scope = sum(n for kind, n in dropped if kind == "scope")

    listings = [_listing(r) for r in rows]
    raw_median = cascade[0]["median"] if cascade else None

    out = {
        "deal": {
            "id": cfg["id"],
            "society": subject.get("society"),
            "society_raw": subject.get("society_raw", subject.get("society")),
            "bhk": subject.get("bhk"),
            "furnishing": cfg["furnishing"],
            "base_rent": subject.get("base_rent"),
            "maintenance": subject.get("maintenance"),
            "all_in": subject.get("all_in"),
            "snapshot": _iso(snapshot),
            "label": cfg["label"],
            "note": cfg["note"],
            "variant": cfg["variant"],
            "synthetic": cfg.get("synthetic", False),
        },
        "cascade": {
            "stages": cascade,
            "raw": len(listings),
            "included": bm["n"],
            "not_evidence": junk,
            "not_comparable": scope,
            "raw_median": raw_median,
        },
        "benchmark": {
            "n": bm["n"],
            "median": bm["median"],
            "ci": list(bm["ci"]) if bm.get("ci") else None,
            "tier": bm["tier"],
            "tier_reason": _prose(bm["tier_reason"]),
            "sources": bm["sources"],
            "owners": bm["owners"],
            "swing": bm.get("swing"),
            "loo_range": list(bm["loo_range"]) if bm.get("loo_range") else None,
            "mean": bm.get("mean"),
            "mean_with_bait": bm.get("mean_with_bait"),
            "median_with_bait": bm.get("median_with_bait"),
            # The surviving rents, so a single listing can be placed inside
            # the distribution it was measured against.
            "values": bm.get("values") or [],
            "clusters": len(bm.get("clusters") or []),
            "overrides": bm.get("overrides", 0),
        },
        "listings": listings,
        "rules": {
            k: {**v, "does": _prose(v["does"]), "why": _prose(v["why"])}
            for k, v in TL.RULES.items()
        },
        "aliases": aliases,
        "policy": _policy(),
    }

    out["answer"] = answer
    out["answer_log"] = ANS.log(cfg["id"])
    # Each option carries the comparison it implies and the call it will
    # produce, so nobody has to guess which way an answer swings the deal.
    choices = {k: dict(v) for k, v in ANS.CHOICES.items()}
    if fork:
        for key, branch in (("excluded", "base"), ("included", "all_in")):
            b = fork[branch]
            choices[key]["compare_amount"] = b["compare"]
            choices[key]["result"] = "ABOVE MARKET" if b["above"] else "BELOW MARKET"
            choices[key]["preview"] = (
                f"compares \u20b9{b['compare']:,} against the "
                f"\u20b9{fork['median']:,.0f} market rate"
            )
    out["answer_choices"] = choices

    if fork:
        out["fork"] = {
            "median": fork["median"],
            "base": _branch(fork["base"]),
            "all_in": _branch(fork["all_in"]),
            "spread": fork["spread"],
            "straddles": fork["straddles"] and not answer,
            "resolved_by": answer["answer"] if answer else None,
        }
    else:
        out["fork"] = None

    if rob:
        out["robustness"] = {
            "call": rob["base"]["verdict"],
            "action": rob["base"].get("action"),
            "tier": rob["tier"],
            "survived": len(rob["survived"]),
            "total": rob["total"],
            "stability": rob["stability"],
            "flipped": [dict(f, description=_prose(f["description"]))
                        for f in rob["flipped"]],
        }
    else:
        out["robustness"] = None

    # The headline. Two separate questions, answered separately: the engine
    # can publish a benchmark at MEDIUM and still refuse the deviation call.
    if bm["median"] is None:
        out["verdict"] = {
            "call": "INSUFFICIENT_EVIDENCE",
            "headline": "INSUFFICIENT EVIDENCE",
            "detail": (
                f"Only {bm['n']} genuinely similar homes are left after the "
                f"checks, and we do not publish a market rate on fewer than "
                f"{TL.POLICY['min_n_low']}. A rate from this few would look "
                f"just as precise as a good one, which is worse than no rate."
            ),
            "published_benchmark": False,
            "resolution": [
                "Look at nearby societies too, accepting that they are a "
                "less exact match.",
                "Start from the semi-furnished rate and add an agreed amount "
                "for the extra furniture.",
            ],
            "resolution_note": (
                "Both are judgement calls. Someone should make them on "
                "purpose rather than the system guessing."
            ),
            "survivors": [
                {"id": r.lid, "rent": r.rent, "source": r.source,
                 "age_days": r.age_days, "poster": r.poster}
                for r in bm["rows"]
            ],
        }
    elif answer and rob:
        call = rob["base"]["verdict"]
        choice = ANS.CHOICES[answer["answer"]]
        out["verdict"] = {
            "call": call,
            "headline": call,
            "detail": (
                f"{choice['label']}, {choice['detail']}. "
                f"{answer['who']} recorded that on "
                f"{answer['at'][:10]}, and it settles the question the "
                "engine could not answer from the listings alone."
            ),
            "published_benchmark": True,
            "resolved": True,
        }
    elif fork and fork["straddles"]:
        out["verdict"] = {
            "call": "INSUFFICIENT_EVIDENCE",
            "headline": "INSUFFICIENT EVIDENCE",
            "detail": (
                "This is not about having too few listings. We have "
                f"{bm['n']} of them and they agree well enough. The problem is "
                "that they may not all mean the same thing by \"rent\": some "
                "quote it with maintenance included, some without, and nothing "
                "in the data says which. Read one way this home looks cheap, "
                "read the other way it looks expensive. Cleaning the data "
                "further will not help, because that detail was never "
                "collected."
            ),
            "published_benchmark": True,
            "action": {
                "owner": "Supply",
                "question": (
                    f"Is the \u20b9{subject.get('maintenance'):,} society "
                    "maintenance included in the quoted rent, or charged on top?"
                ),
                "cost": "One phone call. Answer in a day.",
                "unlocks": (
                    f"Settles a \u20b9{fork['spread']:,.0f} a month "
                    "difference, and tells you whether to sign at the asking "
                    "rent or go back and negotiate."
                ),
            },
        }
    else:
        call = rob["base"]["verdict"] if rob else "UNKNOWN"
        out["verdict"] = {
            "call": call,
            "headline": call.replace("_", " "),
            "detail": rob["base"].get("reading", "") if rob else "",
            "published_benchmark": True,
        }

    return out


def _locality_of(scored: dict) -> str | None:
    """
    Where a subject is, taken from its own clustered listings.

    Only the packet deal has a recorded address; the others are subjects we
    wrote against real societies in the pull, so the honest source is what
    the listings for that society say. The pull disagrees with itself --
    "Harlur Road", "Haralur" and "Harlur-Sarjapur Road" all appear for the
    same buildings -- so this takes the most common spelling and nothing
    more. It is a label for the row, never an input to the benchmark.
    """
    soc = scored["deal"]["society"]
    seen = {}
    for r in scored["listings"]:
        if r["society"] == soc and r["locality"]:
            seen[r["locality"]] = seen.get(r["locality"], 0) + 1
    if not seen:
        return None
    return max(seen.items(), key=lambda kv: (kv[1], kv[0]))[0]


def deals() -> list:
    """Triage list. Scores every configuration -- there are two."""
    out = []
    for did in DEALS:
        s = score(did)
        out.append({
            "id": did,
            "society": s["deal"]["society"],
            "bhk": s["deal"]["bhk"],
            "furnishing": s["deal"]["furnishing"],
            "locality": _locality_of(s),
            "verdict": s["verdict"]["call"],
            "headline": s["verdict"]["headline"],
            "median": s["benchmark"]["median"],
            "tier": s["benchmark"]["tier"],
            "n": s["benchmark"]["n"],
            "robustness": s["robustness"],
            "note": s["deal"]["note"],
            "variant": s["deal"]["variant"],
            "synthetic": s["deal"]["synthetic"],
            # The packet deal keeps BOSS's own costings (shown on its Money
            # tab). Every other subject is costed on the packet's operating
            # assumptions so the table has one set of columns, and each such
            # row is badged.
            "economics": (
                None
                if did == "FLT-FDE-2026-01"
                else ECON.for_subject(
                    s["deal"]["base_rent"], s["deal"]["maintenance"]
                )
            ),
        })
    return out


# ---------------------------------------------------------------------------
# UPLOADS
# ---------------------------------------------------------------------------

REQUIRED_LISTING_COLUMNS = [
    "listing_id", "source", "posted_date", "last_seen_date", "society",
    "locality", "bhk", "furnishing", "area_sqft", "rent", "deposit",
    "photo_count", "poster_type",
]

REQUIRED_DEAL_FIELDS = [
    "deal_id", "snapshot", "society", "bhk", "furnishing", "base_rent",
    "maintenance",
]


class UploadError(Exception):
    """A problem with what was uploaded, not with the engine."""


def score_upload(listings_path: str, deal_path: str, work_dir: str) -> dict:
    """
    Score an uploaded pull with the real pipeline.

    The engine resolves listings, overrides and aliases from module-level
    paths, so this swaps them for the duration of one call and restores them
    afterwards. It does NOT reimplement any stage: an upload goes through
    exactly the same rules as the case-packet deal, which is the only way the
    result means anything.
    """
    with _LOCK:
        saved = (TL.LISTINGS_PATH, TL.HERE, TL.SNAPSHOT, dict(TL.SUBJECT))
        try:
            TL.LISTINGS_PATH = listings_path
            # run() reads overrides.csv and aliases.csv relative to TL.HERE.
            TL.HERE = work_dir
            try:
                subject = TL.load_deal(deal_path)
            except SystemExit as e:
                # load_deal exits the process on a malformed deal. Correct for
                # a CLI, fatal for a server, so it is converted here. The
                # message names a temp path the caller never chose, so that is
                # swapped back for the filename they actually uploaded.
                raise UploadError(str(e).replace(deal_path, "deal.json"))
            except ValueError as e:
                raise UploadError(f"deal.json is not valid JSON: {e}")

            furnishing = subject.get("furnishing")
            bm = TL.run(furnishing, "uploaded pull", verbose=False)
            rows = bm["all_rows"]
            table, dropped = TL.cascade(rows)
            snapshot = TL.SNAPSHOT
            subject = dict(TL.SUBJECT)

            fork = rob = None
            if bm["median"] is not None:
                fork = TL.maintenance_fork(bm)
                rob = RB.assess(
                    bm["rows"], bm["redundant"], subject,
                    TL.POLICY["material_deviation"],
                    TL.POLICY["max_aspirational_bias"],
                )
            aliases = {c: sorted(v) for c, v in bm["society_clusters"].items()}
        finally:
            TL.LISTINGS_PATH, TL.HERE, TL.SNAPSHOT, TL.SUBJECT = saved

    cfg = {
        "id": subject.get("deal_id", "UPLOAD"),
        "furnishing": furnishing,
        "label": "uploaded pull",
        "note": ("Scored from an uploaded pull. Same pipeline, same "
                 "thresholds as every other deal on this site."),
        "variant": False,
    }
    return _assemble(cfg, bm, rows, table, dropped, subject, snapshot,
                     fork, rob, aliases)
