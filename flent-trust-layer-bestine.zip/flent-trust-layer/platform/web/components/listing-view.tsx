"use client";

import { ArrowLeft, ArrowRight, Ban, Check } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { CopyButton } from "@/components/copy-button";
import { RuleInfo } from "@/components/rule-info";
import { statusLabel } from "@/lib/labels";
import { buildAxes, RecordProfile } from "@/components/record-profile";
import { rupees, type Listing, type Scored } from "@/lib/api";

const TABS = ["Overview", "Rules it matched", "As scraped"] as const;

/**
 * Where this listing sits inside the surviving comp distribution.
 *
 * The axis has to stretch to fit the subject when the subject falls outside
 * the comparables (a bait row at Rs 12,000 against a cluster near Rs 59,000).
 * So the axis extent and the COMPARABLE range are two different numbers, and
 * an earlier version printed the axis extent under the heading "where it
 * sits" as though it were the comp range. The shaded band is the comps; the
 * endpoint labels are the axis.
 */
function Distribution({
  values,
  rent,
  median,
  included,
}: {
  values: number[];
  rent: number;
  median: number | null;
  included: boolean;
}) {
  if (!values?.length || median === null) return null;

  const compLo = Math.min(...values);
  const compHi = Math.max(...values);

  // Pad so a marker sitting exactly on an extreme is not clipped by the edge.
  const rawLo = Math.min(compLo, rent);
  const rawHi = Math.max(compHi, rent);
  const pad = (rawHi - rawLo || rawHi || 1) * 0.06;
  const lo = rawLo - pad;
  const hi = rawHi + pad;
  const span = hi - lo || 1;
  // NB: lo/hi carry padding, so they are never shown as values.
  const at = (v: number) => ((v - lo) / span) * 100;

  const BINS = 22;
  const counts = new Array(BINS).fill(0);
  for (const v of values) {
    const i = Math.min(BINS - 1, Math.floor(((v - lo) / span) * BINS));
    counts[i] += 1;
  }
  const peak = Math.max(...counts, 1);

  const below = values.filter((v) => v < rent).length;
  const pct = Math.round((below / values.length) * 100);
  const outside = rent < compLo || rent > compHi;

  return (
    <div>
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <span className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
          WHERE IT SITS
        </span>
        <span className="text-[12px] text-muted-foreground">
          {values.length} similar homes span{" "}
          <span className="tnum font-medium text-foreground">
            {rupees(compLo)} – {rupees(compHi)}
          </span>
        </span>
      </div>

      <div className="relative mt-5 h-[76px]">
        {/* the comparable range, so it is never confused with the axis */}
        <div
          className="absolute bottom-6 top-0 rounded-sm bg-secondary"
          style={{ left: `${at(compLo)}%`, width: `${at(compHi) - at(compLo)}%` }}
        />

        {/* one bar per bin: overlapping comps are visible as height */}
        {counts.map((c, i) =>
          c === 0 ? null : (
            <div
              key={i}
              title={`${c} listing${c === 1 ? "" : "s"}`}
              className="absolute bottom-6 rounded-t-sm bg-muted-foreground/35"
              style={{
                left: `${(i / BINS) * 100}%`,
                width: `${(1 / BINS) * 100}%`,
                height: `${8 + (c / peak) * 36}px`,
              }}
            />
          ),
        )}

        {/* median */}
        <div
          className="absolute bottom-6 top-0 w-px bg-foreground"
          style={{ left: `${at(median)}%` }}
        />
        <div
          className="absolute -translate-x-1/2 whitespace-nowrap text-[10.5px] text-muted-foreground"
          style={{
            // Clamped so the label cannot run off either edge when the
            // median sits near the end of the axis.
            left: `${Math.min(88, Math.max(12, at(median)))}%`,
            top: "-6px",
          }}
        >
          median {rupees(median)}
        </div>

        {/* this listing */}
        <div
          className={`absolute bottom-[18px] w-[3px] -translate-x-1/2 rounded-full ${
            included ? "bg-acquire" : "bg-refuse"
          }`}
          style={{ left: `${at(rent)}%`, height: "46px" }}
        />
        <div
          className={`tnum absolute bottom-0 -translate-x-1/2 whitespace-nowrap text-[11.5px] font-medium ${
            included ? "text-acquire" : "text-refuse"
          }`}
          style={{
            left: `${Math.min(92, Math.max(8, at(rent)))}%`,
          }}
        >
          {rupees(rent)}
        </div>

        {/* axis */}
        <div className="absolute bottom-6 left-0 right-0 h-px bg-border" />
      </div>

      <p className="mt-3 text-[12.5px] leading-relaxed text-muted-foreground">
        {included ? (
          <>
            More expensive than {pct}% of the homes we used, and{" "}
            {rent === median
              ? "exactly at the median"
              : `${rupees(Math.abs(rent - median))} ${
                  rent > median ? "above" : "below"
                } it`}
            .
          </>
        ) : (
          <>
            Shown for reference only. This row was excluded, so it is not one of
            the {values.length} homes the market rate was worked out from
            {outside ? (
              <>
                . At {rupees(rent)} it sits {rent > compHi ? "above" : "below"}{" "}
                every one of them.
              </>
            ) : (
              "."
            )}
          </>
        )}
      </p>
    </div>
  );
}

function Field({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-border py-2.5 last:border-0">
      <span className="text-[12.5px] text-muted-foreground">{k}</span>
      <span className="text-right text-[13px] font-medium">{v}</span>
    </div>
  );
}

export function ListingView({
  d,
  r,
  staleDays,
}: {
  d: Scored;
  r: Listing;
  staleDays: number | null;
}) {
  const [tab, setTab] = useState<(typeof TABS)[number]>("Overview");
  const included = r.included;
  const perSqft = r.area_sqft ? r.rent / r.area_sqft : null;

  const overrideLine = `${r.id},${included ? "exclude" : "include"},Your name,Why you disagree`;

  return (
    <div className="px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
      <Link
        href={`/deals/${d.deal.id}?tab=ledger`}
        className="inline-flex items-center gap-1.5 text-[12.5px] text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-3.5" aria-hidden />
        Ledger
      </Link>

      <h1 className="mt-3 font-mono text-[24px] font-semibold tracking-tight sm:text-[28px]">
        {r.id}
      </h1>
      <p className="mt-1.5 text-[13px] text-muted-foreground">
        {r.society_raw} · {r.bhk}BHK · {r.furnishing} · {r.source}
        {r.posted_date && <> · posted {r.posted_date}</>}
      </p>

      <div className="mt-6 grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.35fr)] lg:gap-5">
        {/* Left: the call on this row, in the slot BOSS gives the deal verdict */}
        <div className="space-y-4">
          <div
            className={`rounded-lg p-6 ${
              included
                ? "bg-acquire text-white"
                : "border border-refuse-border bg-refuse-bg text-refuse"
            }`}
          >
            <div className="flex items-center gap-3">
              <span
                className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[18px] ${
                  included ? "bg-white/20" : "bg-refuse/12"
                }`}
              >
                {included ? (
                  <Check className="size-4.5" aria-hidden />
                ) : (
                  <Ban className="size-4.5" aria-hidden />
                )}
              </span>
              <span className="text-[22px] font-semibold leading-tight tracking-tight">
                {statusLabel(r.status)}
              </span>
            </div>
            <p className="mt-4 text-[13.5px] leading-relaxed opacity-90">
              {r.reason}
            </p>
            {r.rule && (
              <p className="mt-3 border-t border-current/15 pt-3 font-mono text-[12px] opacity-75">
                rule {r.rule}
              </p>
            )}
          </div>

          <div className="rounded-lg border border-border bg-card p-6">
            <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
              THINK WE GOT THIS WRONG?
            </div>
            {r.override_by ? (
              <p className="mt-3 text-[13px] leading-relaxed">
                Already overridden by{" "}
                <span className="font-medium">{r.override_by}</span>. The rule
                it overrode is still recorded below, so the disagreement is
                visible rather than erased.
              </p>
            ) : (
              <>
                <p className="mt-3 text-[13px] leading-relaxed text-muted-foreground">
                  A named person beats every rule, in both directions. Add
                  this line to the overrides file and run it again:
                </p>
                <pre className="mt-3 whitespace-pre-wrap break-words rounded-md border border-border bg-secondary p-3 font-mono text-[11px] leading-relaxed">
                  {overrideLine}
                </pre>
                <div className="mt-2.5">
                  <CopyButton value={overrideLine} label="Copy override line" />
                </div>
              </>
            )}
          </div>
        </div>

        {/* Right: the tabbed panel */}
        <div className="min-w-0">
          {/* Scroll box and tab row kept separate: overflow-x-auto also
              makes overflow-y "auto", and the -mb-px underline below would
              otherwise leave a 1px vertical scrollbar. */}
          <div className="-mx-4 overflow-x-auto px-4 pb-px sm:mx-0 sm:overflow-visible sm:px-0 sm:pb-0">
            <div className="flex min-w-max gap-5 border-b border-border sm:min-w-0">
            {TABS.map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`-mb-px shrink-0 whitespace-nowrap border-b-2 pb-2.5 text-[13.5px] font-medium transition ${
                  tab === t
                    ? "border-foreground text-foreground"
                    : "border-transparent text-muted-foreground"
                }`}
              >
                {t}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-5 rounded-lg border border-border bg-card p-5 sm:p-6">
            {tab === "Overview" && (
              <div className="space-y-7">
                <Distribution
                  values={d.benchmark.values ?? []}
                  rent={r.rent}
                  median={d.benchmark.median}
                  included={included}
                />

                <RecordProfile
                  axes={buildAxes(
                    r,
                    staleDays,
                    d.benchmark.median,
                    d.benchmark.values?.length
                      ? Math.min(...d.benchmark.values)
                      : null,
                    d.benchmark.values?.length
                      ? Math.max(...d.benchmark.values)
                      : null,
                  )}
                  included={included}
                />

                <div>
                  <Field k="Asking rent" v={rupees(r.rent)} />
                  <Field
                    k="Area"
                    v={r.area_sqft ? `${r.area_sqft} sqft` : "not recorded"}
                  />
                  <Field
                    k="Rent per sqft"
                    v={
                      perSqft
                        ? `₹${perSqft.toFixed(1)}`
                        : "cannot compute without area"
                    }
                  />
                  <Field
                    k="Deposit"
                    v={r.deposit ? rupees(r.deposit) : "not recorded"}
                  />
                  <Field
                    k="Last seen"
                    v={
                      r.age_days === null ? (
                        "unknown"
                      ) : (
                        <>
                          last seen {r.age_days}d ago
                          {staleDays !== null && (
                            <span className="font-normal text-muted-foreground">
                              {" "}
                              / limit {staleDays}d
                            </span>
                          )}
                        </>
                      )
                    }
                  />
                  <Field k="Listed by" v={r.poster_type} />
                  <Field k="Photos on listing" v={r.photo_count} />
                  <Field
                    k="Society name on the site"
                    v={
                      r.society_raw === r.society ? (
                        r.society_raw
                      ) : (
                        <>
                          {r.society_raw}
                          <span className="inline-flex items-center gap-1 font-normal text-muted-foreground">
                            <ArrowRight className="size-3" aria-hidden />
                            {r.society}
                          </span>
                        </>
                      )
                    }
                  />
                  {r.dup_cluster && (
                    <Field
                      k="Duplicate group"
                      v={<span className="font-mono">{r.dup_cluster}</span>}
                    />
                  )}
                </div>
              </div>
            )}

            {tab === "Rules it matched" && (
              <div>
                <p className="text-[13px] leading-relaxed text-muted-foreground">
                  Every rule this listing matched, most important first. The
                  first one is the reason shown in the list. The others stay
                  visible so overriding a rule cannot quietly hide it.
                </p>
                <div className="mt-4 space-y-2.5">
                  {r.all_flags.length === 0 && (
                    <div className="rounded-lg border border-acquire-border bg-acquire-bg p-4 text-[13px] text-acquire">
                      Nothing was wrong with this listing. It passed every check.
                    </div>
                  )}
                  {r.all_flags.map((f, i) => (
                    <div
                      key={i}
                      className="rounded-lg border border-border p-4"
                    >
                      <div className="flex flex-wrap items-center gap-2">
                        <RuleInfo id={f.rule} rule={d.rules[f.rule]} />
                        <span className="text-[12.5px] font-medium">
                          {f.status.replace(/_/g, " ")}
                        </span>
                        {i === 0 && (
                          <span className="text-[11px] text-muted-foreground">
                            primary
                          </span>
                        )}
                      </div>
                      <p className="mt-2 text-[12.5px] leading-relaxed text-muted-foreground">
                        {f.reason}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === "As scraped" && (
              <div>
                <p className="text-[13px] leading-relaxed text-muted-foreground">
                  The listing exactly as we scraped it. Blank means blank: we
                  never fill in a missing value.
                </p>
                <pre className="mt-4 overflow-x-auto rounded-md border border-border bg-secondary p-4 font-mono text-[11.5px] leading-relaxed">
                  {JSON.stringify(
                    {
                      listing_id: r.id,
                      source: r.source,
                      posted_date: r.posted_date,
                      last_seen_date: r.last_seen_date,
                      society: r.society_raw,
                      locality: r.locality,
                      bhk: r.bhk,
                      furnishing: r.furnishing,
                      area_sqft: r.area_sqft,
                      rent: r.rent,
                      deposit: r.deposit,
                      photo_count: r.photo_count,
                      poster_type: r.poster_type,
                    },
                    null,
                    2,
                  )}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
