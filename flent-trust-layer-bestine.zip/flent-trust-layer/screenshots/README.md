# BOSS screenshots

The two images in this folder show the current BOSS interface populated with seeded,
sanitised demo records. The society names and numerical outputs are fixture data,
not real Flent deals, portfolio performance or production policy thresholds.

- `boss-scored-deal.png` shows the structure of a scored-deal page.
- `boss-pipeline.png` shows the structure of the deal triage list.

Use them for product context only. They are not a specification or an answer key.
