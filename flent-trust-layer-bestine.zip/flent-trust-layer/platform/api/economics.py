"""
The deal economics, exactly as case-packet/boss-assessment.md sets them out.

NOTHING HERE IS INVENTED, and nothing here is the trust layer's work. These
are BOSS's own numbers for this deal, reproduced so the pipeline view shows a
deal the way an acquisition lead sees it. The trust layer contributes one
column of this table -- the market evidence -- and that boundary is stated in
the UI rather than blurred.

The inputs are the packet's; the outputs are computed from them. The packet
states its own results (Rs 7,400 contribution, 35.1 months payback, and so
on), so recomputing rather than copying means a wrong encoding shows up as a
mismatch instead of passing silently. check() asserts exactly that.

Every input carries its evidence status, because most of them are estimates
that the assessment itself flags as provisional.
"""

# --- Inputs, all from case-packet/ ------------------------------------------

INPUTS = {
    "tenant_revenue": {
        "value": 72000,
        "label": "Planned tenant revenue",
        "status": "HYPOTHESIS",
        "note": (
            "\u20b938,000 + \u20b934,000 across two rooms. Pricing's working "
            "ladder, 18 Aug. No signed tenants."
        ),
    },
    "occupancy": {
        "value": 0.95,
        "label": "Occupancy assumption",
        "status": "EXERCISE ASSUMPTION",
        "note": "Chosen for the exercise by the assessment, not a production figure.",
    },
    "base_rent": {
        "value": 56000,
        "label": "Landlord rent, opening ask",
        "status": "RECORDED, NOT SIGNED",
        "note": "Captured by Supply on the site visit, 17 Aug.",
    },
    "maintenance": {
        "value": 5000,
        "label": "Society maintenance",
        "status": "RECORDED, NOT SIGNED",
        "note": "Payable by Flent. Whether the listings include it is the open question.",
    },
    "alt_rent": {
        "value": 54000,
        "label": "Landlord rent, verbal alternative",
        "status": "VERBAL, UNCONFIRMED",
        "note": (
            "Owner said 'probably could do 54' on 17 Aug if Flent keeps the "
            "full deposit and signs that week. Asked for it in writing; "
            "nothing received."
        ),
    },
    "capex": {
        "value": 160000,
        "label": "Furnishing capex",
        "status": "PLACEHOLDER",
        "note": "Property team's placeholder for paint, deep clean and two beds. No vendor quote yet.",
    },
    "landlord_deposit": {
        "value": 280000,
        "label": "Deposit to landlord",
        "status": "RECORDED, NOT SIGNED",
        "note": "Owner says it is not negotiable.",
    },
    "tenant_deposits": {
        "value": 180000,
        "label": "Deposits from tenants",
        "status": "ASSUMPTION",
        "note": "Finance assumed 2.5 months of the hypothesised tenant revenue.",
    },
    "downside_revenue": {
        "value": 69000,
        "label": "Tenant revenue, downside",
        "status": "HYPOTHESIS",
        "note": "If the second room lands at \u20b931,000 rather than \u20b934,000.",
    },
}


def _scenario(name, sub, revenue, rent, maintenance, status, evidence):
    monthly_revenue = revenue * INPUTS["occupancy"]["value"]
    owner_cost = rent + maintenance
    contribution = monthly_revenue - owner_cost
    uncovered = (
        INPUTS["landlord_deposit"]["value"] - INPUTS["tenant_deposits"]["value"]
    )
    capital = INPUTS["capex"]["value"] + uncovered
    payback = capital / contribution if contribution > 0 else None
    return {
        "id": name.lower().replace(" ", "-").replace(",", ""),
        "name": name,
        "sub": sub,
        "monthly_revenue": round(monthly_revenue),
        # Both halves of the cost, separately. Whether the market comparison
        # uses the rent alone or the all-in figure depends on the maintenance
        # convention, which only the landlord can settle -- so the caller
        # needs each part, not just the total.
        "base_rent": rent,
        "maintenance": maintenance,
        "owner_cost": owner_cost,
        "contribution": round(contribution),
        "capital_employed": capital,
        "payback_months": round(payback, 1) if payback else None,
        "status": status,
        "evidence": evidence,
    }


def scenarios() -> list:
    """The three the assessment costs out, in the order it presents them."""
    base = INPUTS["base_rent"]["value"]
    maint = INPUTS["maintenance"]["value"]
    rev = INPUTS["tenant_revenue"]["value"]
    return [
        _scenario(
            "Opening ask",
            f"\u20b9{base:,} rent + \u20b9{maint:,} maintenance",
            rev, base, maint,
            "AWAITING",
            "RECORDED, NOT SIGNED",
        ),
        _scenario(
            "If the landlord accepts \u20b954,000",
            "The verbal alternative, still unconfirmed",
            rev, INPUTS["alt_rent"]["value"], maint,
            "AWAITING",
            "VERBAL, UNCONFIRMED",
        ),
        _scenario(
            "If room 2 lets at \u20b931,000",
            "Demand downside on the opening ask",
            INPUTS["downside_revenue"]["value"], base, maint,
            "AWAITING",
            "HYPOTHESIS",
        ),
    ]


# The assessment publishes its own results. If this file computes anything
# different, the encoding is wrong and the mismatch should be loud.
EXPECTED = {
    "Opening ask": (7400, 35.1),
    "If the landlord accepts \u20b954,000": (9400, 27.7),
    "If room 2 lets at \u20b931,000": (4550, 57.1),
}


def check() -> list:
    out = []
    for s in scenarios():
        want = EXPECTED[s["name"]]
        got = (s["contribution"], s["payback_months"])
        out.append((s["name"], want, got, want == got))
    return out


if __name__ == "__main__":
    for name, want, got, ok in check():
        print(f"{'OK ' if ok else 'FAIL'} {name:36} want {want}  got {got}")


# --- The property and the lease terms, from case-packet/deal.md -------------
#
# Recorded by Supply on the site visit of 17 Aug. These are the landlord's
# stated terms, not a signed agreement, and the status on each says which.

PROPERTY = {
    "society": "Lakeview Residences",
    "society_note": "anonymised in the packet",
    "locality": "Harlur–Sarjapur Road, Bengaluru",
    "config": "2 BHK · 2 bath · 1 balcony",
    "area_sqft": 1175,
    "area_note": "owner-stated; no floor plan supplied",
    "furnishing": "Semi-furnished",
    "furnishing_note": "wardrobes, kitchen cabinets, geysers and lights",
    "floor": "2 of 12",
    "outlook": "Internal courtyard",
    "availability": "Keys available; owner proposes a 1 September start",
}

TERMS = [
    {"label": "Base rent", "value": "₹56,000 / month", "status": "RECORDED"},
    {"label": "Society maintenance", "value": "₹5,000 / month, paid by Flent",
     "status": "RECORDED"},
    {"label": "Total monthly cost", "value": "₹61,000 / month", "status": "RECORDED"},
    {"label": "Security deposit", "value": "₹2,80,000", "status": "RECORDED",
     "note": "Owner says it is not negotiable."},
    {"label": "Escalation", "value": "7% after month 11", "status": "RECORDED"},
    {"label": "Rent-free period", "value": "15 days from handover", "status": "RECORDED"},
    {"label": "Contract term", "value": "33 months", "status": "RECORDED"},
    {"label": "Lock-in", "value": "11 months", "status": "RECORDED"},
    {"label": "Notice", "value": "3 months after lock-in", "status": "RECORDED"},
    {"label": "Exit charge", "value": "One month's base rent, for painting",
     "status": "RECORDED"},
    {"label": "Lower rent offered", "value": "₹54,000 if Flent keeps the full "
     "deposit and signs that week", "status": "VERBAL, UNCONFIRMED",
     "note": "Asked for in writing on 17 Aug. Nothing received."},
]


# --- Costing a subject other than the packet's ------------------------------

def for_subject(base_rent: int, maintenance: int) -> dict:
    """
    Cost a fabricated subject using the packet deal's own operating
    assumptions, so the only thing that changes between subjects is the rent.

    Tenant revenue is scaled by the packet's revenue-to-cost ratio
    (Rs 72,000 planned against Rs 61,000 owner cost, about 1.18x). That is a
    modelling ASSUMPTION and a crude one: a cheaper home in a different
    society would not necessarily let at the same multiple. It is used only
    so the fabricated subjects can be shown in the same columns as the real
    one, and every row carrying it is badged as a fabricated subject.

    Capex, the deposit ratio and occupancy are held at the packet's values.
    """
    packet_cost = INPUTS["base_rent"]["value"] + INPUTS["maintenance"]["value"]
    ratio = INPUTS["tenant_revenue"]["value"] / packet_cost

    owner_cost = base_rent + maintenance
    revenue = owner_cost * ratio * INPUTS["occupancy"]["value"]
    contribution = revenue - owner_cost
    # Deposits scale with rent the way the packet's do.
    landlord_deposit = base_rent * (
        INPUTS["landlord_deposit"]["value"] / INPUTS["base_rent"]["value"]
    )
    tenant_deposits = revenue * (
        INPUTS["tenant_deposits"]["value"]
        / (INPUTS["tenant_revenue"]["value"] * INPUTS["occupancy"]["value"])
    )
    capital = INPUTS["capex"]["value"] + max(
        0, landlord_deposit - tenant_deposits
    )
    return {
        "owner_cost": owner_cost,
        "monthly_revenue": round(revenue),
        "contribution": round(contribution),
        "capital_employed": round(capital),
        "payback_months": round(capital / contribution, 1)
        if contribution > 0
        else None,
        "basis": (
            "packet operating assumptions, rent-scaled revenue at "
            f"{ratio:.2f}x owner cost"
        ),
    }
