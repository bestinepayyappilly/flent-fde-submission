"use client";

import { LedgerTable } from "@/components/ledger-table";
import { Segmented } from "@/components/segmented";
import { ApiError, LedgerSkeleton } from "@/components/skeleton";
import { getDeal } from "@/lib/api";
import { useApi } from "@/lib/use-api";

export function LedgerClient({ dealId }: { dealId: string }) {
  const {
    data: d,
    error,
    loading,
    reload,
  } = useApi(() => getDeal(dealId), [dealId]);

  if (error) return <ApiError error={error} onRetry={reload} />;

  const used = d ? d.listings.filter((r) => r.included).length : 0;

  // The heading and the deal switcher do not depend on the response, so they
  // are real from the first paint and the switcher stays usable while another
  // deal loads. Only the table below is a skeleton.
  return (
    <div className="px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <h1 className="text-[26px] font-semibold tracking-tight sm:text-[30px]">
          Ledger
        </h1>
        <Segmented dealId={dealId} />
      </div>

      {loading || !d ? (
        <LedgerSkeleton />
      ) : (
        <>
          <p className="mt-5 text-[13.5px] text-muted-foreground">
            {d.listings.length} listings scraped for {d.deal.society} ·{" "}
            {d.deal.bhk}BHK · {d.deal.furnishing} · {used} used for the market
            rate
          </p>
          <div className="mt-6">
            <LedgerTable
              rows={d.listings}
              dealId={d.deal.id}
              rules={d.rules}
              hideIntro
            />
          </div>
        </>
      )}
    </div>
  );
}
