# Submission — Problem 1, the market-listing trust layer

Bestine Payyappilly · deal FLT-FDE-2026-01 · September 2026

`README.txt` is Flent's own file and is untouched. This one is the entry point to
what I built.

## The three deliverables

| | | |
|---|---|---|
| **1 · Approach note** | [`approach-note.pdf`](approach-note.pdf) | 4 pages. Source: [`approach-note.md`](approach-note.md) |
| **2 · Proof of work** | [`trust-layer/`](trust-layer/) | Runs in one command, no install |
| **3 · Execution plan** | [`execution-plan.pdf`](execution-plan.pdf) | FLT-1 parent + 8 sub-issues. Source: [`execution-plan.md`](execution-plan.md) |

## If you have five minutes

```
cd trust-layer
python3 trust_layer.py       # score the packet deal, 86 listings -> a decision
python3 stress_test.py       # 7 reproducible attacks on that decision
python3 outcomes_check.py    # test my own premise against Flent's history
```

Python 3.8+, standard library only. Nothing to install.

Or open **[flent-trust-layer.vercel.app](https://flent-trust-layer.vercel.app)**,
which runs the same engine over an API rather than reimplementing it.

## What it concludes

**The benchmark is publishable. The verdict is not.** The layer refuses to say
whether ₹56,000 is above or below market on this deal, because the scraped comps mix
two rent conventions and the deviation flips sign depending on which one they use. It
returns one question for Supply instead of a number, and the site records the answer
so the refusal resolves.

Three findings the submission rests on:

1. **Cleaning is a null result.** 86 rows to 20; the median moves ₹500. Filtering
   doesn't fix the rate, it collapses the sample. The product is the confidence.
2. **The maintenance fork decides the deal.** ₹5,000/month, opposite verdicts, and no
   cleaning rule reaches it — the information was never scraped.
3. **Confidence must not be a function of `n`.** Every defect *raises* `n`, so
   grading on sample size lets surviving junk buy confidence. v2 grades on how hard
   the call is to overturn: ~20 attacks, and the call must survive them.

And one that argues against my own choice of problem: `outcomes_check.py` reads the
packet's history and finds revenue forecasts landing within 2% of plan while fill-time
forecasts run 23% long. **The layer makes one input honest. The data says it wasn't
the input that was hurting you.** Approach note §5 carries this, caveats included
(n=10, p=0.11 — evidence, not proof).

## Directories

- **`trust-layer/`** — the engine, its stress battery, and
  [`FAILURES.md`](trust-layer/FAILURES.md): nine defects I found by attacking my own
  build, 3 fixed, 2 bounded, 4 open. Read that before believing anything here works.
- **`platform/`** — FastAPI service on Railway (imports the engine, doesn't copy it)
  and a Next.js frontend on Vercel. The ledger surface, not a dashboard.
- **`stress-data/`** — nine labelled synthetic pulls for the upload page. Two are
  built to defeat the engine and say so.
- **`case-packet/`**, **`screenshots/`** — Flent's, unmodified.

Everything fabricated is labelled as fabricated. Nothing in the packet was invented
around.
