import { DealClient } from "@/components/deal-client";

/**
 * A shell, deliberately. The deal is scored by the API on request, and doing
 * that on the server put a Vercel -> Railway round trip in front of the first
 * paint of a layout that is otherwise entirely static. The page frame now
 * ships immediately and the score arrives into a skeleton.
 *
 * The route file stays a server component so the title is still set from the
 * URL, which needs no fetch to know.
 */
export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return {
    title: `${id} · BOSS trust layer`,
    description:
      "The market rate, the confidence behind it, and every listing that did or did not count towards it.",
  };
}

export default async function DealPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ tab?: string }>;
}) {
  const { id } = await params;
  const { tab } = await searchParams;

  return <DealClient id={id} tab={tab} />;
}
