# BOSS market-listing trust layer

Proof of work for Problem 1. Raw scraped listings in, a market-rate benchmark
with an explicit confidence level out — or an explicit refusal when the
evidence cannot support one.

```
python3 trust_layer.py                          # score the case-packet deal
python3 trust_layer.py --deal other_deal.json   # score any other deal
python3 stress_test.py                          # attack it; see FAILURES.md
```

No dependencies, no install, Python 3.8+. Reads `deal.json` and
`../case-packet/listings.csv`. Writes `out/ledger.csv` and
`out/alias_registry.csv`.

The deal is **input, not configuration** — society, BHK, furnishing and the
rent terms live in `deal.json`, so the engine is not welded to one property.
A deal file missing a required term is rejected outright rather than
defaulted, which is guardrail 1 enforced in code rather than promised in a
comment.

---

**Start with [FAILURES.md](FAILURES.md)** if you only read one thing. It
documents nine defects found by attacking this engine — three fixed, two
bounded, four still open — and the architectural change they forced.

## The claim this proves

> Cleaning listings barely moves the market rate. It collapses the sample.
> The trust layer's job is to stop BOSS being confident — and on this deal the
> most valuable output is a refusal, not a number.

Three findings, in order of how much they should change what Flent does.

### 1. The cleaning is a null result, and that is the finding

| stage | rows | cut | median |
|---|---:|---:|---:|
| Raw pull | 86 | | ₹59,000 |
| − broken / impossible records | 82 | 4 | ₹59,000 |
| − cross-post duplicates | 69 | 13 | ₹58,500 |
| − stale listings | 61 | 8 | ₹58,000 |
| *not evidence above · not comparable below* | | | |
| − out of scope (BHK / society / furnishing) | **20** | 41 | **₹59,500** |

**86 → 20 rows. The median moved ₹500.**

The noise in this pull is close to symmetric, so filtering does not move the
centre. What it moves is the *confidence*. Before: "median of 86 listings."
After: "median of 20, 90% interval ₹58,000–₹60,000." Same number, completely
different decision.

Reported as a null result on purpose. A pipeline whose median lurches after
cleaning has usually introduced a bias rather than removed one.

Note the split in that table. Of the 66 rows removed, only **25 were not
evidence** (broken, duplicated, decayed). The other **41 were perfectly good
listings about a different kind of home** — different BHK, society, or
furnishing tier. Collapsing those two categories would let us claim we
removed far more junk than we did.

### 2. The maintenance fork — what actually decides this deal

Market operations flagged it in the thread on 18 Aug:

> *"We do not capture maintenance reliably, so the listing rents are not
> always all-in."*

So the 20 surviving comps are a mix of two conventions, medianed together as
if they were one measurement. Against the **same ₹59,500 benchmark**:

| | compare against | deviation | reading |
|---|---:|---:|---|
| **If listings quote base rent** | ₹56,000 | **−₹3,500 (−5.9%)** | below market — the ask is defensible |
| **If listings quote all-in rent** | ₹61,000 | **+₹1,500 (+2.5%)** | above market — we are overpaying |

Same clean data. Opposite verdicts. A ₹5,000/month swing.

**No amount of further cleaning fixes this, because the information is not in
the dataset.** It was never scraped. It is *missing*, not noisy — and that
distinction is the whole point. A confidence interval is the wrong instrument
for it: the uncertainty is not statistical.

So the engine returns `INSUFFICIENT_EVIDENCE` on market deviation while still
publishing the benchmark at MEDIUM confidence. Those are two separate
questions and the system answers them separately.

**It refuses only when the ambiguity actually changes the call.** The two
readings here *straddle* the benchmark, so the unresolved convention flips
the verdict. On a deal where both readings land on the same side, the engine
says so plainly and gives a determinate answer — a system that refuses even
when refusing changes nothing is just hedging. (Verify with
`--deal` on any property whose rent sits clear of the benchmark.)

**The cheapest resolving action** — one question, owned by Supply, answerable
in a day:

> *"Is the ₹5,000 society maintenance included in the quoted rent, or charged
> on top?"*

That is the deliverable. Not a dashboard: a decision, its two branches with
consequences attached, and the one cheap thing to go and find out.

### 3. The failure case is not staged

The same pipeline, same thresholds, no special-casing. This is not a second
deal: the packet contains one, and this is that same record re-scored with
furnishing changed to **fully furnished**, one configuration to the left. It
refuses:

```
VERDICT: INSUFFICIENT EVIDENCE
only 4 independent comparables survive; the floor for publishing
any benchmark is 6.
```

Four. The brief's own sentence — *"an area that appeared to have 30
comparables can suddenly have four"* — reproduced by running the pipeline
one configuration to the left. It then names the two ways a human could
resolve it, and makes clear both are human choices, not something the engine
should quietly pick.

---

### 4. Confidence is a property of the decision, not the sample

Attacking v1 exposed a structural error: it graded confidence on `n`, and
**`n` is what every defect inflates.** Undetected duplicates, bait rows and
wrongly merged societies all *raise* the sample size. Surviving junk bought
confidence.

So the engine now runs a battery of ~20 attacks — dedup failing entirely,
the k cheapest rows being bait, the dominant portal removed, worst-case
subset deletion, systematic ask-inflation swept 2–10% — and reports how many
the call survives:

```
CALL        INSUFFICIENT
ACTION      UNRESOLVED
ROBUSTNESS  REFUSED  (18 of 20 attacks survived)

The call changes under 2 attack(s):
  [A6.8% ] asks inflated 8% above achieved rents
           -> median Rs 54,740, call becomes ABOVE MARKET
```

That last line is the point. Aspirational bias cannot be detected from
listings (correlation with days-on-market: −0.16), so it cannot be filtered.
But it can be **bounded**: the call is stable up to 6% ask-inflation and flips
at 8%. An unmeasurable risk becomes a stated threshold — and a second named
resolver alongside the maintenance question.

The engine also refuses on a disagreement about the **action**, not the label.
`AT MARKET` and `BELOW MARKET` are different words for the same decision; only
a split into "negotiate" versus "no objection" costs anyone anything.

### 5. The thresholds audit themselves

The engine refuses any listing that arrives without a source and a freshness.
Holding its own thresholds to a lower standard would be incoherent — and
**moving a number into a config block does not justify it, it only relocates
it.** So every threshold declares what set it and what breaks if it is wrong:

| | |
|---|---|
| **EVIDENCED** (4) | `stale_days`, `implausible_z`, `dup_rent_tolerance`, `dup_posted_tolerance_days` — a measurement in this repo backs the value, and the run prints the check |
| **ASSUMED** (6) | `min_n_low`, `min_n_medium`, `max_sqft_per_bedroom`, `min_group_for_outlier_test`, `material_deviation`, `max_aspirational_bias` — judgement calls with nothing behind them yet |

Six of the ten real thresholds are still assumptions, and the run says so
out loud. Two of them — `min_n_low` and `min_n_medium` — decide when BOSS is
allowed to speak at all, and **neither can be validated from listings.** A
confidence tier is a claim about future accuracy; only Problem 2's outcome
loop can check it. That is the honest boundary of what this layer can prove
about itself.

### 6. Society aliases are learned, not hand-listed

Hand-listing aliases works for five societies and is unmaintainable across
Bangalore's ~27,000 listings. What generalises is the **suffix vocabulary**,
not the society list: strip the words listing sites append (`residency`,
`apartments`, `phase N`, …) and cluster the remaining core by string
similarity. That recovers all 5 societies from 16 raw spellings with no alias
table, and reproduces the hand-typed version exactly.

This is the highest-risk automation in the engine, so it is never trusted
blindly — clusters are written to `out/alias_registry.csv` for review, and
`aliases.csv` overrides any of them by hand.

Its two failure modes are not symmetric, and I hit the quieter one while
building this. Adding `park` to the suffix vocabulary split *Park Side
Terrace* from *Parkside Terraces* (`side` vs `parkside`, similarity 0.67) and
silently created a sixth society. Over-merging is loud and obviously wrong;
**over-splitting just shrinks every comp set with no error at all.**

## What the code will not do

- **It never deletes.** All 86 rows appear in `out/ledger.csv` with a status,
  a rule id, and a sentence a non-engineer can argue with.
- **It never invents.** Blank fields stay blank. An unrecognised society name
  is kept verbatim rather than guessed into a cluster.
- **It never picks for you.** Every threshold is in the `POLICY` block at the
  top of the file, each with the evidence that set it.
- **It answers the same way twice.** The bootstrap is seeded.

## Disagreeing with it

The brief asks that a human be able to inspect the result listing by listing
and disagree. Add a row to `overrides.csv` and re-run:

```csv
listing_id,decision,who,why
CP-0086,exclude,Supply reviewer,No area recorded so it can never be duplicate-checked
CP-0015,include,Demand reviewer,28d stale but broker confirmed on 18 Aug it is still available
```

A named human outranks every rule, in both directions. The overridden rule
stays visible in the ledger's `all_flags` column, so the disagreement is
recorded rather than erased.

---

## The judgment calls, and the evidence for each

Every one of these is a decision I made and could be wrong about. They are
listed here rather than buried in the code.

**Duplicate detection — the most dangerous filter.** A cross-post is flagged
only when society, area, BHK, *and both dates* match, with rent within 2%.
Requiring the date pair is deliberately strict. The looser rule most people
would write (society + area + BHK + similar rent) collapses 19 rows here —
but 7 of those are genuinely distinct homes that merely share a floor area.
Under-merging biases the sample; over-merging destroys evidence. I chose the
recoverable error. *This cost me a nicer-looking result: the loose rule gives
n=17 and a median of ₹58,500, which lands exactly midway between the two
maintenance interpretations. That symmetry was an artifact of a bug, so it is
not in this submission.*

**Implausible rent — MAD, not standard deviation**, because outliers poison
the very statistic used to detect them. Threshold is a robust z of 3.5, and
the data shows it is safe anywhere between 3.5 and 10: the two real bait rows
sit at |z| = 10.6 (₹12,000) and 28.3 (₹1,85,000), while the most extreme
*legitimate* listing sits at |z| = 3.04. Tightening to 2.5 "to be safe" would
delete six real listings — and every one of them is unfurnished or fully
furnished. At that threshold the test stops measuring implausibility and
starts measuring furnishing tier.

**Furnishing is a scope filter, not something to average over.** Within
Lakeview the tiers run ₹54,500 unfurnished → ₹59,500 semi → ₹68,500 fully.
A ₹14,000 spread, ~24% of rent. Medianing across it would be the single
largest silent error available in this dataset.

**"Phase 1" is merged into Lakeview Residences.** The only genuine aliasing
judgment call. Evidence: within every furnishing tier Phase 1 tracks the rest
of the society closely (semi ₹60,750 vs ₹59,500; fully ₹68,250 vs ₹69,000).
No separate price tier, so the merge is safe. Aliasing must run *before* the
society filter or the filter silently discards good rows.

**Cluster representative = the lowest rent.** Conservative in both directions
this benchmark is used: it makes Flent's own ask look more above-market, and
makes the room-split revenue premium look larger and therefore less credible.
The engine never flatters the deal.

**Staleness at 21 days is nearly irrelevant here**, and the run proves it —
the sensitivity block sweeps 14/21/30/45 days and no staleness filter at all,
and the median is ₹59,500 in every case. The conclusion does not depend on
where that knob is set. Worth knowing before anyone argues about it.

## What this does not do

- **No transaction data.** These are asking prices. A landlord asking ₹70,000
  and settling at ₹62,000 leaves only ₹70,000 in the dataset, and nothing in
  this packet can correct for it. The benchmark is a ceiling-biased estimate
  of asks, not an estimate of achieved rents — and it is labelled as such.
- **No photo or text deduplication.** Real cross-post detection should use
  image hashes and description similarity. `listings.csv` carries a
  `photo_count` but no marketplace images, and no description text. (The
  packet's four photos are site-visit stills of the *subject* home — evidence
  about this deal, not about the comps.)
- **No calibration.** Whether MEDIUM confidence actually means what it claims
  is Problem 2's job, and cannot be answered from 20 listings.
- **Nothing about the other inputs.** Capex, tenant revenue and fill time are
  the larger uncertainties on this deal. This layer only makes the market
  evidence honest.

## AI disclosure

Claude was used to: interrogate the framing before any code was written,
scan the 86 rows for alias and duplicate patterns, and draft this engine. The
judgment calls above are mine — in particular the dedup strictness (which
overturned an earlier, better-looking result), the 3.5 threshold, and the
decision to make refusal the headline output rather than a caveat. Every
number in this README is produced by running the script; none were
transcribed by hand.
