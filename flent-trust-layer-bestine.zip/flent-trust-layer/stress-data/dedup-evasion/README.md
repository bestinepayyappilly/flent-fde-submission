# dedup-evasion

**SYNTHETIC. Every row here is fabricated.**

Every home is cross-posted twice with the posted dates 5 days apart, beyond the 2-day dedup tolerance. Each home therefore counts twice.

**Expected:** EXPECTED TO DEFEAT THE ENGINE: n is roughly double the true count

24 listings.
