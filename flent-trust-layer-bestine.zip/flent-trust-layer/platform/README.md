# BOSS trust layer — platform

FLT-9 from the execution plan, built early at the user's request: a **ledger
inspection and refusal surface**, deliberately not a metrics dashboard.

```
https://flent-trust-layer.vercel.app                         frontend (Vercel)
https://flent-trust-layer-api-production.up.railway.app      API (Railway)
```

## The thing to look at

The scored-deal page puts a **refusal** in the slot where BOSS shows a green
`ACQUIRE`, at the same size and weight, with the one resolving question beside
it. That is the whole argument in one screen: *"we don't know yet, go ask
Supply this"* is a first-class output, not a missing one.

Two deals, both refusing for different reasons:

| deal | benchmark | why it refuses |
|---|---|---|
| `FLT-FDE-2026-01` semi-furnished | ₹59,500 · MEDIUM · n=20 | publishes a rate, refuses the *deviation* call — the comps mix two rent conventions and the readings straddle the benchmark |
| `FLT-FDE-2026-01-FF` fully-furnished | none | n=4, floor is 6. Same pipeline, same thresholds, one configuration to the left |

Tabs are deep-linkable (`?tab=ledger`), so a reviewer can send someone the
exact view rather than "open it and click around".

## Upload your own pull

`/upload` scores an arbitrary pull through the same pipeline. Two files are
required and one is optional:

| file | required | contents |
|---|---|---|
| `listings.csv` | yes | `listing_id, source, posted_date, last_seen_date, society, locality, bhk, furnishing, area_sqft, rent, deposit, photo_count, poster_type`. Header row required. `area_sqft` and `deposit` may be blank, and blanks stay blank. |
| `deal.json` | yes | `deal_id, snapshot, society, bhk, furnishing, base_rent, maintenance`. A deal missing any of these is rejected outright rather than defaulted. |
| `overrides.csv` | no | `listing_id, decision, who, why`. A named human outranks every rule in both directions. |

Nothing is persisted. The files live in a temp directory for one request and
are deleted afterwards. `GET /api/upload/spec` returns this contract as JSON,
so the UI does not hardcode it.

The easiest thing to test is the guardrail: delete a field from `deal.json`
and upload it. The engine refuses rather than substituting a default.

## Stress data

Nine labelled synthetic pulls, one per known failure mode:

```
python3 trust-layer/generate_stress_data.py --check
```

That writes `stress-data/` and then scores each scenario, printing what the
engine actually did next to what the scenario expected. Every row is
fabricated and every folder says so.

| scenario | what it injects | what the engine does |
|---|---|---|
| `clean-baseline` | nothing. The control | MEDIUM, n=20, 3.4% interval |
| `thin-evidence` | only 4 comparables | refuses outright |
| `single-portal` | 19 of 20 comps from one portal | LOW, names the portal |
| `broken-records` | 5 impossible rows | benches all 5 with a rule id |
| `alias-collision` | `Lakeview` / `Lake View` / `Lakeside` | merges the first two, keeps Lakeside separate |
| `determinate-call` | subject clear of the comps | ABOVE MARKET, ROBUST 19/19 |
| `ask-inflation-8pc` | every ask inflated 8% | publishes a confidently wrong MEDIUM, flagged FRAGILE |
| `dedup-evasion` | cross-posts 5 days apart | **defeats the engine.** n is double the true count |
| `bait-inside-distribution` | 4 plausibly cheap rows | **defeats the filter.** The median absorbs it |

The last two are meant to fail. A harness that only generates cases its own
code passes is a demo, not a test, and both correspond to open entries in
`trust-layer/FAILURES.md` (S1 and S2).

`determinate-call` is the one that matters most in the other direction: it
proves the engine does not refuse whenever anything is ambiguous. The
maintenance convention is just as unresolved there, but both readings land on
the same side of the benchmark, so the engine answers plainly.

## Architecture

```
platform/api/    FastAPI over trust_layer.py            → Railway (Dockerfile at repo root)
platform/web/    Next.js 16 + shadcn/ui + Tailwind      → Vercel
```

**The API does not reimplement the pipeline.** It imports `trust_layer.py` and
`robustness.py` and serves what they return, so the UI cannot drift from the
proof. Verified: every figure on the site matches `python3 trust_layer.py`.

Two consequences worth stating:

- The engine keeps module-level state (`SUBJECT`, `SNAPSHOT`, `LISTINGS_PATH`
  are globals that `load_deal()` and `run()` mutate). Correct for a CLI, wrong
  for a server — so `engine.py` holds a lock around every scoring call. A real
  deployment would make the engine take its subject as an argument instead.
- The engine writes for a terminal (ASCII `--`, `Rs`). `engine._prose()`
  normalises those to `—` and `₹` at the API boundary. Presentation only; no
  figure is changed and the CLI is untouched.

The design is read off `screenshots/` — warm off-white ground, white cards,
emerald primary, and Plus Jakarta Sans, which is the typeface BOSS uses and
the one the brief's own PDF embeds. Refusals are ochre, never red: a refusal
is a legitimate output, not an error.

## Run locally

```
cd platform/api && pip install -r requirements.txt
uvicorn main:app --port 8077

cd platform/web && npm install
echo 'NEXT_PUBLIC_API_URL=http://127.0.0.1:8077' > .env.local
npm run dev
```

## What it deliberately does not have

No charts, no aggregate market views, no trend lines. Anything that invites
reading a number off a screen without its ledger reintroduces the exact failure
this project exists to fix — *a bad market rate looks just as precise on a
dashboard as a good one.*
