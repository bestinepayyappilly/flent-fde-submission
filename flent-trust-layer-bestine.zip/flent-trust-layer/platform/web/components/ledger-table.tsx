"use client";

import { ArrowRight, Search } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { rupees, type Listing, type Rule } from "@/lib/api";
import { RuleInfo } from "@/components/rule-info";
import { STATUS_HELP, statusLabel } from "@/lib/labels";

const STATUS_STYLE: Record<string, string> = {
  INCLUDED: "border-acquire-border bg-acquire-bg text-acquire",
  OVERRIDE_IN: "border-acquire-border bg-acquire-bg text-acquire",
  BENCHED_INTEGRITY: "border-[#f0cfc6] bg-[#fcefeb] text-[#9b3620]",
  REDUNDANT: "border-border bg-secondary text-muted-foreground",
  STALE: "border-border bg-secondary text-muted-foreground",
  OUT_OF_SCOPE: "border-border bg-secondary text-muted-foreground",
  OVERRIDE_OUT: "border-refuse-border bg-refuse-bg text-refuse",
};

export function LedgerTable({
  rows,
  dealId,
  rules,
  hideIntro,
}: {
  rows: Listing[];
  dealId: string;
  rules: Record<string, Rule>;
  /** The ledger page states this above the table; do not say it twice. */
  hideIntro?: boolean;
}) {
  const [status, setStatus] = useState<string>("ALL");
  const [q, setQ] = useState("");

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const r of rows) c[r.status] = (c[r.status] ?? 0) + 1;
    return c;
  }, [rows]);

  const filtered = useMemo(() => {
    const n = q.trim().toLowerCase();
    return rows.filter(
      (r) =>
        (status === "ALL" || r.status === status) &&
        (!n ||
          r.id.toLowerCase().includes(n) ||
          r.society_raw.toLowerCase().includes(n) ||
          r.source.toLowerCase().includes(n) ||
          r.reason.toLowerCase().includes(n)),
    );
  }, [rows, status, q]);

  const tabs = ["ALL", ...Object.keys(counts).sort()];

  return (
    <div>
      {!hideIntro && (
        <p className="max-w-3xl text-[13.5px] leading-relaxed text-muted-foreground">
          Every one of the {rows.length} listings we scraped is here, including
          the ones we did not use. Nothing is quietly deleted. Each row says in
          plain English why it was kept or dropped, so you can disagree with any
          single one. Click a row to see the full listing.
        </p>
      )}

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:overflow-visible sm:px-0 sm:pb-0">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setStatus(t)}
            className={`shrink-0 whitespace-nowrap rounded-full border px-3 py-1.5 text-[11.5px] font-medium transition ${
              status === t
                ? "border-foreground bg-foreground text-background"
                : "border-border bg-card text-muted-foreground hover:border-muted-foreground/40"
            }`}
          >
            {t === "ALL" ? "All" : statusLabel(t)}
            <span className="tnum ml-1.5 opacity-70">
              {t === "ALL" ? rows.length : counts[t]}
            </span>
          </button>
        ))}
        </div>
        <div className="relative sm:ml-auto sm:w-[260px]">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search id, society, portal, reason…"
            className="w-full rounded-md border border-border bg-card py-2 pl-9 pr-3 text-[13px] outline-none focus:border-foreground"
          />
        </div>
      </div>

      <div className={`mt-4 hidden overflow-hidden rounded-lg border border-border bg-card ${filtered.length ? "sm:block" : ""}`}>
        <div className="max-h-[560px] overflow-auto">
          <table className="w-full min-w-[1040px] text-left">
            <thead className="sticky top-0 z-10">
              <tr className="border-b border-border bg-secondary/70 text-[11px] font-medium tracking-[0.06em] text-muted-foreground">
                <th className="px-5 py-3.5">ID</th>
                <th className="px-5 py-3.5">STATUS</th>
                <th className="whitespace-nowrap px-5 py-3.5">RULE</th>
                <th className="px-5 py-3.5">RENT</th>
                <th className="px-5 py-3.5">SOCIETY</th>
                <th className="px-5 py-3.5">WEBSITE</th>
                <th className="min-w-[320px] px-5 py-3.5">WHY</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => (
                <tr
                  key={r.id}
                  className="border-b border-border/70 align-top last:border-0 hover:bg-secondary/40"
                >
                  <td className="whitespace-nowrap px-5 py-3">
                    <Link
                      href={`/deals/${dealId}/listings/${r.id}`}
                      className="font-mono text-[12px] hover:underline"
                    >
                      {r.id}
                    </Link>
                  </td>
                  <td className="px-5 py-3">
                    <span
                      className={`inline-block whitespace-nowrap rounded-full border px-2 py-0.5 text-[10.5px] font-medium ${
                        STATUS_STYLE[r.status] ?? "border-border bg-secondary"
                      }`}
                    >
                      {statusLabel(r.status)}
                    </span>
                  </td>
                  <td className="whitespace-nowrap px-5 py-3">
                    <RuleInfo id={r.rule} rule={rules[r.rule]} />
                  </td>
                  <td className="tnum whitespace-nowrap px-5 py-3 text-[13px] font-medium">
                    {rupees(r.rent)}
                  </td>
                  <td className="min-w-[190px] px-5 py-3 text-[13px]">
                    {r.society_raw}
                    {r.society_raw !== r.society && (
                      <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                        <ArrowRight className="size-3 shrink-0" aria-hidden />
                        {r.society}
                      </span>
                    )}
                  </td>
                  <td className="whitespace-nowrap px-5 py-3 text-[12.5px] text-muted-foreground">
                    {r.source}
                  </td>
                  <td className="px-5 py-3 text-[12.5px] leading-relaxed text-muted-foreground">
                    {r.reason}
                    {r.override_by && (
                      <span className="mt-1 block font-semibold text-acquire">
                        overridden by {r.override_by}
                      </span>
                    )}
                    {/* The primary flag is chosen by status precedence, not
                        by position, so filter by rule rather than slicing —
                        otherwise a row lists its own reason as "also". */}
                    {r.all_flags.filter((f) => f.rule !== r.rule).length > 0 && (
                      <span className="mt-1 block text-[11px] italic">
                        also matched:{" "}
                        {r.all_flags
                          .filter((f) => f.rule !== r.rule)
                          .map((f) => f.rule)
                          .join(", ")}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {/* Below sm a seven-column table is unreadable, so each row becomes a
          card carrying the same fields. */}
      <div className={`mt-4 space-y-2 ${filtered.length ? "sm:hidden" : "hidden"}`}>
        {filtered.map((r) => (
          <Link
            key={r.id}
            href={`/deals/${dealId}/listings/${r.id}`}
            className="block rounded-lg border border-border bg-card p-4"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-mono text-[12px]">{r.id}</span>
              <span
                className={`rounded-full border px-2 py-0.5 text-[10.5px] font-medium ${
                  STATUS_STYLE[r.status] ?? "border-border bg-secondary"
                }`}
              >
                {statusLabel(r.status)}
              </span>
            </div>
            <div className="tnum mt-2 text-[15px] font-medium">
              {rupees(r.rent)}
            </div>
            <div className="mt-1 text-[12px] text-muted-foreground">
              {r.society_raw} · {r.source}
              {r.rule && <span className="font-mono"> · {r.rule}</span>}
            </div>
            <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
              {r.reason}
            </p>
            {r.override_by && (
              <p className="mt-1 text-[12px] font-medium text-acquire">
                overridden by {r.override_by}
              </p>
            )}
          </Link>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="mt-4 rounded-lg border border-dashed border-border px-5 py-10 text-center text-[13px] text-muted-foreground">
          No listing matches that.{" "}
          <button
            onClick={() => {
              setStatus("ALL");
              setQ("");
            }}
            className="font-medium text-foreground underline"
          >
            Clear the filters
          </button>
        </div>
      )}

      <p className="mt-3 text-[12px] text-muted-foreground">
        Showing {filtered.length} of {rows.length}.
        {status !== "ALL" && STATUS_HELP[status] && (
          <span className="ml-1">{STATUS_HELP[status]}</span>
        )}
      </p>
    </div>
  );
}
