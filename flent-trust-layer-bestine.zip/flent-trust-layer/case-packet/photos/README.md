# Site-visit stills

These four frames were selected from a walkthrough and re-exported without source
metadata. They are evidence, not professional listing photography.

| File | View | What is and is not established |
|---|---|---|
| `01-living-room.jpg` | Living room and balcony edge | Daylight and broad layout are visible; direction and noise are not verified. |
| `02-kitchen.jpg` | Kitchen and storage | Cabinet provision is visible; appliance condition is not tested. |
| `03-bedroom.jpg` | Bedroom and wardrobe | Storage and usable floor area are visible; exact dimensions are not measured. |
| `04-bathroom.jpg` | Bathroom | Fixtures are visible; plumbing, exhaust and seepage are not signed off. |
