# bait-inside-distribution

**SYNTHETIC. Every row here is fabricated.**

Four lead-harvesting listings priced just below the cluster rather than absurdly below it. The MAD test cannot reach them because they sit inside the distribution.

**Expected:** bait survives every filter and is counted as evidence, which is the defect. But 4 cheap rows in 22 barely move a MEDIAN, so the published rate is close to unchanged. The filter is defeated and the statistic absorbs it. That split is the finding: a mean would have moved

22 listings.
