# determinate-call

**SYNTHETIC. Every row here is fabricated.**

The subject is well above the comps on BOTH readings of the maintenance convention: base 64,000 and all-in 68,000 against a benchmark near 52,000. The fork is still unresolved, but it no longer changes the call.

**Expected:** gives a determinate ABOVE MARKET call rather than refusing

22 listings.
