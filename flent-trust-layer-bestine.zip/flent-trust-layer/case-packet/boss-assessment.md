# BOSS assessment snapshot — FLT-FDE-2026-01

Snapshot time: **18 August 2026, 17:00 IST**  
Status: **PROVISIONAL HOLD**  
Owner: Acquisition lead

This is a sanitised exercise output, not a production-engine export. It gives
candidates choosing Problem 3 a recommendation to explain without exposing Flent's
production thresholds, weights or source code.

## Current read

The home may work on better terms, but the current evidence is not strong enough to
authorise an acquisition. Hold until the team has a cleaned comparable benchmark,
a written landlord alternative, a vendor BOQ and stronger tenant-price evidence.

The recommendation is provisional because the inputs that dominate the answer are
still estimates. `HOLD` here means "resolve the evidence", not "reject the home".

## Transparent exercise arithmetic

The snapshot uses the context pack's illustrative arithmetic and a **95% occupancy
assumption chosen for this exercise**. It does not apply a production hurdle.

### Opening ask

| Line | Calculation | Result |
|---|---|---:|
| Planned tenant revenue | ₹72,000 × 95% | ₹68,400 / month |
| Monthly owner cost | ₹56,000 rent + ₹5,000 maintenance | ₹61,000 / month |
| Occupancy-adjusted contribution | ₹68,400 − ₹61,000 | ₹7,400 / month |
| Contribution per lettable room | ₹7,400 ÷ 2 | ₹3,700 / month |
| Deposit not covered by tenant deposits | ₹2,80,000 − ₹1,80,000 | ₹1,00,000 |
| Simplified capital employed | ₹1,60,000 capex + ₹1,00,000 uncovered deposit | ₹2,60,000 |
| Simple payback | ₹2,60,000 ÷ ₹7,400 | 35.1 months |

First-fill vacancy, escalation, the exit painting charge and central operating costs
are not included in that simple payback. Each would need an explicit treatment in a
decision model.

### Verbal ₹54,000 alternative

If base rent falls to ₹54,000 and all other working assumptions stay unchanged,
monthly owner cost becomes ₹59,000, contribution becomes ₹9,400 and simple payback
becomes **27.7 months**. The landlord has not confirmed this alternative in writing.

### Demand downside

If the rooms achieve ₹38,000 and ₹31,000 instead of ₹38,000 and ₹34,000, planned
tenant revenue at 95% occupancy becomes ₹65,550. At the opening ask, contribution
falls to ₹4,550 and simple payback becomes **57.1 months**, before first-fill cost.

## Evidence behind the read

| Evidence | Status | Effect on recommendation |
|---|---|---|
| Opening landlord terms in `deal.md` | Recorded, not signed | Used in the opening-ask scenario. |
| Verbal ₹54,000 alternative | Unconfirmed | Shown as a scenario only. |
| ₹72,000 tenant-revenue hypothesis | Estimate; no signed tenants | Largest positive assumption in the economics. |
| ₹1,60,000 capex | Placeholder; no BOQ | Keeps capital employed and payback provisional. |
| Raw comparable listings | 86 noisy records | Raw median is not accepted as a benchmark until cleaning choices are inspectable. |
| Demand thread | 4 comparable enquiries in 14 days | Directional only; sample is too small for certainty. |
| Site-visit stills and Property note | Partial visual evidence | Supports daylight/storage; does not close technical checks. |
| Landlord and tenant deposits | One recorded, one assumed | Creates an estimated ₹1,00,000 cash gap. |

## What is missing or disputed

- No written confirmation of the ₹54,000 alternative.
- No vendor BOQ or completed technical inspection.
- No signed room prices; the second room has a stated downside case.
- Comparable listings contain aliases, duplicates, staleness and outliers, while
  maintenance is inconsistently captured.
- The first-fill estimate has no cited historical cohort in the packet.

## What would change the call

| New evidence | Likely movement |
|---|---|
| Written lower rent, clean BOQ and tenant-price proof | Re-run as `NEGOTIATE` or `ACQUIRE` using a clearly chosen exercise hurdle. |
| Clean comps show the home materially above credible market | Move towards `NEGOTIATE` or `PASS`. |
| BOQ or technical diligence reveals material additional work | Keep `HOLD` or move to `PASS`. |
| Demand evidence validates both room prices and fill timing | Reduces the largest revenue and vacancy uncertainty. |
| Society rules prevent working-professional sharing | `PASS`, regardless of the headline arithmetic. |

There is deliberately no hidden answer key or production threshold in this file.
Candidates should state the rule they choose, test sensitivity around it and keep
the evidence status visible.
