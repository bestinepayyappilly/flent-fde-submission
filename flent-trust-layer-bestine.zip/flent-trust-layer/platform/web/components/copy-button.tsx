"use client";

import { Check, Copy } from "lucide-react";
import { useEffect, useRef, useState } from "react";

/**
 * Copy-to-clipboard, generic over whatever text it is handed.
 *
 * navigator.clipboard is unavailable on insecure origins and can be blocked
 * by permissions, so a failure is reported rather than silently swallowed:
 * a button that says nothing after a click is worse than one that says it
 * could not do the thing.
 */
export function CopyButton({
  value,
  label = "Copy",
  className = "",
}: {
  value: string;
  label?: string;
  className?: string;
}) {
  const [state, setState] = useState<"idle" | "done" | "failed">("idle");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
      setState("done");
    } catch {
      setState("failed");
    }
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setState("idle"), 2000);
  }

  return (
    <button
      onClick={copy}
      className={`inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-[12.5px] font-medium transition ${
        state === "failed"
          ? "border-refuse-border bg-refuse-bg text-refuse"
          : "border-border bg-card text-foreground hover:bg-secondary"
      } ${className}`}
    >
      {state === "done" ? (
        <Check className="size-3.5" aria-hidden />
      ) : (
        <Copy className="size-3.5" aria-hidden />
      )}
      {state === "done"
        ? "Copied"
        : state === "failed"
          ? "Copy blocked"
          : label}
    </button>
  );
}
