"use client";

import Link from "next/link";
import { rupees } from "@/lib/api";

type Survivor = {
  id: string;
  rent: number;
  source: string;
  age_days: number;
  poster: string;
};

/**
 * The evidence floor, drawn as a polygon whose vertices are comparables.
 *
 * The vertex count is min_n_low, not an arbitrary shape: one corner per
 * comparable the engine requires before it will publish anything. Filled
 * corners are real surviving listings; hollow ones are the shortfall, and
 * the outline is left open across them, so the picture says the same thing
 * the refusal does. A pentagon or octagon would have looked tidier and meant
 * nothing, because neither number is in the data.
 */
export function EvidenceFloor({
  survivors,
  floor,
  dealId,
}: {
  survivors: Survivor[];
  floor: number;
  dealId: string;
}) {
  const n = Math.max(floor, survivors.length);
  const R = 66;
  const cx = 128;
  const cy = 108;
  const angle = (i: number) => (Math.PI * 2 * i) / n - Math.PI / 2;
  const pt = (i: number, m = 1): [number, number] => [
    cx + Math.cos(angle(i)) * R * m,
    cy + Math.sin(angle(i)) * R * m,
  ];

  const slots = Array.from({ length: n }, (_, i) => survivors[i] ?? null);
  const missing = n - survivors.length;

  // Only the run of filled corners is joined. The outline stays open across
  // the gap rather than being closed with a line that has no evidence.
  const filled = slots
    .map((s, i) => (s ? pt(i) : null))
    .filter(Boolean) as [number, number][];
  const path = filled.map(([x, y]) => `${x},${y}`).join(" ");

  return (
    <div>
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <span className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
          HOW MUCH EVIDENCE WE NEED
        </span>
        <span className="text-[12px] text-muted-foreground">
          one corner per home we need before we will give a rate
        </span>
      </div>

      <div className="mt-4 grid gap-6 sm:grid-cols-[256px_minmax(0,1fr)] sm:items-center">
        <svg viewBox="0 0 256 216" className="w-full max-w-[256px]">
          {/* the shape the evidence would have to fill */}
          <polygon
            points={Array.from({ length: n }, (_, i) => pt(i).join(",")).join(" ")}
            fill="none"
            stroke="var(--border)"
            strokeWidth="1"
            strokeDasharray="3 3"
          />
          {Array.from({ length: n }, (_, i) => {
            const [x, y] = pt(i);
            return (
              <line
                key={`spoke-${i}`}
                x1={cx}
                y1={cy}
                x2={x}
                y2={y}
                stroke="var(--border)"
                strokeWidth="1"
              />
            );
          })}

          {/* What actually survived, left deliberately unclosed. fill is
              "none" because SVG fills a polyline as though the last point
              joined the first, which would paint the closed shape this
              evidence does not support. */}
          {filled.length > 1 && (
            <polyline
              points={path}
              fill="none"
              stroke="var(--refuse)"
              strokeWidth="1.75"
              strokeLinejoin="round"
            />
          )}

          {slots.map((s, i) => {
            const [x, y] = pt(i);
            return s ? (
              <circle
                key={i}
                cx={x}
                cy={y}
                r="5"
                fill="var(--refuse)"
                stroke="var(--background)"
                strokeWidth="1.5"
              />
            ) : (
              <circle
                key={i}
                cx={x}
                cy={y}
                r="5"
                fill="var(--background)"
                stroke="var(--muted-foreground)"
                strokeWidth="1.25"
                strokeDasharray="2 2"
              />
            );
          })}

          <text
            x={cx}
            y={cy - 4}
            textAnchor="middle"
            fontSize="26"
            fontWeight="600"
            fill="var(--foreground)"
          >
            {survivors.length}
          </text>
          <text
            x={cx}
            y={cy + 12}
            textAnchor="middle"
            fontSize="10.5"
            fill="var(--muted-foreground)"
          >
            of {floor} needed
          </text>

          {slots.map((s, i) => {
            const [x, y] = pt(i, 1.32);
            return (
              <text
                key={`label-${i}`}
                x={x}
                y={y}
                textAnchor={
                  Math.abs(x - cx) < 6 ? "middle" : x > cx ? "start" : "end"
                }
                dominantBaseline="middle"
                fontSize="9"
                fill={s ? "var(--muted-foreground)" : "var(--muted-foreground)"}
                fontStyle={s ? "normal" : "italic"}
              >
                {s ? s.id : "missing"}
              </text>
            );
          })}
        </svg>

        <div className="min-w-0">
          {slots.map((s, i) =>
            s ? (
              <Link
                key={s.id}
                href={`/deals/${dealId}/listings/${s.id}`}
                className="flex items-baseline justify-between gap-3 border-b border-border py-2 last:border-0 hover:bg-secondary/50"
              >
                <span className="min-w-0">
                  <span className="font-mono text-[12px]">{s.id}</span>
                  <span className="ml-2 text-[11.5px] text-muted-foreground">
                    {s.source} · {s.age_days}d old · {s.poster}
                  </span>
                </span>
                <span className="tnum shrink-0 text-[12.5px] font-medium">
                  {rupees(s.rent)}
                </span>
              </Link>
            ) : (
              <div
                key={`gap-${i}`}
                className="flex items-baseline justify-between gap-3 border-b border-dashed border-border py-2 text-muted-foreground last:border-0"
              >
                <span className="text-[12px] italic">no home found</span>
                <span className="text-[12.5px]">—</span>
              </div>
            ),
          )}
        </div>
      </div>

      <p className="mt-4 text-[12.5px] leading-relaxed text-muted-foreground">
        {missing} {missing === 1 ? "corner is" : "corners are"} empty, so the
        shape never closes. The minimum of {floor} is a judgement call, not
        something we measured, and it is worth knowing how fine the line is:
        two more listings would fill those corners and we would publish a rate.
        That is a known weakness, and it is written down rather than hidden.
      </p>
    </div>
  );
}
