# Internal thread extracts

Names and channel identifiers have been removed. Times are in IST. Spelling and
shorthand have been lightly normalised, but uncertainty and disagreement are
preserved.

## 17 August 2026

**10:12 — Supply**  
Visited this morning. Owner opening is ₹56k rent + ₹5k maintenance, ₹2.8L deposit,
7% escalation after 11 months and 15 rent-free days. Keys are ready. They want a
quick close and say the deposit is not negotiable.

**10:47 — Property**  
Good daylight in the living room and both bedrooms. Wardrobes and kitchen storage
are usable. Utility wall has a damp patch near the floor and the master-bath exhaust
is weak. I have put ₹1.6L as a placeholder for paint, deep clean, two beds, soft
furnishing and minor repairs. This is not a BOQ.

**12:05 — Demand**  
We had 11 enquiries in the wider Harlur / Kasavanahalli pocket over the last 14
days, but only four were for comparable two-room sharing homes. Prospects discussed
₹34k–₹38k per room. None of those conversations is a signed booking, and two wanted
immediate move-in before this home can be ready.

**15:26 — Supply**  
Owner called back. Could "probably do 54" on base rent if we retain the full ₹2.8L
deposit and sign this week. I asked for it in writing. Nothing received yet.

## 18 August 2026

**09:18 — Market operations**  
Raw export attached: 86 rows from four portals. Society spelling is inconsistent.
There are cross-posts, old rows still marked live and at least one 3BHK that looks
like this 2BHK copied with the wrong label. We do not capture maintenance reliably,
so the listing rents are not always all-in. Please do not quote a median without
showing the cleaning choices.

**11:32 — Pricing**  
Working ladder is ₹38k for the larger room and ₹34k for the second room = ₹72k gross
at full occupancy. That is a hypothesis, not an achieved price. If the second room
lands nearer ₹31k, the deal gets tight at the opening ask.

**13:06 — Finance**  
If we collect 2.5 months of the working tenant revenue, tenant deposits total ₹1.8L.
That leaves ₹1L of landlord deposit uncovered before capex. Please show the cash
exposure separately from monthly margin.

**16:10 — Acquisition lead**  
Society and apartment look promising, but do not turn "bright home" into a buy
recommendation. We still need a defensible comp set, the repair scope and a clear
view of what happens if room 2 fills late. Recommend acquire / negotiate / hold /
pass, and say exactly what evidence would change the call.
