"use client";

import { notFound } from "next/navigation";
import { ListingView } from "@/components/listing-view";
import { ApiError, ListingSkeleton } from "@/components/skeleton";
import { getDeal } from "@/lib/api";
import { useApi } from "@/lib/use-api";

export function ListingClient({ id, lid }: { id: string; lid: string }) {
  const { data: d, error, loading, reload } = useApi(() => getDeal(id), [id]);

  if (error) return <ApiError error={error} onRetry={reload} />;
  if (loading || !d) return <ListingSkeleton />;

  // The row is found client-side now, so a bad listing id is a 404 raised
  // after the fetch rather than before it. Same outcome, one round trip later.
  const r = d.listings.find((x) => x.id === lid);
  if (!r) notFound();

  const stale = d.policy.find((t) => t.name === "stale_days");

  return (
    <ListingView
      d={d}
      r={r}
      staleDays={typeof stale?.value === "number" ? stale.value : null}
    />
  );
}
