/**
 * Loading and failure states for the four data-backed pages.
 *
 * Each skeleton mirrors the real layout closely enough that nothing jumps
 * when the data lands: same paddings, same card shapes, same number of rows.
 * A spinner in the middle of an empty page would be less work and would tell
 * the reader nothing about what is coming.
 *
 * These deliberately show no numbers, not even placeholder ones. This site's
 * whole argument is that a figure you cannot trace is worse than no figure,
 * and a fake ₹59,500 flashing before the real one would be exactly that.
 */

export function Skeleton({ className = "" }: { className?: string }) {
  return (
    <div
      className={`animate-pulse rounded bg-secondary ${className}`}
      aria-hidden
    />
  );
}

/** Wraps a skeleton so screen readers hear "loading" instead of nothing. */
function Loading({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div role="status" aria-busy="true" aria-label={label}>
      <span className="sr-only">{label}</span>
      {children}
    </div>
  );
}

/**
 * The API is a separate deployment on a free tier: it sleeps, it redeploys,
 * it can be down. Saying which of those is unknowable from here, so the copy
 * says what is true and offers the one useful action.
 */
export function ApiError({
  error,
  onRetry,
}: {
  error: string;
  onRetry: () => void;
}) {
  return (
    <div className="px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
      <div className="max-w-xl rounded-lg border border-refuse-border bg-refuse-bg p-6">
        <h1 className="text-[18px] font-semibold text-refuse">
          Could not reach the scoring API
        </h1>
        <p className="mt-2 text-[13.5px] leading-relaxed text-refuse opacity-90">
          Every figure on this site is computed by the engine on request, so
          there is nothing cached to show you instead. The API is a separate
          deployment and may be waking up.
        </p>
        <p className="mt-3 font-mono text-[12px] text-refuse opacity-75">
          {error}
        </p>
        <button
          onClick={onRetry}
          className="mt-4 rounded-md bg-foreground px-4 py-2 text-[13px] font-medium text-background transition hover:opacity-90"
        >
          Try again
        </button>
      </div>
    </div>
  );
}

export function PipelineSkeleton() {
  return (
    <Loading label="Loading deals">
      <div className="px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
        <Skeleton className="h-8 w-56" />
        <Skeleton className="mt-3 h-4 w-full max-w-xl" />

        <div className="mt-6 grid grid-cols-[minmax(0,1fr)] gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="rounded-lg border border-border bg-card p-5">
              <Skeleton className="h-3 w-20" />
              <Skeleton className="mt-3 h-8 w-14" />
              <Skeleton className="mt-2 h-3 w-28" />
            </div>
          ))}
        </div>

        <div className="mt-7 overflow-hidden rounded-lg border border-border">
          <div className="border-b border-border bg-secondary px-4 py-3">
            <Skeleton className="h-3 w-32" />
          </div>
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <div
              key={i}
              className="flex items-center gap-4 border-b border-border px-4 py-4 last:border-0"
            >
              <Skeleton className="h-4 w-40 shrink-0" />
              <Skeleton className="hidden h-4 w-24 sm:block" />
              <Skeleton className="ml-auto h-4 w-16 shrink-0" />
            </div>
          ))}
        </div>
      </div>
    </Loading>
  );
}

export function DealSkeleton() {
  return (
    <Loading label="Scoring this deal">
      <div className="px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
        <Skeleton className="h-4 w-16" />
        <Skeleton className="mt-4 h-9 w-72 max-w-full" />
        <Skeleton className="mt-3 h-3.5 w-full max-w-lg" />
        <Skeleton className="mt-2 h-3.5 w-64" />
        <Skeleton className="mt-5 h-9 w-44 rounded-md" />

        <div className="mt-6 grid gap-4 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)] lg:gap-5">
          {/* The verdict card. Its height is roughly known, so the page below
              does not jump when the real one arrives. */}
          <div className="rounded-lg border border-border bg-card p-6 sm:p-7">
            <div className="flex items-center gap-3">
              <Skeleton className="h-9 w-9 rounded-full" />
              <Skeleton className="h-7 w-60 max-w-full" />
            </div>
            <div className="mt-5 space-y-2">
              <Skeleton className="h-3.5 w-full" />
              <Skeleton className="h-3.5 w-full" />
              <Skeleton className="h-3.5 w-4/5" />
            </div>
            <div className="mt-5 space-y-2 border-t border-border pt-4">
              <Skeleton className="h-3.5 w-3/4" />
            </div>
            <div className="mt-5 border-t border-border pt-4">
              <Skeleton className="h-3 w-14" />
              <div className="mt-3 space-y-3">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="flex flex-col gap-2 sm:flex-row sm:gap-4">
                    <Skeleton className="h-3.5 w-20 shrink-0" />
                    <div className="w-full space-y-1.5">
                      <Skeleton className="h-3.5 w-full" />
                      <Skeleton className="h-3.5 w-2/3" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="rounded-lg border border-border bg-card p-6 sm:p-7">
            <Skeleton className="h-3 w-40" />
            <Skeleton className="mt-3 h-16 w-full rounded-md" />
            <Skeleton className="mt-4 h-8 w-36 rounded-md" />
            <div className="mt-5 space-y-2 border-t border-border pt-4">
              <Skeleton className="h-3.5 w-2/3" />
              <Skeleton className="h-3.5 w-full" />
            </div>
          </div>
        </div>

        {/* The tab row: Overview, Money, Removed, Listings, Stress test... */}
        <div className="mt-7 flex gap-5 overflow-hidden border-b border-border pb-3">
          {["w-16", "w-12", "w-18", "w-14", "w-20", "w-12", "w-16"].map(
            (w, i) => (
              <Skeleton key={i} className={`h-4 shrink-0 ${w}`} />
            ),
          )}
        </div>
      </div>
    </Loading>
  );
}

/** Just the table. The ledger's heading and deal switcher are real from the
 *  first paint, so they are not faked here. */
export function LedgerSkeleton() {
  return (
    <Loading label="Loading the ledger">
      <div>
        <Skeleton className="mt-5 h-3.5 w-full max-w-md" />
        <div className="mt-6 overflow-hidden rounded-lg border border-border">
          <div className="border-b border-border bg-secondary px-4 py-3">
            <Skeleton className="h-3 w-40" />
          </div>
          {Array.from({ length: 12 }, (_, i) => (
            <div
              key={i}
              className="flex items-center gap-4 border-b border-border px-4 py-3 last:border-0"
            >
              <Skeleton className="h-3.5 w-24 shrink-0" />
              <Skeleton className="hidden h-3.5 w-32 sm:block" />
              <Skeleton className="ml-auto h-3.5 w-20 shrink-0" />
            </div>
          ))}
        </div>
      </div>
    </Loading>
  );
}

export function ListingSkeleton() {
  return (
    <Loading label="Loading this listing">
      <div className="px-4 py-6 sm:px-6 lg:px-10 lg:py-9">
        <Skeleton className="h-4 w-24" />
        <Skeleton className="mt-4 h-8 w-64 max-w-full" />
        <Skeleton className="mt-3 h-3.5 w-80 max-w-full" />
        <div className="mt-6 grid gap-4 lg:grid-cols-2 lg:gap-5">
          {[0, 1].map((i) => (
            <div key={i} className="rounded-lg border border-border bg-card p-6">
              <Skeleton className="h-3 w-28" />
              <div className="mt-4 space-y-2.5">
                {[0, 1, 2, 3, 4].map((j) => (
                  <div key={j} className="flex justify-between gap-4">
                    <Skeleton className="h-3.5 w-24" />
                    <Skeleton className="h-3.5 w-16" />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </Loading>
  );
}
