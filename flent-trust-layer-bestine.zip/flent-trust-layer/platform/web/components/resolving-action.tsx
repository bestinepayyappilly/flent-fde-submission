"use client";

import { RotateCcw } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { CopyButton } from "@/components/copy-button";

/**
 * The resolving question, editable before it is sent.
 *
 * The engine produces the wording; a human sends it. Those are different
 * jobs, so the text is a real input rather than a fixed string, and the copy
 * button hands over whatever is on screen.
 *
 * Deliberately not generated. The question comes from the engine's own
 * arithmetic (which two branches straddle the benchmark, and by how much),
 * so putting a model in front of it would replace a derived sentence with a
 * plausible one. Editing is for tone and context, not for inventing the ask.
 *
 * Edits live in this browser tab only. Nothing is persisted, and the note
 * under the field says so rather than implying a saved draft.
 */
export function ResolvingAction({
  question,
  owner,
  cost,
  unlocks,
  children,
}: {
  question: string;
  owner: string;
  cost: string;
  unlocks: string;
  /** The answer control. The question and its answer are one thing. */
  children?: React.ReactNode;
}) {
  const [text, setText] = useState(question);
  const ref = useRef<HTMLTextAreaElement | null>(null);
  const edited = text.trim() !== question.trim();

  // Grow to fit rather than scrolling inside a fixed box.
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${el.scrollHeight}px`;
  }, [text]);

  return (
    <div className="rounded-lg border border-border bg-card p-6 sm:p-7">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-[11px] font-medium tracking-[0.07em] text-muted-foreground">
          THE ONE THING TO CONFIRM
        </div>
        {edited && (
          <button
            onClick={() => setText(question)}
            className="inline-flex items-center gap-1.5 text-[11.5px] font-medium text-muted-foreground hover:text-foreground"
          >
            <RotateCcw className="size-3" aria-hidden />
            Reset to the engine&apos;s wording
          </button>
        )}
      </div>

      <label className="sr-only" htmlFor="resolving-question">
        The one thing to confirm
      </label>
      <textarea
        id="resolving-question"
        ref={ref}
        value={text}
        onChange={(e) => setText(e.target.value)}
        spellCheck
        rows={1}
        className="mt-3 w-full resize-none rounded-md border border-border bg-secondary/40 px-3 py-2.5 text-[16px] font-medium leading-snug tracking-tight outline-none transition hover:bg-secondary/70 focus:border-foreground focus:bg-background sm:text-[17px]"
      />

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <CopyButton value={text} label="Copy question" />
        <span className="text-[11.5px] text-muted-foreground">
          {edited
            ? "Edited in this tab only. Nothing is saved."
            : "Editable. Nothing is saved."}
        </span>
      </div>

      <div className="mt-5 flex flex-wrap gap-x-8 gap-y-3 border-t border-border pt-4 text-[13px]">
        <div>
          <span className="text-muted-foreground">Ask · </span>
          <span className="font-medium">{owner}</span>
        </div>
        <div>
          <span className="text-muted-foreground">Takes · </span>
          <span className="font-medium">{cost}</span>
        </div>
      </div>
      <p className="mt-3 text-[13px] leading-relaxed text-muted-foreground">
        {unlocks}
      </p>

      {children && (
        <div className="mt-5 border-t border-border pt-5">{children}</div>
      )}
    </div>
  );
}
