# Case packet

One sanitised Flent exercise deal, the raw comparable-listing pull around it, a
provisional BOSS assessment and a small historical prediction-versus-outcome set.
The evidence snapshot is dated **18 August 2026**. We have deliberately left noise,
missing values and censored outcomes in the data.

This is not production data. The society and people are anonymised, identifiers and
selected values have been changed, and the listing pull is a bounded exercise
dataset modelled on the kinds of records BOSS receives. The contradictions,
duplicates, stale entries and missing values are intentional.

## Files

| File | What it is |
|---|---|
| `deal.md` | The property and the landlord's opening ask, as our Supply team recorded it: rent ask, security deposit ask, escalation, rent-free period, furnishing capex estimate, custom terms, plus the home's basics. |
| `comments.md` | Sanitised extracts from the internal thread on this deal: Supply, Demand, Pricing, Finance and Property notes, in the order they were made. |
| `listings.csv` | An 86-row raw pull of rental listings for comparable homes in the same micromarket. Duplicates, stale entries and mislabelled rows are present on purpose. Source URLs are removed. |
| `outcomes.csv` | Fourteen anonymised historical exercise cases pairing acquisition-time predictions with day-90 outcomes. Observed, partial, cancelled, still-filling and not-yet-mature records are included. |
| `boss-assessment.md` | The provisional BOSS recommendation for this case, its transparent exercise arithmetic, provenance, uncertainties and flip conditions. It contains no production thresholds. |
| `photos/` | Four anonymised stills from the site-visit walkthrough, plus a short manifest. |

Suggested starting points: Problem 1 → `listings.csv`; Problem 2 → `outcomes.csv`;
Problem 3 → `boss-assessment.md` together with the deal, comments and photos.

## `listings.csv` fields

| Column | Meaning |
|---|---|
| `listing_id` | Row identifier for the exercise, not the platform's identifier. |
| `source` | Platform the listing was scraped from. |
| `posted_date` | Date the listing was first seen (YYYY-MM-DD). |
| `last_seen_date` | Date the listing was last seen live. |
| `society` | Society or project name as written on the platform. |
| `locality` | Locality as written on the platform. |
| `bhk` | Bedrooms as listed. |
| `furnishing` | Furnishing state as listed. |
| `area_sqft` | Built-up area as listed (may be blank). |
| `rent` | Monthly asking rent, INR. Maintenance is not reliably captured. |
| `deposit` | Security deposit as listed, INR (may be blank). |
| `photo_count` | Number of photos on the listing. |
| `poster_type` | Owner / broker / unknown. |

The listing rows do not include marketplace images. `photo_count` is the scraped
image-count field; the four files under `photos/` belong to the subject deal only.

## `outcomes.csv` fields

| Column | Meaning |
|---|---|
| `case_id` | Anonymised exercise-case identifier. |
| `signed_date` | Date the landlord agreement was signed. |
| `micromarket` | Operating micromarket used for the prediction. |
| `bhk` | Bedrooms in the signed home. |
| `predicted_tenant_revenue` | Stabilised monthly tenant revenue forecast at acquisition. |
| `predicted_full_fill_days` | Forecast days from handover until all lettable rooms fill. |
| `predicted_capex` | Capex forecast at acquisition, INR. |
| `predicted_capital_employed` | Forecast capex plus uncovered deposit and included one-time costs, INR. |
| `predicted_monthly_contribution` | Forecast stabilised monthly contribution, INR. |
| `predicted_payback_months` | Forecast simple payback. |
| `actual_tenant_revenue_day_90` | Collected or contracted monthly revenue visible at day 90; may be blank. |
| `actual_full_fill_days` | Observed days to full occupancy; blank when not observed. |
| `actual_capex` | Booked capex by the observation date; may be blank or incomplete. |
| `actual_capital_employed_day_90` | Capital employed visible at day 90; may be blank. |
| `actual_monthly_contribution_day_90` | Monthly contribution visible at day 90; blank before stabilisation. |
| `actual_payback_months_day_90` | Simple payback using the available day-90 actuals; may be blank. |
| `outcome_status` | Observed / partially observed / still filling / cancelled / not mature. |
| `observation_date` | Cut-off date for actual fields. |
| `notes` | A short explanation of censoring, comparability or material variance. |

## Ground rules

- Treat the packet as the complete evidence available. If something is not here, it
  either does not exist or should be clearly marked as an assumption.
- You may add synthetic rows if you need them. Label them.
- Blank outcome fields are not zeroes. Use `outcome_status`, `observation_date` and
  `notes` before deciding whether a record is comparable.
- Do not try to identify the property, the landlord or the people in the thread.
- There is no hidden answer key. We care about how you handle evidence and explain
  trade-offs, not whether you land on a particular verdict.
