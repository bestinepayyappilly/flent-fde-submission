"use client";

import {
  Check,
  ChevronRight,
  Clock,
  LayoutPanelLeft,
  MessagesSquare,
  Search,
} from "lucide-react";
import Link from "next/link";
import { Segmented } from "@/components/segmented";
import { useMemo, useState } from "react";
import { rupees, type DealSummary, type Pipeline } from "@/lib/api";

type Filter = "all" | "acquire" | "negotiate" | "awaiting";

/**
 * The triage page, laid out like screenshots/boss-pipeline.png.
 *
 * Kept deliberately thin: this is the page someone scans, not the page they
 * read. Anything that explains itself belongs on the deal page behind the
 * row. Columns the packet has no data for (BOSS's OA-GPU, TIER, TAT) are left
 * out rather than filled with dashes.
 */
type Row = {
  id: string;
  title: string;
  sub: string;
  /** The scope filter that decides which comps a subject even gets compared
   *  against — a 24% spread across tiers here, and the reason the
   *  fully-furnished variant is a refusal rather than a benchmark. Worth a
   *  badge rather than a line of small grey text. */
  furnishing: string;
  synthetic: boolean;
  status: string;
  marketNote: string;
  contribution: number | null;
  payback: number | null;
  evidence: string;
  conservative?: boolean;
};

export function PipelineView({
  p,
  deals,
}: {
  p: Pipeline;
  deals: DealSummary[];
}) {
  const [filter, setFilter] = useState<Filter>("all");
  const [chip, setChip] = useState<string | null>(null);
  const [q, setQ] = useState("");

  // One row per subject. The packet's deal carries BOSS's costings; the
  // fabricated subjects have none, so those columns stay empty rather than
  // being filled with invented capex and revenue.
  const headline = p.scenarios[0];
  const rows_all: Row[] = useMemo(() => {
    const out: Row[] = [];
    if (headline) {
      out.push({
        id: p.market.deal_id,
        title: `${p.property.society} · ${p.property.config.split(" · ")[0]}`,
        sub: `${p.property.locality.split(",")[0]} · ${p.scenarios.length} ways to approach it`,
        furnishing: p.property.furnishing.toLowerCase(),
        synthetic: false,
        status: headline.status,
        marketNote: headline.market_note ?? p.market.label,
        contribution: headline.contribution,
        payback: headline.payback_months,
        evidence: headline.evidence,
        conservative: headline.conservative,
      });
    }
    for (const d of deals) {
      if (d.id === p.market.deal_id) continue;
      const refused = d.median === null;
      out.push({
        id: d.id,
        title: `${d.society} · ${d.bhk}BHK`,
        // Same line the packet deal gets. Its address is recorded in the
        // packet; theirs is read off their own listings, which is the only
        // source that exists for a subject nobody visited.
        sub: d.locality ?? "",
        furnishing: d.furnishing,
        synthetic: d.synthetic,
        status: refused
          ? "AWAITING"
          : d.robustness?.call === "ABOVE MARKET"
            ? "NEGOTIATE"
            : "ACQUIRE",
        marketNote: refused
          ? `refused · only ${d.n} comparable${d.n === 1 ? "" : "s"} survive`
          : `${rupees(d.median)} from ${d.n} listings`,
        contribution: d.economics?.contribution ?? null,
        payback: d.economics?.payback_months ?? null,
        evidence: refused ? "NOT ENOUGH EVIDENCE" : `${d.tier} CONFIDENCE`,
      });
    }
    return out;
  }, [headline, deals, p]);

  const counts = useMemo(
    () => ({
      all: rows_all.length,
      acquire: rows_all.filter((d) => d.status === "ACQUIRE").length,
      negotiate: rows_all.filter((d) => d.status === "NEGOTIATE").length,
      awaiting: rows_all.filter((d) => d.status === "AWAITING").length,
    }),
    [rows_all],
  );

  const chips = useMemo(
    () => Array.from(new Set(rows_all.map((d) => d.evidence))),
    [rows_all],
  );

  const rows = rows_all.filter((s) => {
    if (filter !== "all" && s.status !== filter.toUpperCase()) return false;
    if (chip && s.evidence !== chip) return false;
    const n = q.trim().toLowerCase();
    return (
      !n ||
      s.title.toLowerCase().includes(n) || s.sub.toLowerCase().includes(n)
    );
  });

  const TILES: { key: Filter; n: number; label: string; icon: typeof Check }[] = [
    { key: "all", n: counts.all, label: "ALL DEALS", icon: LayoutPanelLeft },
    { key: "acquire", n: counts.acquire, label: "ACQUIRE", icon: Check },
    {
      key: "negotiate",
      n: counts.negotiate,
      label: "NEGOTIATE",
      icon: MessagesSquare,
    },
    { key: "awaiting", n: counts.awaiting, label: "AWAITING", icon: Clock },
  ];

  // BOSS's own verdict vocabulary, from the 18 Aug thread: acquire /
  // negotiate / hold / pass.
  const PILL: Record<string, string> = {
    ACQUIRE: "border-acquire-border bg-acquire-bg text-acquire",
    NEGOTIATE: "border-refuse-border bg-refuse-bg text-refuse",
    AWAITING: "border-border bg-secondary text-muted-foreground",
  };

  return (
    <>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <h1 className="text-[26px] font-semibold tracking-tight sm:text-[30px]">
          Deals
        </h1>
        <Segmented dealId={p.market.deal_id} />
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-4">
        <p className="text-[13.5px] text-muted-foreground">
          {rows_all.length} subjects scored from one 86-listing pull ·{" "}
          {p.status.toLowerCase()}
        </p>
        <div className="relative">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search deal, society, terms"
            className="w-[280px] max-w-full rounded-md border border-border bg-card py-2 pl-9 pr-3 text-[13px] outline-none focus:border-foreground"
          />
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 overflow-hidden rounded-lg border border-border bg-card sm:grid-cols-2 lg:grid-cols-4">
        {TILES.map((t, i) => {
          const active = filter === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setFilter(t.key)}
              aria-pressed={active}
              className={`px-5 py-5 text-left transition ${
                i > 0
                  ? "border-t border-border sm:border-l sm:border-t-0"
                  : ""
              } ${active ? "bg-secondary" : "hover:bg-secondary/60"}`}
            >
              <div className="tnum text-[30px] font-semibold leading-none tracking-tight">
                {t.n}
              </div>
              <div
                className={`mt-2 flex items-center gap-1.5 text-[11.5px] tracking-[0.06em] ${
                  t.key === "acquire" && t.n > 0
                    ? "text-acquire"
                    : t.key === "negotiate" && t.n > 0
                      ? "text-refuse"
                      : "text-muted-foreground"
                }`}
              >
                <t.icon className="size-3.5" aria-hidden />
                {t.label}
              </div>
            </button>
          );
        })}
      </div>

      <div className="mt-5 flex flex-wrap gap-2">
        {chips.map((c) => (
          <button
            key={c}
            onClick={() => setChip(chip === c ? null : c)}
            className={`rounded-full border px-3 py-1.5 text-[11.5px] font-medium transition ${
              chip === c
                ? "border-foreground bg-foreground text-background"
                : "border-border bg-card text-muted-foreground hover:text-foreground"
            }`}
          >
            {c.charAt(0) + c.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      <div className="mt-6 overflow-hidden rounded-lg border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-left">
            <thead>
              <tr className="border-b border-border bg-secondary/60 text-[11px] font-medium tracking-[0.06em] text-muted-foreground">
                <th className="px-5 py-3">VERDICT</th>
                <th className="min-w-[230px] px-5 py-3">DEAL</th>
                <th className="px-5 py-3">MARKET</th>
                <th className="px-5 py-3 text-right">CONTRIBUTION</th>
                <th className="px-5 py-3 text-right">PAYBACK</th>
                <th className="px-5 py-3">EVIDENCE</th>
                <th className="px-5 py-3" />
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && (
                <tr>
                  <td
                    colSpan={7}
                    className="px-5 py-10 text-center text-[13px] text-muted-foreground"
                  >
                    Nothing matches that filter.{" "}
                    <button
                      onClick={() => {
                        setFilter("all");
                        setChip(null);
                        setQ("");
                      }}
                      className="font-medium text-foreground underline"
                    >
                      Show all deals
                    </button>
                  </td>
                </tr>
              )}
              {rows.map((s) => (
                <tr key={s.id} className="border-b border-border last:border-0">
                  <td className="px-5 py-4">
                    <span
                      className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-1 text-[11.5px] font-medium ${
                        PILL[s.status] ?? PILL.AWAITING
                      }`}
                    >
                      {s.status === "ACQUIRE" ? (
                        <Check className="size-3.5" aria-hidden />
                      ) : s.status === "NEGOTIATE" ? (
                        <MessagesSquare className="size-3.5" aria-hidden />
                      ) : (
                        <Clock className="size-3.5" aria-hidden />
                      )}
                      {s.status}
                    </span>
                    {s.conservative && (
                      <span className="mt-1 block text-[10.5px] leading-tight text-muted-foreground">
                        conservative default
                      </span>
                    )}
                  </td>
                  <td className="min-w-[240px] px-5 py-4">
                    <Link href={`/deals/${s.id}`} className="block">
                      <div className="flex flex-wrap items-center gap-2 text-[14px] font-medium">
                        {s.title}
                        {s.synthetic && (
                          <span className="rounded-full border border-border bg-secondary px-2 py-0.5 text-[10.5px] font-medium text-muted-foreground">
                            fabricated subject
                          </span>
                        )}
                        {/* Neutral, not colour-coded: the tier is a fact
                            about the subject, not a judgement on it. */}
                        <span className="rounded-full border border-border px-2 py-0.5 text-[10.5px] font-medium text-muted-foreground">
                          {s.furnishing}
                        </span>
                      </div>
                      {s.sub && (
                        <div className="mt-0.5 text-[12.5px] text-muted-foreground">
                          {s.sub}
                        </div>
                      )}
                    </Link>
                  </td>
                  <td className="px-5 py-4 text-[12.5px] text-muted-foreground">
                    {s.marketNote}
                  </td>
                  <td className="tnum px-5 py-4 text-right text-[14px] font-medium">
                    {s.contribution === null ? (
                      <span className="font-normal text-muted-foreground">—</span>
                    ) : (
                      <>
                        {rupees(s.contribution)}
                        <span className="text-[12px] font-normal text-muted-foreground">
                          /mo
                        </span>
                      </>
                    )}
                  </td>
                  <td className="tnum px-5 py-4 text-right text-[13.5px]">
                    {s.payback === null ? (
                      <span className="text-muted-foreground">—</span>
                    ) : (
                      `${s.payback} mo`
                    )}
                  </td>
                  <td className="px-5 py-4">
                    <span className="inline-block whitespace-nowrap rounded-full border border-dashed border-border px-2.5 py-1 text-[11px] text-muted-foreground">
                      {s.evidence.toLowerCase()}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-right">
                    <Link href={`/deals/${s.id}`} aria-label="Open">
                      <ChevronRight className="ml-auto size-4 text-muted-foreground" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <p className="mt-4 max-w-3xl text-[12.5px] leading-relaxed text-muted-foreground">
        Only the first row carries BOSS&apos;s own costings. Every other
        subject is fabricated and costed on the same operating assumptions,
        with tenant revenue scaled from the rent, so the columns line up. Those
        payback figures compare subjects; they are not forecasts.
      </p>
    </>
  );
}
