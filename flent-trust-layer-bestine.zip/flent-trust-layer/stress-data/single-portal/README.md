# single-portal

**SYNTHETIC. Every row here is fabricated.**

20 comparables, 19 of them from one portal. The count looks healthy and the evidence is not: this is S5.

**Expected:** publishes, but the tier drops to LOW naming the dominant portal

20 listings.
