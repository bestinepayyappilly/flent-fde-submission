export const API =
  process.env.NEXT_PUBLIC_API_URL ?? "http://127.0.0.1:8077";

export type Flag = { status: string; rule: string; reason: string };

export type Rule = {
  name: string;
  does: string;
  why: string;
  family: string;
};

export type Listing = {
  id: string;
  source: string;
  society_raw: string;
  society: string;
  locality: string;
  bhk: string;
  furnishing: string;
  area_sqft: number | null;
  rent: number;
  deposit: number | null;
  photo_count: number;
  poster_type: string;
  posted_date: string | null;
  last_seen_date: string | null;
  age_days: number | null;
  status: string;
  rule: string;
  reason: string;
  all_flags: Flag[];
  dup_cluster: string;
  override_by: string;
  included: boolean;
};

export type Branch = {
  compare: number;
  delta: number;
  pct: number;
  above: boolean;
  reading: string;
  implication: string;
};

export type Threshold = {
  name: string;
  value: number | string;
  provenance: "EVIDENCED" | "ASSUMED" | "CONSTANT";
  basis: string;
  if_wrong: string;
};

export type Attack = {
  id: string;
  description: string;
  median: number;
  verdict: string;
};

export type AnswerEntry = {
  deal_id: string;
  answer: string;
  who: string;
  note: string;
  at: string;
};

export type Choice = {
  label: string;
  compare: string;
  detail: string;
  /** What this answer will decide, shown before the click. */
  preview?: string;
  result?: string;
};

export type Scored = {
  deal: {
    id: string;
    society: string;
    bhk: string;
    furnishing: string;
    base_rent: number;
    maintenance: number;
    all_in: number;
    snapshot: string;
    label: string;
    note: string;
    variant: boolean;
    synthetic: boolean;
  };
  cascade: {
    stages: {
      divider: boolean;
      stage?: string;
      rows?: number;
      cut?: number;
      median?: number | null;
    }[];
    raw: number;
    included: number;
    not_evidence: number;
    not_comparable: number;
    raw_median: number | null;
  };
  benchmark: {
    n: number;
    median: number | null;
    ci: [number, number] | null;
    tier: string;
    tier_reason: string;
    sources: string[];
    owners: number;
    swing: number | null;
    loo_range: [number, number] | null;
    mean: number | null;
    mean_with_bait: number | null;
    median_with_bait: number | null;
    values: number[];
    clusters: number;
    overrides: number;
  };
  fork: {
    median: number;
    base: Branch;
    all_in: Branch;
    spread: number;
    straddles: boolean;
  } | null;
  robustness: {
    call: string;
    action: string;
    tier: string;
    survived: number;
    total: number;
    stability: number;
    flipped: Attack[];
  } | null;
  verdict: {
    call: string;
    headline: string;
    detail: string;
    published_benchmark: boolean;
    resolved?: boolean;
    action?: {
      owner: string;
      question: string;
      cost: string;
      unlocks: string;
    };
    resolution?: string[];
    resolution_note?: string;
    survivors?: {
      id: string;
      rent: number;
      source: string;
      age_days: number;
      poster: string;
    }[];
  };
  listings: Listing[];
  rules: Record<string, Rule>;
  answer: AnswerEntry | null;
  answer_log: AnswerEntry[];
  answer_choices: Record<string, Choice>;
  aliases: Record<string, string[]>;
  policy: Threshold[];
};

export type DealSummary = {
  id: string;
  society: string;
  /** Most common locality across this subject's own clustered listings. A
   *  label, never an input to the benchmark. Null if the pull has none. */
  locality: string | null;
  bhk: string;
  furnishing: string;
  verdict: string;
  headline: string;
  median: number | null;
  tier: string;
  n: number;
  robustness: Scored["robustness"];
  note: string;
  variant: boolean;
  synthetic: boolean;
  economics: {
    owner_cost: number;
    monthly_revenue: number;
    contribution: number;
    capital_employed: number;
    payback_months: number | null;
    basis: string;
  } | null;
};

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${API}${path}`, { cache: "no-store" });
  if (!res.ok) throw new Error(`${path} -> ${res.status}`);
  return res.json() as Promise<T>;
}

export const getDeals = () =>
  get<{ deals: DealSummary[] }>("/api/deals").then((d) => d.deals);

export const getDeal = (id: string) => get<Scored>(`/api/deals/${id}`);

/** Rupees, Indian digit grouping, no decimals. */
export function rupees(v: number | null | undefined): string {
  if (v === null || v === undefined) return "—";
  return "₹" + Math.round(v).toLocaleString("en-IN");
}

export function pct(v: number): string {
  return `${v > 0 ? "+" : ""}${(v * 100).toFixed(1)}%`;
}

export function signed(v: number): string {
  return `${v > 0 ? "+" : "−"}${rupees(Math.abs(v)).replace("₹", "₹")}`;
}

export type Scenario = {
  id: string;
  name: string;
  sub: string;
  monthly_revenue: number;
  owner_cost: number;
  contribution: number;
  capital_employed: number;
  payback_months: number | null;
  status: string;
  evidence: string;
  market_note?: string;
  conservative?: boolean;
};

export type Pipeline = {
  status: string;
  status_note: string;
  property: {
    society: string;
    society_note: string;
    locality: string;
    config: string;
    area_sqft: number;
    area_note: string;
    furnishing: string;
    furnishing_note: string;
    floor: string;
    outlook: string;
    availability: string;
  };
  terms: { label: string; value: string; status: string; note?: string }[];
  inputs: Record<
    string,
    { value: number; label: string; status: string; note: string }
  >;
  scenarios: Scenario[];
  market: {
    label: string;
    detail: string;
    median: number | null;
    tier: string;
    n: number;
    deal_id: string;
    question: string | null;
    owner: string | null;
  };
  checks: { name: string; expected: number[]; got: number[]; ok: boolean }[];
};

export const getPipeline = () => get<Pipeline>("/api/pipeline");
